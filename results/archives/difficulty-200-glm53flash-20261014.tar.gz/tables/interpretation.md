# Study interpretation companion

Evidence class: `live_development`. Model: `x-test-1`.

Generated from verified recorded attempts. Human interpretation remains pending.

- All attempts remain in denominators, including provider failures. No inference or solver reruns are performed by analysis.
- Block and tier rows pool task/label cells explicitly; fine cells may contain one observation and have no population confidence claim.
- Related renderings and generation/repair instances share families; rows across summary scopes must not be added together.
- Casebook includes every rejection, unscored answer, structural mismatch and valid nonmatching/unproved objective, plus the first clean success per block/tier/method in sorted identity order.
- Examples are selected for interpretation, not for estimating rates. Structural mismatches are not automatic causal explanations.
- Gold data in the casebook is evaluator-only and must never be passed back to either method during measured inference.

## Failure-inclusive block outcomes

| Block | Method | Accepted / attempted | Rate | Valid SAT / SAT | Correct UNSAT / UNSAT | Objective matches / comparable |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| controlled | direct | 55/60 | 91.7% | 26/30 | 29/30 | 25/26 |
| controlled | solver_augmented | 60/60 | 100.0% | 30/30 | 30/30 | 30/30 |
| language | direct | 18/20 | 90.0% | 8/10 | 10/10 | 8/8 |
| language | solver_augmented | 18/20 | 90.0% | 9/10 | 9/10 | 9/9 |
| realistic | direct | 18/20 | 90.0% | 8/10 | 10/10 | 8/8 |
| realistic | solver_augmented | 20/20 | 100.0% | 10/10 | 10/10 | 10/10 |

Objective matching is conditional on gold-valid SAT schedules with comparable reference stages; 0/0 means unavailable, not zero performance.

## Evidence review

Full request, original schedule, gold specification, model output, extracted specification and checksummed trace pointers are in `casebook.json`. Paths identify reproduction-archive members.

### Example `ffdc779b794e`

`difficulty-0020c5ec0fe4660f50b9020b-generation` / canonical / direct / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/d9a394758bf9365b65659fc0de59da78af1b0d0dfa6f5148458451eb9b36f281.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c7ebbeeafcd`

`difficulty-0020c5ec0fe4660f50b9020b-generation` / canonical / solver_augmented / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/02c695e4263769ef95b76677e7bd7b3e2db1d8db3060ab74b025c27b6059bdc4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `141e195c24ec`

`difficulty-0b7187410c3abe24d822d691-generation` / canonical / direct / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/controlled/controlled/attempts/d30ef6153be61d0221f94652f73416fc7e12d5d4ad8224dfc85f1d2031e51e56.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a7b44731e83`

`difficulty-0b7187410c3abe24d822d691-generation` / canonical / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/4ed4d0581197b0df8c4b66a07844c2f2ff5bf4fba8f3a62f68f2defddb6a7608.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8911eeddc990`

`difficulty-0b7187410c3abe24d822d691-repair` / canonical / direct / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/ba6952bfb4e62f4c510268ac22236e9b45d89bb62b38152c866e2dc27ccb08c3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `58399b9d0670`

`difficulty-0fd2c91a8d9ebf63959d5309-generation` / canonical / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/b18600648f03c6da38a532d81d0d5e6863b0a8b47a4736cfce077163bf838152.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c36333de140e`

`difficulty-0fd2c91a8d9ebf63959d5309-generation` / canonical / solver_augmented / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/f79836a4c615ea7b735f12e627b3920510dfbdf581419d0c76dc74354f100d8f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cbb470a653ff`

`difficulty-2db29861b6da01ed900d90ee-generation` / canonical / direct / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/219d280afe98539b601b865cdbb2b4483722e2c8796ef5c81f5a7ed95cf802c6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `408253b2a861`

`difficulty-2db29861b6da01ed900d90ee-generation` / canonical / solver_augmented / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/f817aa0587f884f8747d589585c0087667eaff6cc25bf20aec8c088bf6090cf6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1a4c82881976`

`difficulty-3d94df09f26bfb5af5f06691-generation` / canonical / direct / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/0d1715ea7f876e2994901c72281cf54ec1708a17b7dc25744f816258b2bb05d1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fbe72272c1eb`

`difficulty-3d94df09f26bfb5af5f06691-generation` / canonical / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/9e41c2848db66851b2c579bf39fcdf0a34ae4cef65e57193a4c2b541aa78287e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5aecacd42822`

`difficulty-6b7b49b44db771d64af31ce3-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/8ddff8252078f1d57cb96d250f78bc998e2fcce9e0a9ecb40cd8747182db5fb5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e9373cf4690f`

`difficulty-89b1e300bfbadfa2a68b697d-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/1fd32a48844a8ddc37845ab440f0150da8cb5fae51df07d9d4114e3d57f21901.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `410f1c9bd10c`

`difficulty-9fa7b12430c5191bd2fb930e-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/456205450ccbb91d8751cbc3c9c52cd89e08954f9d87bd5be937468647ecf890.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `97220dbf3e70`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/56c5277535d60e581f7ea716b865277d58f30d8cbb515c92e1aa3e73d6e27ad6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2e75e2fe74e8`

`difficulty-cdf1f6441e4a0d266084a8c8-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/32a483cb858632896dc403ce0ecc9509c0b54b6203f59900178a7796fd9d6aeb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f1b1daa5aa43`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / paraphrase / direct / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/73ffc702416d92a9c5ad5b8b8e43f3d2221061b38dfe13d11dc08e26d4b32f95.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a6a121833329`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / paraphrase / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/94b99900cd3fd466b6770c76fd7ce878b69774582b062eb47a4920c2a9f20c59.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `41768b0ee1d1`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / reordered / solver_augmented / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/language/language/attempts/c9702e2384c1eb570f6f2ed7c4919e4a3170abc3a339a0621327885627c9c65f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `60b4bd1999f9`

`difficulty-0b7187410c3abe24d822d691-generation` / paraphrase / direct / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/969d71dd2aa8881be10aa1e2d464e5ec4f890caaa08477ae8c35b24ac78863e6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2f545eb79035`

`difficulty-0b7187410c3abe24d822d691-generation` / paraphrase / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/b47791b6678206892ce856c3377e91aebdc0122c2a683117901bf7200ef5e2b5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bae4836704e2`

`difficulty-0b7187410c3abe24d822d691-generation` / reordered / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/5ce5db54ffc17dc66e31cc4521bdce00b42b27bb69c641e9b5997a0fd40b5f75.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d76f298f4a5c`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / paraphrase / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/ba4ad3cef81446894cdea2760556193cfeafd0d213baafce5ded9a8115c33a7c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e337b3c08056`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / paraphrase / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/3f69cd2f0494ce7b32745e0ef748844c8260d386cf5e2d9dad574e2dbe63bfe4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cdc5b75999a4`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / reordered / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/e26608199ee0f25a69f9e91d2ba13f8203363e2b39ebec48864276558be2531b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7fe62d8d2e9f`

`difficulty-2db29861b6da01ed900d90ee-generation` / paraphrase / direct / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/5edcb55dac81066ec2eb65733023accccd902ad023b99844f302422a3b756b48.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `050bf03340d0`

`difficulty-2db29861b6da01ed900d90ee-generation` / paraphrase / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/89d473c16fb761f23b178e3a50e2924895033388d7fb1bf3cfa4a88b87721f8b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8571c43a3210`

`difficulty-2db29861b6da01ed900d90ee-generation` / reordered / solver_augmented / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/18e77e4b137104333d7142a90a5cea99ba15dc773879ec6b360886f5383c3b37.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d67a7e6e4407`

`difficulty-81df31c2af1d216b78dd1e91-repair` / paraphrase / direct / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/115ddbfb8268c985e7ff56bf4a967657f52639b648c90d7d56c5dbbfb0dcdb01.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `443cf504cecd`

`difficulty-81df31c2af1d216b78dd1e91-repair` / paraphrase / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/820d3a2e90eb875e2acc8c9d2e9f7a3a3b41a81d4aa36d1f4b979ae74d35c248.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aa64acd172e7`

`difficulty-81df31c2af1d216b78dd1e91-repair` / reordered / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/52a23b05a6ca9c490c1cfb15ae097b743d17e3f4ec264a74483771f488921545.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7985f5b404bc`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / paraphrase / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/1628e470a9acddece188887d262ab3c532e31716b566daa85e98618d746ddde5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b982c6b4b62e`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / reordered / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/1ca09109ebccf921134e951d78d67d25c7e19f4005e7d94f6558e4c749d7d864.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5ed25ed5c250`

`difficulty-a29114c9c66571386fb90095-generation` / paraphrase / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/4020264c032eac26aa1d6b920f969d0e7e699b470bc1d98257a3bef6df52bc1b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `509c725b24ab`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / paraphrase / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/language/language/attempts/391cdbda100410948b1fd8bda92baa22cb55c99d68d6a5b51086382b9330773e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b3f33cb67ce1`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / paraphrase / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/54c2519afaaa4a56d38a701543c3ffa9904896a85d11f4b69c006fa8f076e5f9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cfdf122554ec`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / reordered / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/language/language/attempts/d84a9c08c8d5c5eef9720d735d60a0491e21b93ee486710f0fc3d994c457c8b1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `75484fd5faf7`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / reordered / solver_augmented / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/language/language/attempts/ab98756664b5b57369a8fff136117c3ecd222d8ff7952683906b40cc70fc8096.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c51db4b795df`

`difficulty-b2b00bb2823346f5b73abe5a-generation` / paraphrase / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/3854bb0603772b11205ceae18a53e5ed9419295bc5f40afd76aa96f18f8355bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `921ceb57d1a4`

`difficulty-b2b00bb2823346f5b73abe5a-generation` / reordered / solver_augmented / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/95e47f50d5abfbf6abf673defff5bcd9b2bb3068e0bc667bc1a57a4ea2b9d516.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2e59de9c52b1`

`difficulty-ecdd584a599de7b78799f3dc-repair` / paraphrase / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/041637d71a5c7c41001df0b5d3e9fef486afe47b6ce8a6b3adb0aaf3632621a6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aba614ee8e6e`

`difficulty-1eeecc1c31e18b501ee559c6-generation` / canonical / direct / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/fd724452427b92dc7ad5e7e1a1928358159c625115a06872aad6c1bc0b8cd048.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ec0177772a00`

`difficulty-1eeecc1c31e18b501ee559c6-generation` / canonical / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/d1ca826f70795271ca7d2bf062f37feaad731eded3dfe577ad61b6ac1d79d30d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6ff36ba2451c`

`difficulty-36b286bcee4ce1613f31a350-generation` / canonical / direct / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/64a858f76a7d30ec6af5a927f47177132a1872d1f0b9c09d1156613abc3e0061.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `167e4e87ef78`

`difficulty-36b286bcee4ce1613f31a350-generation` / canonical / solver_augmented / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/aaafdfa976b57fa0e0f5201dc5afb91f7c39458cc855afa5550a91fb6ab005df.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8db53a400d0c`

`difficulty-3c3c60bd2407f1828a3e048e-generation` / canonical / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/563b919a65daed378eb08475618bd6d5e97666237995b86c5b61549763b95aac.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5d850a9bd843`

`difficulty-3c3c60bd2407f1828a3e048e-generation` / canonical / solver_augmented / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/14b888bb76b72dca4d537bdb36779c0954a7103be8cdf95a6a68f3bcfbc6183f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ca0d4d6284be`

`difficulty-6a05feedb643dd0d66ed41ae-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/realistic/realistic/attempts/00161d2304539fece2189e774de6ab898cfc58d822d5e0652f0e628b74969427.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `23aec7a270f9`

`difficulty-6a05feedb643dd0d66ed41ae-generation` / canonical / solver_augmented / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/62d1457dbee162a743283a6c4869e919340105377c39f2b168045c5f9c69c813.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b60d240ff3e6`

`difficulty-6a05feedb643dd0d66ed41ae-repair` / canonical / direct / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/2745b69c468a041b6f0e3f7e9a3134e4f61846303315026d4ce9e694e510d8c2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `68503f17a637`

`difficulty-6dd38a35a807f5693336f267-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/realistic/realistic/attempts/57c43b66099216fbdeaf289985c61fd9fcb44ec73afeeb6685295faa6c871b74.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `77e9e104f065`

`difficulty-dbfbed7cd7af66cf37a53817-generation` / canonical / direct / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/a05abf0c0182885152d2dc128b9bab5aa4d69002d0e0e550ce24fd3f3cead046.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `40191fd90c8b`

`difficulty-dbfbed7cd7af66cf37a53817-generation` / canonical / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/65035661511a20f3bb1e0adf16ec41424484a30b171c40695e325c9300b9a283.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

