# Study interpretation companion

Evidence class: `live_development`. Model: `qwen3.6:35b`.

Generated from verified recorded attempts. Human interpretation remains pending.

- All attempts remain in denominators, including provider failures. No inference or solver reruns are performed by analysis.
- Block and tier rows pool task/label cells explicitly; fine cells may contain one observation and have no population confidence claim.
- Related renderings and generation/repair instances share families; rows across summary scopes must not be added together.
- Casebook includes every rejection, unscored answer, structural mismatch and valid nonmatching/unproved objective, plus the first clean success per block/tier/method in sorted identity order.
- Examples are selected for interpretation, not for estimating rates. Structural mismatches are not automatic causal explanations.
- Gold data in the casebook is evaluator-only and must never be passed back to either method during measured inference.

## Failure-inclusive block outcomes

| Block | Method | Accepted / attempted | Rate | Valid SAT / SAT | Correct UNSAT / UNSAT | Objective matches / comparable |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| controlled | direct | 17/60 | 28.3% | 4/30 | 13/30 | 1/4 |
| controlled | solver_augmented | 57/60 | 95.0% | 29/30 | 28/30 | 29/29 |
| language | direct | 4/20 | 20.0% | 1/10 | 3/10 | 0/1 |
| language | solver_augmented | 19/20 | 95.0% | 9/10 | 10/10 | 9/9 |
| realistic | direct | 5/20 | 25.0% | 0/10 | 5/10 | 0/0 |
| realistic | solver_augmented | 18/20 | 90.0% | 10/10 | 8/10 | 10/10 |

Objective matching is conditional on gold-valid SAT schedules with comparable reference stages; 0/0 means unavailable, not zero performance.

## Evidence review

Full request, original schedule, gold specification, model output, extracted specification and checksummed trace pointers are in `casebook.json`. Paths identify reproduction-archive members.

### Example `ffdc779b794e`

`difficulty-0020c5ec0fe4660f50b9020b-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/0fcf815d5346279fb166fd5c292e3299f6b6f1513cc3453107d75bf02d3c734c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c7ebbeeafcd`

`difficulty-0020c5ec0fe4660f50b9020b-generation` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/436a8e05757d2f13499a6dc602f604e6f8e0eae615cdc4c1ca4b487b433e0bcf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e973e7cd0a16`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / canonical / direct / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/7494d1f28913ce3bc487d5b6145d48214d98924011d4a5280f51b5c0c40608f7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `30d8adec338d`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/651b032a6e3a8148916379e2462b73d9911cdd3f9fda77c8fd852b7612d851e3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b98d31548d2d`

`difficulty-00eaf3055a3435619e8c32fc-generation` / canonical / solver_augmented / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/088b36ee005b99ccf0ea688de311fa67868bce772b5d389e7c89380ad8261479.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `114d5f50cba0`

`difficulty-00eaf3055a3435619e8c32fc-repair` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/c57a67a26dd86af0f67b49cddf3e522cfbeb34e8c2f0425307731ebf35533af6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `292110175b24`

`difficulty-00eaf3055a3435619e8c32fc-repair` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/7830002dca54bb9a944097cd3b38b369fb0ed932f2bed037eee9c1243550248d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `141e195c24ec`

`difficulty-0b7187410c3abe24d822d691-generation` / canonical / direct / easy. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/c913e2c8d0b88a4d20bcc973f0cd46266a7b9a6096b52cc709ced1a56b93ee1d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a7b44731e83`

`difficulty-0b7187410c3abe24d822d691-generation` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/2f7b564c6fca5316215e71f5637ac47a47e74d10d4c2933c764f2d82ab2ed024.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8911eeddc990`

`difficulty-0b7187410c3abe24d822d691-repair` / canonical / direct / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/controlled/controlled/attempts/c3ad26d0d491017280c4b50b1b1721640a429b87afce7f844109f24fe23d24b1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a3dd0513e35b`

`difficulty-0b7187410c3abe24d822d691-repair` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/fbbf6d99aac2e6eb93ef814b588fdb5c84f06f1fd4a01911a62b57b787e27f79.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `58399b9d0670`

`difficulty-0fd2c91a8d9ebf63959d5309-generation` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a1c717d59e7fb69f9e4a687a8d60903b98ca4a0c0bb272d181bc46445f7b807b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c36333de140e`

`difficulty-0fd2c91a8d9ebf63959d5309-generation` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/d16ff982b8934f58e4c9b34ff45009b32d6728c4abea25ebd2bda07393a0b33b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c4cc703b5cd5`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/controlled/controlled/attempts/5f1ef37525ef49c19db6f5272e0761054a8b33da2d6369524adc8baa33c52d82.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `74f17d5af99a`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/c4b74ac938b9fb390d55a09180cbb424d663fbf638cb00c12433f168ba9d9967.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `09c72792c029`

`difficulty-2b5714bda3039e8302b8309a-generation` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/c6e58bbcc53cc8bcddd69070499f165e982c8695bfdf6d9fd4f06957c3f73ec3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0acd4d00181b`

`difficulty-2b5714bda3039e8302b8309a-generation` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/d54c293b68e010a4a7dffe84b1e02fae133fb70ef564bc87ba894eacf4af9bbf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d5e5f9468afb`

`difficulty-2b5714bda3039e8302b8309a-repair` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/controlled/controlled/attempts/30cbb50e77a90f3942efd6d04a39f7318b51de5e370cc57ed0ef51c4822436c6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `268a2785a51f`

`difficulty-2b5714bda3039e8302b8309a-repair` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/613740e2e770b800fe6a196aec15068eb9a8b0a1bc14836f77b0f4535fcc5d87.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cbb470a653ff`

`difficulty-2db29861b6da01ed900d90ee-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/748ed82d4b0c65d73f16d75ef13aa3ccd19a75b2fc0953bcbe605f6b88b4af78.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `408253b2a861`

`difficulty-2db29861b6da01ed900d90ee-generation` / canonical / solver_augmented / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/bdfd5bf24c00ff6dfe7ee193fbea20d2f0c094f1ac7c9f9d3ea8a24dc87a3596.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b8a79347c5d7`

`difficulty-2db29861b6da01ed900d90ee-repair` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/9e4ee7ef77be58751a1694ae7968ee62c59a18da135b83df36f9570c4fe1f673.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `65ab2e598e94`

`difficulty-2db29861b6da01ed900d90ee-repair` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/91054422758a6bc88f472506506c44515af66f9822e8bf49b13b6a4460e38601.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0b7db67f9d2d`

`difficulty-390ed27e0d18a5fcd3245800-generation` / canonical / direct / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/55de8ff97296616404702bdfeee27e0c9985facca32235740a8f0a874a7d64f4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `913d1e9089b2`

`difficulty-390ed27e0d18a5fcd3245800-generation` / canonical / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/18d5f03c9eb9fd1b33a06cf7c9712ec1893ed41badffd582d8f4026c253e9de4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e027594e88c8`

`difficulty-390ed27e0d18a5fcd3245800-repair` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1b95ceb5b12c8fc954225cc99a734fef386584ea8db4cf43c0a2ad4c8b65d68a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `12519e4a75bb`

`difficulty-390ed27e0d18a5fcd3245800-repair` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/9c9a9c141780892fb0d2b506f8e908602a7166f01c84e81c139dbcf73db3d99b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1a4c82881976`

`difficulty-3d94df09f26bfb5af5f06691-generation` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked, precedence.
- Attempt record: `runs/controlled/controlled/attempts/45ac9d32a5a12f3399ce3c33b7744185774db4ee80fb1e837c892b89fef8faf5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fbe72272c1eb`

`difficulty-3d94df09f26bfb5af5f06691-generation` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/7e4f5a73c94f11b9c1000fc4f278f50dfa0636985e70ad8f2c35aad579e9503f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d4dd81c0d9d3`

`difficulty-3d94df09f26bfb5af5f06691-repair` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/2529b90a12d3796063ca06a77ee1004ab96f4d3f8555492ec882c57c16a2826b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `76e517dd5789`

`difficulty-3d94df09f26bfb5af5f06691-repair` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/67b8f5db1e1e1f2f8e30ed814a7e5c547c4a85f01ad74c980a647ad826637820.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4ab3dc58c348`

`difficulty-4862d8ff6665c89ca99a1c8a-generation` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d08b0e854cfb053176e801b68dfb0e22da762b92a7dba348e40fb43cba589da7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7ec2c5eb1d90`

`difficulty-4862d8ff6665c89ca99a1c8a-generation` / canonical / solver_augmented / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/2944c5046976e009a905058d8ba0ae719d9d5c1794661362da95ba7857dce3f6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a0d29b0b932d`

`difficulty-4862d8ff6665c89ca99a1c8a-repair` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b3b1d42987f3ae325cefb50d856be73ae66a7427f1154ce8392d1edf3eac40bb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bc2a7b6073be`

`difficulty-577887286f301f7a8d330457-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/controlled/controlled/attempts/6c34bfb231b95714f61d01bda9227145daa2b5d14ad9d6db8232fc5f5ace44c6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e5d9d564b2a7`

`difficulty-577887286f301f7a8d330457-repair` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/60d2b30579120c779009278137ea0f6a83b0f23cb783a80fcbe32058a8d995c9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5aecacd42822`

`difficulty-6b7b49b44db771d64af31ce3-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/217f39424cbbd6b2c5e969e336850ff65d80d85b7f48b7c2f32201aaadbec880.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7d6a9c658842`

`difficulty-6b7b49b44db771d64af31ce3-generation` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/243c1a35e0b6d33e1943857b296c40a05ab203dd5981bc619f96a4b1a37a246a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0b8965e9a3b3`

`difficulty-6b7b49b44db771d64af31ce3-repair` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3da36e94539aa5460e5142b06232c7c2b71d0d739fbc862d27d04eb015b47ab8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `834e5ea9ad4c`

`difficulty-6b7b49b44db771d64af31ce3-repair` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/69f7af1902c15f67c396d73537dbcf66682246e7765afe3def6142249a6537d1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `363f1dd8353b`

`difficulty-763051de490e2a84f3946b4d-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/bae32c9a042596284945dbdcd7f2441d27d610e879335216a1064e2b50118707.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `890cd3c55881`

`difficulty-763051de490e2a84f3946b4d-generation` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/654afaa31c69539298bb13b667183124071ca98c96bce1f40b942f8a8482a4c3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `66ba7e86ba74`

`difficulty-763051de490e2a84f3946b4d-repair` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/59374a1ac40c5181b63d461bb81992362b745546e70ecb7d07bccbb9ef086a39.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5b7b03317536`

`difficulty-77c181646cc1eed03a3422b2-generation` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/572ddc9bfe0b8d3728a548521e1502fc6528fb392cfd8455de7b17d5038884bc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `adfbec19e31b`

`difficulty-77c181646cc1eed03a3422b2-generation` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/7f34fcb39bbc37bb180cf00ca1f3961582323819ed355aff3ae041ccd2730334.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2e66cc26d95b`

`difficulty-77c181646cc1eed03a3422b2-repair` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/3ccaef11e4fad189d23170af7910341e5ab324cf7538b0f95839dc5f52b03797.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `424ed1fa6176`

`difficulty-77c181646cc1eed03a3422b2-repair` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/cf0c82c4416dcc8fe95facc0a9ed3d502a69bf347dafb2d4bbce98039c5f7478.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9609b842dbc5`

`difficulty-7ce0aa639c2c3bc8657f38aa-generation` / canonical / direct / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/913250a5b5d70deb6fe0824411766a7773c4786112feb85489ca1787337db68e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f32d92fbae10`

`difficulty-7ce0aa639c2c3bc8657f38aa-generation` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/dad7d58c9a1ee2233d6305cd6f17649118fd143dc73cedc22021fa40ceccc22c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `be5fb1df9a1c`

`difficulty-7ce0aa639c2c3bc8657f38aa-repair` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/e84a383b7f7e108d0d1c2566ef8e74801e86f394a24dbc030b48bcb073852f38.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b4bdb60daf4f`

`difficulty-7ce0aa639c2c3bc8657f38aa-repair` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/e04c88ce1a3d61c7c94af26bda12242d80d3fab241743d58f0538f55835ecf60.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4caf98a07994`

`difficulty-81df31c2af1d216b78dd1e91-generation` / canonical / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/02a59ce92ac2b6e0489b796a964dd55863686505cc594653f3e9ed5820db40fe.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `efea333464a7`

`difficulty-81df31c2af1d216b78dd1e91-repair` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, fixed_start.
- Attempt record: `runs/controlled/controlled/attempts/c8f5392e5fbd81c88a34ee22850cc512cdc62f0ab22eb24e68ac0df0414050b1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e9373cf4690f`

`difficulty-89b1e300bfbadfa2a68b697d-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/2776b196b3f6cdc9448a31150929e448eb58aab7c620138a738128fc7fcc03e8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f9164cfb4c8f`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b106c6761a3abc866d299948d610315699c8e5342369bc6c5c282cf26a25e607.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `83c19b000ad4`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0e66e8ef09b470abbd2184f22d19dfdae2d4c4774f0c44c28286d4e770e48a0e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6c8d185827c7`

`difficulty-8fc172d742942ec004e74ec9-generation` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/f1a916028e7a72e965ef5a7ad26ec78e04be0104e78411bbe1ac3ff6c1a5bb0d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `165678470698`

`difficulty-8fc172d742942ec004e74ec9-repair` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/bb67626f455f00a7a9deaae6c57693747f2e369a5c5f1b2b48d752cc351f32ce.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a1c95ec06fa4`

`difficulty-9f3f12974d9fac7e2670d796-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/controlled/controlled/attempts/186c1086c5c88384c53431f4be115d2b52665bf9e0eec1dfcb90877bad03a131.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fb8449265919`

`difficulty-9f3f12974d9fac7e2670d796-repair` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/15f80474ba81cb7cc88582576a11a2fb432f10dd9efb3a513507e139b9001244.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8fb6b06dae99`

`difficulty-9fa7b12430c5191bd2fb930e-generation` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/e7e3afb9d4bf86b8e58efecfdb0f294ba6995f3a424fd2a01de4906af8691eb3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8aa074bb264a`

`difficulty-9fa7b12430c5191bd2fb930e-repair` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/bf7582928123ee73991aa96c1daf721d0d57ab0ddebbadcb34011dfe799b57c4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `999c225db6d6`

`difficulty-a29114c9c66571386fb90095-generation` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/3ef4a863de23c2a877088577a3b0a699923ab61e6909c8b6ed862b7731e4f54b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c2b5fbab4b65`

`difficulty-a29114c9c66571386fb90095-repair` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/edd7f54459e1c66812bc8b3eb40c2b39af6ba1561b3607eef2545913153842a1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `97220dbf3e70`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/e310a0a6a36427e63ff381e32fb5244222fbecb7297dd1475262ac1b1e84c1f8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `49bc7bc774eb`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/02e517045761c3eabea3d33759dab8d8e56fbee5bf136a35deaf717bd6d5e549.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `71f706847b5d`

`difficulty-a3c657c260a8d9be7aaf0f9f-repair` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ba7f3cf500bc441af066a07cd2ca3c080acbf5b044dd135d02f1e2bc29678fa9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `82adddd43131`

`difficulty-a3c657c260a8d9be7aaf0f9f-repair` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/1208631de7eef348d57fc9f95e024b052f9907d9ec4b11c412d3a76c9c81db33.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c1d1c2087e2d`

`difficulty-b2b00bb2823346f5b73abe5a-generation` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2a3e94b035b80a34f0878cc4a18b025aad9fe2fcd867caf45545ded0a4af37d3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `10a0209e7675`

`difficulty-b2b00bb2823346f5b73abe5a-repair` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/bdef732e7db23eecc3939c5f224e5e1b584cc7ddc78e7d701d5f933d9a46e240.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4f44be6e3ca1`

`difficulty-bfa06007795e9eb38210a6e2-generation` / canonical / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/4b155a2d78d673eb4555b7c97c2f12436bd7f657e8fbfd4734fd1345f4a85ace.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2e75e2fe74e8`

`difficulty-cdf1f6441e4a0d266084a8c8-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4d40414f9c6ac8c9779c0acaee2e8c08cce4d95965735d99ad36c599037788e2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `77fa9005aede`

`difficulty-cdf1f6441e4a0d266084a8c8-generation` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/d70c7f3a06ff6e2c0b7d777bd69580c46141b59a1a25ffafd83de37571f9f022.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bdff2dc11412`

`difficulty-cdf1f6441e4a0d266084a8c8-repair` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/73ce86691223b2c67415e9e8f94f696139f47ef89ef1f563f2fffa6de2567a8f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cb8e1948bffd`

`difficulty-cdf1f6441e4a0d266084a8c8-repair` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/54dd0443072c28d5eac76666a4cf95fe8f9c0a84e2753f78b5321153f7f61977.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0ff0a5fd8dbb`

`difficulty-ead7eeab45febddec0232b30-repair` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/controlled/controlled/attempts/b08f09d28122b509880bef998ee1c5ab11a277e91ba349683d310c23ee273478.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `083bbbac605f`

`difficulty-ec93292bc8716510a294e869-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1eeecbe68595a301e7b41efd41fcc4bafcfd227ded30de2a0fc55e69b6be79af.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b57a773787da`

`difficulty-ec93292bc8716510a294e869-generation` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/8f72defe7ab40dd8a5995e9df4e15817e5ca5b66cc1b49fbabfc8cd82c2e57e9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fb452dd32aa3`

`difficulty-ec93292bc8716510a294e869-repair` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d3f794ad5985f0a6cc5074fd9076f22a47f499d553052da52815b3bc5dc99639.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7f759132db78`

`difficulty-ec93292bc8716510a294e869-repair` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0bf3186093e267cf43dbae7356b5cd8c1146bb0673b8eaf2158dd117e3ce8184.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4dae0a8a77ab`

`difficulty-f4ec232764614cb7d78b6925-generation` / canonical / direct / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/controlled/controlled/attempts/bfa995d0c33041109f51d26229de9f63c9544e15a1b6ebcf9c2c47af4478463f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b1495bef55d6`

`difficulty-f4ec232764614cb7d78b6925-repair` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/1c1bb0ad8851d35ab0ce40b722b04bc18d4b60c959608e03aa8b890d005b58a0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ff8394a1f1ca`

`difficulty-faab3611349cada081c8e0b0-repair` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3ae67ca59f59c21ab27736effbecca78b1277174bbd3ad8242ad149a7d50b577.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dbbb9ef4138a`

`difficulty-fb1c2a0fe6f25c97d65238c2-generation` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/506be046b4202852b0a9413abb4320dd5e3d8a615c55848f0ba2d64642281005.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9687fcdeea1d`

`difficulty-fb1c2a0fe6f25c97d65238c2-repair` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c4bf4d10f55c100b5d5431aea2405a6690f7e17eeb2ab0d1c45e95948ad7cc13.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `51f877be7705`

`difficulty-fb1c2a0fe6f25c97d65238c2-repair` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/34a38fe3cadfe67b98499eb04e85cf414245a27a42739b786d9ed764ef3e74b7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f1b1daa5aa43`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / paraphrase / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/language/language/attempts/a1034a68753a345dff0c527504bc6eae88925a8b6642d378b1430cb94379aee2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a6a121833329`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / paraphrase / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/8ca47bbd46850ab36cc7070e4bb251bc5c36145c92979cb35d5b397f2d16425d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ccde10e6645b`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / reordered / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/language/language/attempts/c657cb037a517d72de4967101e9a5dbda653b0c7e02ef6412e457ae6973f1eae.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `41768b0ee1d1`

`difficulty-0020c5ec0fe4660f50b9020b-repair` / reordered / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/eb525f42cdabd8886567ce17cda7d2c005e35c27e0f712e7ac9765f2433e33e5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `60b4bd1999f9`

`difficulty-0b7187410c3abe24d822d691-generation` / paraphrase / direct / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/language/language/attempts/17a9cbb854c9a41dad727c58c097024db54786092d996a2436b94f8f2f676c2d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2f545eb79035`

`difficulty-0b7187410c3abe24d822d691-generation` / paraphrase / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/84a868b31e3105485ef827ac053a1b85812fbfb8d2d454e9694f8083eb5f7ea7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `175f1cb230b3`

`difficulty-0b7187410c3abe24d822d691-generation` / reordered / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/language/language/attempts/c418e4b2a2e75c35dc7851789384a540aebb1f6c23b7c13b7567f736653d09f2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bae4836704e2`

`difficulty-0b7187410c3abe24d822d691-generation` / reordered / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/274100ef127bb66aa943bfd3db067f37098dbd1b33ffa7cf98dbef68260a76c5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d76f298f4a5c`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / paraphrase / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/language/language/attempts/3bcfb347cc5e4449596522a2f892d03c164474100b74b0f47a1b07d37184726e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e337b3c08056`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / paraphrase / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/fa884d9f4deee1ed74e4fb7947f927dc133a4b07f8de03fe31065143320846ad.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d8cb3849c529`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / reordered / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/language/language/attempts/c2e45a93e9f9e0fcdca4e7912ef7dad11c100d9de0388e8d1f19289d83fc2b96.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cdc5b75999a4`

`difficulty-0fd2c91a8d9ebf63959d5309-repair` / reordered / solver_augmented / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/language/language/attempts/ba71aafaedb38c993c860e06f5e478e93a2a6004c46b9f7c29c7bce3be6aa595.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7fe62d8d2e9f`

`difficulty-2db29861b6da01ed900d90ee-generation` / paraphrase / direct / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/d6b968e598ee5a702a6d9001d044c67358a1182d485497dac20ff31d9744f79a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `050bf03340d0`

`difficulty-2db29861b6da01ed900d90ee-generation` / paraphrase / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/44b33e583d9c86df20f453e36b618839e007645286bb9aec821fbc03f03783b5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8571c43a3210`

`difficulty-2db29861b6da01ed900d90ee-generation` / reordered / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/c7bb290840a907e0d079b8224ca383ecba8735032af70adc1170400b5f7519c3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d67a7e6e4407`

`difficulty-81df31c2af1d216b78dd1e91-repair` / paraphrase / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/language/language/attempts/62ac84d0b424f570ffb4a862ec6d538efeb0c395356fef35dce5bbebba413c99.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `443cf504cecd`

`difficulty-81df31c2af1d216b78dd1e91-repair` / paraphrase / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/63d670d7fe3c5de5fd92302e62e149bbbbce55b9fd5c9b711813ba4d19659e55.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7604d50a2461`

`difficulty-81df31c2af1d216b78dd1e91-repair` / reordered / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/language/language/attempts/d9b3cfff04fbbea34f861dc2da21c9117c41d2140ef4d75cdf726c01b26661b6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aa64acd172e7`

`difficulty-81df31c2af1d216b78dd1e91-repair` / reordered / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/735d2941cd143c5092c18a93f44332209c58847a76e64d2eae1d4fe5afdff564.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a923f77d5304`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / paraphrase / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/language/language/attempts/f823543d7fcbbdd7156ce17839f165784252b16892aea33256a7797331a7bc49.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7985f5b404bc`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / paraphrase / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/dbb8d9edb3fd1d476679366e11c0b0a91cc828274a4ea9439b636172ee2b4b55.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `76eae2be8a3a`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / reordered / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/language/language/attempts/b063cbfce35276a44f4b178acbdf31c0ab91c12e35ccb136bca88e3ff0766a87.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b982c6b4b62e`

`difficulty-89b1e300bfbadfa2a68b697d-repair` / reordered / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/7a34fc46e9c8d2fb56536612c157a8c7e30824a44d04f3d3edbeef13844e680c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `579f2e4c9ed6`

`difficulty-a29114c9c66571386fb90095-generation` / paraphrase / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/language/language/attempts/a8330451905019c498fffa6116c6add934ba13469e35a6fa2480a17569090069.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5ed25ed5c250`

`difficulty-a29114c9c66571386fb90095-generation` / paraphrase / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/e56d1b2518e0e89860b575200b602d53288907c94b16b7543024c35a9e989b03.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `09ad1cd8abf5`

`difficulty-a29114c9c66571386fb90095-generation` / reordered / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/language/language/attempts/d70cc18706ecfe15b866576b2ee4bc5f25731f62153b2d9eac41a273201ba52e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `084cc9246293`

`difficulty-a29114c9c66571386fb90095-generation` / reordered / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/98b6e2d437e48c3e7016abad1e050cae4f9aa070d0813239cf268d9523ae9a0a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `509c725b24ab`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / paraphrase / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/language/language/attempts/cc6fef38184f48a097410087d1c59b73855c5feaa381aab35c424d0eec1d1c93.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b3f33cb67ce1`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / paraphrase / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/7809aa6b654d659d45785f613428f897ef5bedad0613c2e5c094cca8fcd6ecdc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cfdf122554ec`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / reordered / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/language/language/attempts/76d3182cbd3ced86cac2d17705f66d9aa9d744aa05b182b07c055032b9737a4a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `75484fd5faf7`

`difficulty-a3c657c260a8d9be7aaf0f9f-generation` / reordered / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/a55642a1c1a98f55917e1f6dd2e33887a92bcd7a99f1c45c93665efb0ab27230.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2bf6baa3582a`

`difficulty-b2b00bb2823346f5b73abe5a-generation` / paraphrase / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/2f496923864863bfc5af871a4df0e869b6d9e57d8c2acfb317be6918ac023171.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c51db4b795df`

`difficulty-b2b00bb2823346f5b73abe5a-generation` / paraphrase / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/556f513058fdffff6ad102ad1974c3461dd89279a3c30075fdb73eb4c22daed1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c93d1b4d8c73`

`difficulty-b2b00bb2823346f5b73abe5a-generation` / reordered / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/language/language/attempts/4319293d4b09ad6f05a6344dda6e4da9379911ffdb56920b130eb70ddac09a76.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `921ceb57d1a4`

`difficulty-b2b00bb2823346f5b73abe5a-generation` / reordered / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/language/language/attempts/32c56d7ed90bdd48e9a5a66a2b58c026208b31c208ebdc694385fc7a12f51265.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7ee1fc7ad44f`

`difficulty-ecdd584a599de7b78799f3dc-repair` / paraphrase / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/language/language/attempts/fc02e2d145d2e34277f5d07272e6c6a71ef7c8cf7eb566761ac6a37192a7102c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2e59de9c52b1`

`difficulty-ecdd584a599de7b78799f3dc-repair` / paraphrase / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- The extracted frame or activity set differs; schedule witnesses cannot be compared as the same task coordinates.
- Attempt record: `runs/language/language/attempts/e9a6914e55442fa79483499dc6e34323c9e4771eeb7c15c598d75f599286fece.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7730247c4f62`

`difficulty-ecdd584a599de7b78799f3dc-repair` / reordered / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/language/language/attempts/9cb06f475b50a0d52b214100a5be328cd64c41bb4fc5529e751da7e722790c44.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bad50ea13c56`

`difficulty-ecdd584a599de7b78799f3dc-repair` / reordered / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/language/language/attempts/e848e3307d7dbd7c74fa1589b78820f50f9904c75880c89f5895f9fdf483db0f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aba614ee8e6e`

`difficulty-1eeecc1c31e18b501ee559c6-generation` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, horizon, participant_availability, resource_availability.
- Attempt record: `runs/realistic/realistic/attempts/41714020df96e2b9fb9b203e4a0526d76d3bda20a777da7cb8a7f85e541767ea.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ec0177772a00`

`difficulty-1eeecc1c31e18b501ee559c6-generation` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/964320c3664c3587ed3286fa51dbca30cfe3c0def81c7fb2400fe4b2584dadf5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `24d9ba08c4e1`

`difficulty-1eeecc1c31e18b501ee559c6-repair` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/realistic/realistic/attempts/85995db67c2eca0f42c8981e5527f508833e44705046d948eace64d66be4cfe7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5dd481d8fa93`

`difficulty-1eeecc1c31e18b501ee559c6-repair` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/76b4705d86dde4e33fc5f4edfcabe93c16afbef02f6826fba6661f81f212ac79.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6ff36ba2451c`

`difficulty-36b286bcee4ce1613f31a350-generation` / canonical / direct / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/0afdb137bed5dbb0885961febdd8cd46cd6094b3c381fd6caf9de8fa60ad94c4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `167e4e87ef78`

`difficulty-36b286bcee4ce1613f31a350-generation` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/188651d66954972c7902d3d54bbdd6b4bf150c8b521265366578f9ffb0034057.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `70b0ceda8ae7`

`difficulty-36b286bcee4ce1613f31a350-repair` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/d8b9056ae2e93d0e92286e6c23f9579ee7db058fdc1cbe62d1d18a40f77b90e7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8db53a400d0c`

`difficulty-3c3c60bd2407f1828a3e048e-generation` / canonical / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/dd38e1e30c1e4e6e09cc97f53bcc95523bec810dda163f078bace3b4a3cac342.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5d850a9bd843`

`difficulty-3c3c60bd2407f1828a3e048e-generation` / canonical / solver_augmented / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/227762794d73f285e38d6cac2e8ad28848da4a220bec2da97cdd904387fd1ce4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `93d3b170aa81`

`difficulty-3c3c60bd2407f1828a3e048e-repair` / canonical / direct / moderate. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/realistic/realistic/attempts/3a61ec47c92a1e96e8d0fd55a2d15097ecfbbb6d3f52b9f0dc3ea9aa5f799758.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `30ab8fac3735`

`difficulty-5d519fe98da0884fdc03f3fa-generation` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/realistic/realistic/attempts/5aab7ba5cd2d38d421faa4281b3c60484434756e970809541da5055689e75802.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `56317df2ca33`

`difficulty-5d519fe98da0884fdc03f3fa-generation` / canonical / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/596da9047c90db55ae7120e29631874383da84037e3c39c6430ea17c76028339.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `efe1056bca27`

`difficulty-5d519fe98da0884fdc03f3fa-repair` / canonical / direct / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/79ca87465507ad06c64fefd4dfc4607b296d869f076545b33bc02d2558fbce32.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `54fa3b821ae7`

`difficulty-64036ef2c2a26def2f56786b-generation` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, blocked, horizon, participant_availability, precedence, resource_availability.
- Attempt record: `runs/realistic/realistic/attempts/8dc715888972e151bd8ba13b89a884df09f72875d8dc11904fd39b3a6e9fcadc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f5012546c964`

`difficulty-64036ef2c2a26def2f56786b-generation` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/de7424bcfd238354c935cef456cd8569c5f3cb7856fc2ce621fe71d9b729292c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `03917e98b4b5`

`difficulty-64036ef2c2a26def2f56786b-repair` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/realistic/realistic/attempts/7f02b745c5f602dff824bbdba5e6c2bc3276307104c81b1f875a2acaa08c9f4a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8e06cd5f43fe`

`difficulty-64036ef2c2a26def2f56786b-repair` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/0e6d427c134b710dab4e002e1d5050a523a792124ba712832975647957795db7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ca0d4d6284be`

`difficulty-6a05feedb643dd0d66ed41ae-generation` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/realistic/realistic/attempts/1c60edae9787c71c07ef0aa22d84ea0265f4575841684764c8f68caec66a82d5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `23aec7a270f9`

`difficulty-6a05feedb643dd0d66ed41ae-generation` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/47947af86fd4e5a594ddaaf8901b73f83086fe5bb06b8db3aac1ec4ec2784336.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b60d240ff3e6`

`difficulty-6a05feedb643dd0d66ed41ae-repair` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/realistic/realistic/attempts/ef6651457ff483f8c80c89ce5c25b24f32df48fc1b84c854ad05ba306e4c121a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `64176b89677c`

`difficulty-6a05feedb643dd0d66ed41ae-repair` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/a377cd8cf6d118a28ece51584f49cd145722d2fdef9ebff8a646695bacb1c385.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `68503f17a637`

`difficulty-6dd38a35a807f5693336f267-generation` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/realistic/realistic/attempts/e07198333a59a92af56cabebefd930758a951b5b1e4c93d5a823e3f210fc0bc5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6bda215f1d22`

`difficulty-6dd38a35a807f5693336f267-generation` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/6158a508f82dbd69f6e4bc271ceaa4555b1a934d3fe7368c963e6f43d8960c4c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7cbc938c224a`

`difficulty-6dd38a35a807f5693336f267-repair` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/realistic/realistic/attempts/2b8b7a96e76e1f57211c92025c3dc0b805f584c94dbb96970a7e708f745a26ed.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a35244250970`

`difficulty-6dd38a35a807f5693336f267-repair` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/29b03865727ebe953323fa619171f3cc5120929cae6da756927d3ca22966d5b4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2124f1d02af5`

`difficulty-72ac5a2069011da65b217c82-generation` / canonical / direct / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/30491d0c4b1777178de28463e98db7fb300bed6afcb1ca5d5adf11e5ac64ba8c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `724e73ccbf88`

`difficulty-72ac5a2069011da65b217c82-generation` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/1f6cd805caee8c74b01020e4a3c619bb506b1318d236e1fe0455d822c0a286c9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6331bf0f07c8`

`difficulty-72ac5a2069011da65b217c82-repair` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/realistic/realistic/attempts/2fdc12631afa37a0a1dead847c0cd1a9cb0e6ecf4be4778799ae5a0c6896d649.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2b337fb7cb13`

`difficulty-72ac5a2069011da65b217c82-repair` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/realistic/realistic/attempts/94280e9e778e4b0f5517e5fa6a0b1d4e6850b2ca61a6bb0b300cf9bc298df6a5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `77e9e104f065`

`difficulty-dbfbed7cd7af66cf37a53817-generation` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/realistic/realistic/attempts/6143e8e4b4c6f13db1d9c5a0842ae471ee1689eb122571d97e6d5cca4dddffbf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `40191fd90c8b`

`difficulty-dbfbed7cd7af66cf37a53817-generation` / canonical / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/realistic/realistic/attempts/849861433c78d2bdc8f78e4df7f6a38787c75fa35c3dab525e21953c1d11c19b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `97ceb83a2b81`

`difficulty-dbfbed7cd7af66cf37a53817-repair` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/realistic/realistic/attempts/cef47957a720c804ce2e5a9ccacdcdc53796a8dd4fc9e771e4fba589c6078440.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `090628d13e58`

`difficulty-eca2aa698b8215bc8ffccd74-generation` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: blocked.
- Attempt record: `runs/realistic/realistic/attempts/c220d86d4cdea02ab2b05917b2c6e7567af842146baa199af178e300445ed4c8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `05f9d6053b06`

`difficulty-eca2aa698b8215bc8ffccd74-generation` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/realistic/realistic/attempts/3b9c625c8ccd16022d0f8fffa8c0c811fbb45699d05adbe96808f8fc13ba2282.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `834245e98a77`

`difficulty-eca2aa698b8215bc8ffccd74-repair` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/realistic/realistic/attempts/b770df4f403f4fb6de7043b1df706e1a6f6a9b21c497e983a35115d217088b0b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f03ad5242030`

`difficulty-eca2aa698b8215bc8ffccd74-repair` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/realistic/realistic/attempts/ed384b4fc4835263ce44b46bf7e2aaf249d283ce1930522419807562d8d24ed4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

