# Study interpretation companion

Evidence class: `live_development`. Model: `x-test-1`.

Generated from verified recorded attempts. Human interpretation remains pending.

- All attempts remain in denominators, including provider failures. No inference or solver reruns are performed by analysis.
- Block and tier rows pool task/label cells explicitly; fine cells may contain one observation and have no population confidence claim.
- Related renderings and generation/repair instances share families; rows across summary scopes must not be added together.
- Casebook includes every rejection, unscored answer, structural mismatch and valid nonmatching/unproved objective, plus the first clean success per block/tier/method in sorted identity order.
- Examples are selected for interpretation, not for estimating rates. Structural mismatches are not automatic causal explanations.
- Gold data in the casebook is evaluator-only and must never be passed back to either method during measured inference.

## Failure-inclusive block outcomes

| Block | Method | Accepted / attempted | Rate | Valid SAT / SAT | Correct UNSAT / UNSAT | Objective matches / comparable |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| controlled | direct | 891/1000 | 89.1% | 404/500 | 487/500 | 403/404 |
| controlled | solver_augmented | 988/1000 | 98.8% | 492/500 | 496/500 | 492/492 |

Objective matching is conditional on gold-valid SAT schedules with comparable reference stages; 0/0 means unavailable, not zero performance.

## Evidence review

Full request, original schedule, gold specification, model output, extracted specification and checksummed trace pointers are in `casebook.json`. Paths identify reproduction-archive members.

### Example `d9b7e9c9f306`

`dg-000756b15a53c687f0ef2c96` / canonical / direct / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/3d8dcf55a72b0990bb0b5e01a809e392f2abd9b3ed564e0799cdedf289704172.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cf7dc7c5680b`

`dg-000756b15a53c687f0ef2c96` / canonical / solver_augmented / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/631a6d8873682c7f4bc42b0069d81fc390481f77a39977a644672f7c045aacec.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9303e2e47bf2`

`dg-00528db31996f031dd6424ef` / canonical / direct / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/b0b40074340c6cc8f1c661de9131fe130d279082728da829c4e0bc723e5488b4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ac87f058531d`

`dg-00528db31996f031dd6424ef` / canonical / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/be0036e828bafacbe15a8e532dbe45aff929dd0b34cc29589767aa56163b6038.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `96f198f2cfee`

`dg-008bb67c4b98a343291aeca1` / canonical / direct / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/8f7f4861c41b0c0ed6abea6ee8323cbed93e02637b991a20baeb66dd79c68085.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4bd47cbf5342`

`dg-008bb67c4b98a343291aeca1` / canonical / solver_augmented / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/402eab31178aebbb7952d0d22bc7a7bb6a6d1203e267743da301085857f33f42.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `182f3bff0edc`

`dg-013f991d5d10a4f31cb7f8bd` / canonical / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/98f99341caa09efa4674ba6641f9c80fc373ec58e4fc73c4da515b3fc6e7a479.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `acf34b67090f`

`dg-013f991d5d10a4f31cb7f8bd` / canonical / solver_augmented / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/61cc8e64ff9d991a8e81760bf9ee7e460f11aaec99deddbee8bd2ead539301c6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b843ea997ec2`

`dg-01d3b0173f90e4c4ea7e7026` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1e5aa2d22f523b9d8c135e55cefc2c101dbb8fd155307fbcf457e982545af101.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `905a196614ff`

`dg-02257aa39cb14889597ecfa5` / canonical / direct / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/ffc850411795caf825bdb0347c831baa7f711b924828724dc8cc810c92628601.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `331fe5bf3b47`

`dg-02257aa39cb14889597ecfa5` / canonical / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/8185ed9bd6764bb84b5f42b2254438f81926ac49ad67534b9d8b29129c00b1b3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f1468b25d5d8`

`dg-0405b47d2aca43e4a7ec0e29` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/22bb7686a71a32166ea24519da0834b9ad7779d13ac1220d00844781ee6beb13.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `40f56348bbf6`

`dg-07679c8dfacde9ab5db16941` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/28d41cb07d3e0e78d4ec244d6603007777abf05baf4f2881a4ea155410076a92.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c8ff6681be12`

`dg-07679c8dfacde9ab5db16941` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/e1bacfc36558aa85d19189eec161f506b5ae52316c8cd45b9ab0f92073ed7be6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `62c1b7f39a5f`

`dg-07a8a364db88956122484ec6` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/5dc57ad195ff394b9e176769b0a0e29dc42f2a8b5b69032eaae37d852fb37cc9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `85770edef303`

`dg-07b6a208ad6e0bccb43b19fb` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/cea086a5ed0c698bc53de683891f0c66de2e2de282f53d55e9d44f22b5f52a0a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7064e2d2a251`

`dg-08cf4481bd3f2e519ea81f2f` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/eeb65eebb94446c74bbaa70d486bfafd276d3e4142008a932a8e4ae385a323ef.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7799e1502c66`

`dg-0d56371f3693977d89cb1520` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/c2efe41e33c3ed74c1b7b7c77c336c7ab59fe1ef1c2e5a4c0b95801531cad214.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3a9f63ee6c05`

`dg-0de48d3f1c1e28f419a6a391` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5d55606143aea9035ad932fd0457a5ee8d9e5fee51dcfc7199fd5892e31f9bb8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f6265a3a31eb`

`dg-107a7428ce3b473a63c4a688` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/b3b022ddae4449672bd3ef873468e71c3382bf338700432a7c7926218489691c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `57b6001d4748`

`dg-10d17769dcc42f998c175025` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b3193a3783c9db3d565807f8201977bfb0bb8608d1521f5b79e70b0d7ab3f266.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ddaaebf2e329`

`dg-12caa5fe1502186434731c41` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/3dc0e3c80946836166a83974dbcceba6b338a43d24ffe372aa87064e3cded04a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5b2338c1942c`

`dg-147021efe8e5b6307b38828c` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/699cf8dff5498bca1a4a6e7b1419b32ca94489c02888daa2e788f33692392085.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6e9989ee9f64`

`dg-18afdfc38a50ae7261924285` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0d2f03d1d21be3fe25753d186cebf3ee2271184f868eb60b9d6436fb3e4d0b2c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a662d7242e3`

`dg-190c0b97a1e89b5afe58b64f` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b22dc5357474176857a4d14148477bef863520453a07de8e1dbb1837f447005e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3ec868eaa388`

`dg-1cdbd7c8395bf0162913adf7` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/c604203184789f6159619aa70657492fd25e5cc2580752b4dee1dceafc9aa1b7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3858a5f82e1f`

`dg-1d65f234307ef6830d7a29f0` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/fef8b7bfdf229261f8d70066e94f9ee3121a68a94446cc8fd4941cdf51c39b04.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `653aa2b9e90e`

`dg-1d9bee68f9d1e887598a052c` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/598b55c7619c723099de144d69b00585c4b29f6d47243da400c53a16a01052b9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bdcf8819f352`

`dg-22d2eb92b21e0794f317294f` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/9a00824251dd4240b6f69992f8871eccfeee93a4613271d79e5b5c771ed5cfdc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6fa240ede54e`

`dg-24939b088a3606ebf88a4085` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/0e113542a7a01f2ca16590423e6a9da8cdfbb11b64ffba22a0f89962403147c8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `feb6de20fe54`

`dg-2818966ca1f592b51f5e5cff` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a97948a4c8389432c2048a556be2b28439584cb8268cd6a3d767d9a737d2cd5b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d8e17e534188`

`dg-2f98e4526b788589de65549a` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f74c20807bde4557fe4def98d72aee7855b6ae2033245926bdb9a9e731717abe.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `de60d7d73d12`

`dg-32d68a2ce4875e1a33652687` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/959fb405b05579ec52e8fb8d14bbf5ee661243f4749d2e08834e7f448e3ef570.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `eb623fc0d534`

`dg-33804c9155f7d7977363dff4` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/7b07fa940705fb9a3805a6450a4539f157b8a73f5da35829678f9cebdafc6801.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `65c668b94b7a`

`dg-35ee3494b3f1e748d7a427fb` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/b8546cba6a0f4b8c82d13525ad17d70a39793ee02dcf232d1d546b392f3ed309.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e93aaaf5f298`

`dg-360b5e65b16f36c124a4bfe8` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4d1a004b5d454c88de69e83bfc75926ba320a6b1b8115a67e78dc094af3c0cdb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4d1c15111015`

`dg-3aebef157b3ce766adb2f32f` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline.
- Attempt record: `runs/controlled/controlled/attempts/99e48cb50e4f8997d99201fe8f467c2ddde45c18be16a9a9151ab52cbdfe9d50.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3a91022a5d81`

`dg-3b7d86c56884daa6ef967c45` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/ca7c786b28ba764c7b4b049c8382e6d53bd7c7840dfbc42a85411cfa028eba0c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `51e54239d6d6`

`dg-3b7d86c56884daa6ef967c45` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/c9da2fe2948f564a29b336b8709527a824a5e9888770a2d06cb8bc01fc0adbba.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `143f7e5caf02`

`dg-3ba77fe69b3c00e352713317` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/330fa74ec7ec32c1772b647fc703280cae82a59f85bcc71308f2b29d3ace4daf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d6c53e6684d3`

`dg-3c2aa96007bf7681ba595fbe` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/ab7278bb71865cb156cd361531c15552b231cd70a71331b4e0f4a9e11c8e73d7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0a3a0f012b59`

`dg-3d10150669fb6252739e4d2e` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/cd7d444d1c0f048de59d75c425a5526a2f22b156916dd3efb6073cb9713a9936.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `52d69e769fd2`

`dg-3d10150669fb6252739e4d2e` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/1e76823e34d13c7ceb7fd12a6e8896e43002488220263242dee93ffdc17d6a35.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4757f7a9a1be`

`dg-3fd5174321284caacab1f4a9` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/c6e8938fded99db88efdc7a833a65b7046c188ec85891a287681a291f4a9df13.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `116282699dfb`

`dg-4075ed586aeb62fd06eed0e2` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/23f119c50ec4f1d1f55ea13f257261fc9de36997df003829b1884f4c47a8d909.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0e62d5df26ab`

`dg-4075ed586aeb62fd06eed0e2` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/9ca9fbd0475fcbedc4554ec59d898eb80fbda838bda7336c572f1a6316ed8ac8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cd55a5d395a8`

`dg-40b1643d9f0858146d439e77` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a0c993a8d13b2c81c75c0fdd098c7a4fdcd1c1491465777aefe0cac9939d2e21.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e9f6f9abf897`

`dg-416733ab3509ecd0d2653763` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0e44981e2ba37d2bfcf0081a10a2a2212e2dfc69bcffd548bf293731b04f78b2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c3e10b6401ef`

`dg-42fff357ff1c53055faf04e8` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/69034b77199d68fe5208252ac958049c0a9bb39c9a6f56058db03503efcbdf22.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3ece53a9187a`

`dg-4366fc616bdde0bb9f96ea2a` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/cb47318c904a6d00d613ff14b7259039cc1d4063d9ff2fe1ff07ebc04e8715ef.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `054db6402b20`

`dg-4366fc616bdde0bb9f96ea2a` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/46a1dad470281eb0b29f40b7060342df396adb15b9192eb67267fc682f2109fa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `199ba476649c`

`dg-4662bf55c933a4d1a1516663` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/17bcd3e9431fb23770d952fe0041ef0fde5cae65ffabece0b6d33cf81015b87b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b01b470a425e`

`dg-46cdc3e31315ea1058e00845` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/93501fea61774044ee40245493a62251e18961842d5b4e8d6b1a35aeac42198e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `808c0b0de8be`

`dg-48286e28ab65d598fa581987` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/9898ce9846a6e3029c03d7a17b3640a8e9032149e14b89c9e111d681f9a8563b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `146531021b42`

`dg-48286e28ab65d598fa581987` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/20fa07d407e162d6dea8007fb6702adf639605c54fe1fa9e6134dd8385c18e40.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b46babc23d38`

`dg-4c5286374642e98f6de15c77` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/338f8c511b5a1bd51751b3d4fa9d2231ee7085a6dedf9787423f88651592fecb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `305e5e4b5bd3`

`dg-4e5253062b7e62ffc92eb9de` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/3b514409930125409cae8d0b2b6e689121812063b54013507076b16755771f03.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a39d824d202c`

`dg-4eba49a6b4c89a5f265dab81` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/b25513c20e8df59e6d667ffa250cedcae96326a1dcd860d63bd55f2a271848c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `67c818e39da0`

`dg-4f2bc14f689d8d49fedcc6b0` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d8b174c41ff75d86ed042145c82d36ff07f45fae7e7f195b434a970e54c04505.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `09b0247512aa`

`dg-503fac68a90ff20d49e65cea` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/00e9d9bbd818055a8f06478b3a486ed227f06e89df3b48f987d846c6a0e1d05f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `eeff1afe98d1`

`dg-52896ede44c587ac456de024` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/3a16ed51ee1887cf4cfd512224428db66d31fb90146f05dc16ee3e835cbd72ee.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `63d1e5af01a2`

`dg-54934ea04c7c8c0a68056b82` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/56af3610672408838de805159fc87a4575308c6ba45f03cb616af93a40a964ff.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1e0eb34abb7a`

`dg-58c8f1767c302b67b7b0715c` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/4e7459eb53defaa9ea213fdb71682f2a2b9c019104f518456840b2460ebd42e7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `717004c20846`

`dg-58ec86e70a9442ee790765cd` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/d1712c708488f9002df00f37b05cad1c3c5eb72f91f439a5062c87bdeed3f8dd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e48c3d9d8f95`

`dg-5a91de02e198ec471a455eb8` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/13374ba1df6ef544b3b536570c70b3157b3b51f3a92d8e2c92168cc8d1ddec6e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `94f73a62c5fd`

`dg-5ae8b862f554705e31938cd2` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/47c2516596ca3a16b82dec022b0705a79f6b317f3d47e9fece8078d8bf045ee3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `af7037668109`

`dg-5d9670f061ef6bee8e1591b1` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/a1a1b4aea7eae3cc63be958717cf1b17210d66772f00ff1d04c400a0eeb88034.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7e749b16265f`

`dg-5f193a8ab9ad44c2268bd195` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/366b3e8cd8a759e1b3eb4c7b6f51618f3bc01f798ce7e79ff26df18258503c05.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `34bd0ae72ce3`

`dg-5f463cd33d17e8413b827960` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/a854ae907c3669ac779868e9e981f3ed6f871469999d7a40bd5036a3c6fabc51.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ed68fc2663f7`

`dg-5f5379e96cf1878d7141742d` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/0ec5a1a2c4604283f926aeab90811b25472df011d5867e4dc7e44be3b232025d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8a0049e76cf9`

`dg-5fa01da086033450641a327b` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/57c7bd2071940aaf5d0c19e60f902c291a2255eeb7fe01a88b311cef734697f8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c0708a0ff55b`

`dg-603695af06396a5e31bf40c7` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/58d0e9f9b1212c8e77ff2d235c1cafd77a1d3b17de9845048323a3948663715d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `021d10c5340d`

`dg-6268a27b6f889be42a36affc` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/26664dd6a537fa8ed3ca50ba7bb71d8e5d92ddcac0fa9b0f19e937f2b87dd2bd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d9de5628f7d7`

`dg-64c223fff47cc0d1ff8d10b3` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/2a07b15e709ad690ba2424e51c1c36a35ce9f20adacde48e15afe2866082cf9a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `acd2d383ef6e`

`dg-663aa621a323c2c4e272b208` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/697c3ff94ae80c6de4fcd54425b17165dd96a29e91a01eed16c2990c259301ff.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dbfd78f2bdd1`

`dg-67258575c2ac0a206828ac2a` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/80f1b5b5ebcf9d2d77d42c4d6007411fd14ae6ba80a0c88ee19046be7c0f9a9f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9b7749c8eb69`

`dg-67b2c46790316d3205c78460` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/7a9ea5750fc435abeb1c20346014511f473ce73ad556e231b6f6341caf44dcca.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e613ed6cb9d6`

`dg-699a2a6266af7a8a21e17ddc` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/b3d7367f83d6c3525f6a7d6895d07610fe1dfac4cd068d1aca240a9630f5ea2f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1988d339991b`

`dg-6a31c9b60713bb2939ad4fb6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/9b1dcae46e7a5cf8db6f375d2bc7974207e54a6db95c0bdb7b3af609c988f0c1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c9c02cd773f9`

`dg-6af99b4a6c0b37ca8e5d24fe` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ca9c06c92f76e66addbe3981054e83ac2c83bce1181c6d6785a3e9f240e633f4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `58f88ce0dc9d`

`dg-6cf52465b5f7d26eddef0d7c` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/2a3d7fc421780d68be631a2a1ccc0d82aac8c742ae1417bab4b7342532faffd0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `46deeff1368c`

`dg-6d0f55e376c810e3051d98d9` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/544c43f23c112184ce0ed7cca552b65c0b153d2beff9f1d118c76b656ec01ec7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1d900911540f`

`dg-726c944fe360956afda5e0e1` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/31a76b239388cc3e99e0de15bd529f7b8da2ee1add692bb6831a2e340f3eb113.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c13a71a38574`

`dg-729950e61e6586880d57c394` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/4f11769b7795d9874bd9cbdd2490848b0edab43ecdf4cbd665aef54352b179a4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c2ed79059f8e`

`dg-736531568094c1a2a3443951` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/9eb33c9b14de94f91f0bf2b6e93b21d198a16a6d5e355d9adf3a66e671921132.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `22924faf473c`

`dg-73e392bd2fca692480fb2f34` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/0f78934b4fb9dee3a1f0e66b3a5b355af84469c33d2d2a0a17495f992a5e1afd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `278073fa5b09`

`dg-73f70a5a1ade78f5f8cd9d3e` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/c6c46efd827b7adc0f75da84712a720150e0dbd57cf1f3d005e50f829c2d0703.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3265a353c556`

`dg-7479c7cc3fad01034248c9c9` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/3db4d588ae9dd5ad8d8b47f687936bd6491551ec0e4d66d7dadf539b49eb00a8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fcf0cae6b3ce`

`dg-7479c7cc3fad01034248c9c9` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/78a294043714695d187afe938f50723a5ead7af614c58354ecfb664a467747ce.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c19dcc821a7d`

`dg-766b11e5d24dfa4cd7e91d85` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/fe2998501069bdbf090af1277bc6a84e7b05b7b61923ca8ebfdaf12b415f5e57.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dab75c3f9200`

`dg-7acb6d444888d8b78495dc84` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/1a4d54811ce4987520a7fd9fd65d6f9cf5b0fccc5fc94c3d1237ba3ead3afe17.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e9db334e175e`

`dg-8031630cabffecc6fd3e2c73` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/29cca25b193ad1b50092774a30cae1b01039ad278720a0662b59efda22a115c9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `29eb379a88b0`

`dg-82b5b412c5ce9021546cf62f` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5334f05253fe5e3158a480f292cde399391c4a3762ff57c8ba9515662d28a27c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b37f23f5e278`

`dg-860090e1e7800d60ec03f976` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/f9fc4055dfd2127abc61b61bb7a69464f85c9430389cd767d7d51706f4133c84.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `70df694f2424`

`dg-8725dfeb182caa8023ca4c2c` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/b1442cd36532d93cf08f029349991a55557fe9e0f3b6c26ccfb20b49dc45dc95.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `498275d5eb86`

`dg-875277e61c42ff9407492b3f` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5e998427e53721f5a25bda6ddfd22c2ae91c45ea12c64941b6b98e1cc33e9ac4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9685053105dc`

`dg-87c547bed8416a870938afbd` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/9bb6e55832ecc964a3d3a541d2f1d9947b019bdd7525c5605741ced0e0e797b8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `73840d203d11`

`dg-87c547bed8416a870938afbd` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/1b2f6b65bda2c1181461cc54c6ca91e8cf58bd0ffc63ee44831487a2659d01a5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f8a717908d42`

`dg-88b7ce630577caef75e80a62` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/214fcc75b8d711dff07ba576884f7b2466a7130804e55ad1b3554995d7fe2912.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c292cb5caf67`

`dg-890e88c51014ca35933664fa` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/a506d8a5d5818855b9d5a170ac54491654881781411a0a4bb781c91732e8dc90.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8fafb2ccc476`

`dg-8b4ac8dcd202787ba09ad551` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/170dc173ff0efa4af33c3ee26360f318250d796b79df82f71ba70bc60010041e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1dd8c8eb1ad3`

`dg-9217be4ccd6ef38c2cb086f4` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/4dbaa03aa82133d660c5a59cbe935d489d68dce408eacba46e58771cc3c62ddb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0d37d826d8d8`

`dg-922456595da34b60fbe5a2ea` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/88bba51aa6920167858bf14c6550ff6f3be92faf7d861eef286171e1273a4c9b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `290b499e7fc0`

`dg-93645cd68c645d31d613fa2b` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/d4253d4cc1258632f7a50be19c224e354e7c37e5824dd279ef47b234e6e3b69d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2b1f8756836b`

`dg-97caed70b9a286c5c0195a59` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/6219e3b0ee912c90d84666828b0e4fffa2e6da8e50780d4d261c98f3608ba5f1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `027a8083c961`

`dg-9bbf03f41ea97890d805abb7` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_availability.
- Attempt record: `runs/controlled/controlled/attempts/56fc080073a36e02dbe39134afe8443e2ae131ef4c8d29b3114b644e63ced7c6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4e43a1a6efd4`

`dg-9d3a387ab9df3fee10493450` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/14d22a9e435acf8803700cdc2e9c1c68cda68303ed4e876b4baf8e5dcee86b8e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7a03bbb55a43`

`dg-9d622418294763463a9cda52` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/2f5c7959a3145f9374c843bc314538200ebdf45a3a6d3e8c30ebae3d8a9f338d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `17b80bc8c829`

`dg-9e44cba9c69f184fb92cca1d` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d43a05b81c98c2e9ec0692e77915088fd4ced417cd8895bfb3025fe8e8f7bc8d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d9b499d483c5`

`dg-9f4f196b93eeec7c5bce13dd` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/ae54f7b381f45f0bfac18b66a4e0bd92306a031dc89ddc6072ceabc4e1ea6c19.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c4a508007bb`

`dg-a56ab539ae67d4f196440d00` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/84e18d49e83387d5e7ad7483a33b16a5d9181f861d1ecf49788b962a2d302919.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9014e83b789f`

`dg-a6693846ff3b52109af04704` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/63036b9fbe2009027d75de35272635ef98af37674b2568678d6226b17f98f04e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `80ebb4a73d52`

`dg-a7542bcaf35f7024ab973f3c` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/controlled/controlled/attempts/4ffbbe48c36b04daae820c2d14b4bedd54de33e7e6b17caadfbb066f337f8002.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0e95b7ab6d7b`

`dg-a8d5c4bdea2ada978e3ae36b` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/4f01b1f2876b265cbf6fd57c9fd54ab11e8d697da1fdc7f3ad7b3460a62a18d4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e5dc23f7a94c`

`dg-a8d5c4bdea2ada978e3ae36b` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/562b56953c1deb97fe28c68b0056155f11162a1ae1059e29d274d364586b51ea.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4c36239953fc`

`dg-a9ca1489dd2b1c422be45580` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8913efeb00a7efa989e283e934c252c3c6a79438cdec39aaa96cfe7a8a1bc45c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4a71d927d4d2`

`dg-a9d150cf7e48546f3189b25d` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/48ac0fd2446ef301c593517b85dc49fc168871d5326b68368669310bc29a495d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `811f7a17b474`

`dg-aa8bf0e11745d4abfb8d5663` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/29ded00fd58a0dbf642555bee13120fceb0e6ee2f89b05e2c0b424cd891f45ff.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `feb0c41a3a16`

`dg-ac632709b4f5c13218b7c9c3` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/fe38db9c213e293a2b9fcc4b2dc9d65bd6c7272d47a9851bbdcd69c68474a897.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e6bfe2f962ac`

`dg-aced6e4c6644be00ffae2521` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/4bde21298a48af3b6c0f14c1fdc21e0ce3bc4048e58215a1157fabddc885a8e9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `da7e25f2bc5f`

`dg-ad42993d87d77d251f11c488` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/cdd78ef3fea4a0115fb4cdb95836ac5e3e91099cbc707ff7ee840257f5147970.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `515f65839dff`

`dg-ae6c16b78be5244dba06ccd4` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/0a4b9a387ef3fa51ee373de0a8e1c7349d9afdd76e8b7ebdefa9a2ce9923ed13.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0f80005a4be2`

`dg-aef82da290dc5ccf372d7d55` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/5846fc9ac6ffb43147b926e5cff9ae683f8905670d094090ebf36a5849182aae.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `957ceb1604b8`

`dg-af73a00580cd874b02780deb` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/a33e4eb1b5b5656705a0b3f092261bfff2e635462c4c21f465597f6c57814ebd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `10c8df4657b8`

`dg-b364054c772e1c8254bd5fd3` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/39c43a2dd6d92e49a1e448515eddf14080ac4f1b2d452b5324cc35f8c4dd87e3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f5f6311d65e2`

`dg-b3859a44cb70563808b0f3b0` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/525a71e31e2c5e2d26d7a3597417a43aaf2646f2dd7640dcf9705c106ce9861a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6108822d1c25`

`dg-b88363dea41347881dafd903` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/f4132c50c126610a3bdaef23d03d61410c55b5a7a06d1f1ff50f86dcd99d405d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e7d3ecea6096`

`dg-b8d113936266262772942444` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/1ce30c2e8bd695edd11750e67ab55fd4a1cfc2a7b4a56cc00d099e6c6322eef5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a1edbf3c8384`

`dg-bfd3d31c67805bac350ebeed` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4b49653981cd300f2acbb8e9b7ba59fe24772442722c9b061d8529e2bb4d4795.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6d02f8aab7ed`

`dg-c25f19b05a638c418aa778f5` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/86425dbf5b437f24a9d448ba7b4b1cc81e5614e59b060c180e225468d9f02212.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ffba4929bd9e`

`dg-c289a32efa923d0cb3e54748` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/fbe9e4dd24c557a924b1f87cc54f727465dc2c6d51f5e334ec2009c269a700ed.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1008261c9a40`

`dg-c6530b23fb34c31a28d71b15` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/ab2c8f819a277b08af54a3e893a99e3af36269681e99202176c078aed011eed8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4360e76d82b4`

`dg-c6b31eb54818e334ea72e991` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f7088f2d2e789de45b2db888a7314a050969912761f98e522245319903b20182.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f7ae40b5ada6`

`dg-c7924c0e5faa9720705ad359` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5d56fa57f5023a14501cc521ee7a676db2e1756ac03a9131c3a181aa7540c6eb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d854e28d9432`

`dg-cddb9f6eb90fa67e9d430a3d` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/e6762a2fa9e9ff1c453e93adb932503ca21faf24fb383e0266a040dbeb3047dc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d746510f34ad`

`dg-d5413808c6fd5f890fd91872` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/850ace437f049ffe382d2394021ddb2425dd575a8793a48b6035a341e96f03e2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c939a140ef8f`

`dg-d6195ffb778aa07c166e50e1` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/188ad297524088a0b20a7c68a905e283c4321b6c73a466cad537d26af1c11a3f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e8d81c8c6aff`

`dg-d620f51058b6be4f6e27d2bd` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/7b5c205570f659f2be839593ad92a93ef10ffe8b2c1b8a313f2f66e2861cf6b3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `46398c06f8b9`

`dg-d678ef1e10e835c9f3d4bdcf` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/2fd77b63389c4a612cc393f8566e8db14d66879e12f61a95327dd8f4c63ed2c0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `931c373ec894`

`dg-d70ba58f2113f6959d0b429d` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b422238880ec7f98587cc03d757e8bd26381bb996ac14fb3cdcb6ef424ccddeb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dc6ca889dbd0`

`dg-d9b38f402e0bdb0130f64b07` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5408aab6b534acf6f0cd58656e8ce7a24adafd9b9b71ffb116da31748584a14e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8d704999e812`

`dg-dbbe4930940aa03aba98fe0b` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d5e21966a38cac7b556b787d2ddee1255141bb1bb38487c60d3e528713a4e9c3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b2b183fd3083`

`dg-dde5eb5b79b0833507d4fdb0` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d4d42d430ecea1d8edc05c429fc39a1ba453ddc6841a86332916dfff6ac11593.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dd5899266b2e`

`dg-dee6c10ab7ae5f3e7938c11e` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/72d8fc29d6dd3b0c80525231eaa31c900a2536aa275db55ad6e7f11835e417b3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2f649c1e76d2`

`dg-e52a25c547a835778b9daefa` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/ee95261e51c34fd2156961e30066821630a1b57c210bfb17001eb2c9930eed2b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6f0c8ed99bda`

`dg-e53c3c76efaba24dcd5335d8` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/dd2bfce47fe34bb50073cdc320d59c29bf8774c7bc53b1a1d1afab87eb83b7e0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7409f02b4645`

`dg-e5b2846c84e02d62af04c011` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/9246f3d374428811e37f355abce30e3c4957f45c77ad5af9043321c9986154bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1233f388ab81`

`dg-e5eef8f569bf0db9ac9b9697` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline.
- Attempt record: `runs/controlled/controlled/attempts/ac76efd273e63deb60bf4a68038977038549a1364d5b4cf465955b0b7eeafdab.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b5fd9e0785e1`

`dg-e725547d07aa87b40fd3bb27` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/6676406e2ff2d16a5571dd718face8934b0a6a0e1663ccc929e6e6fdf91d2be7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8665b2eafa1c`

`dg-e740df0ee42437ef05f28303` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- Attempt record: `runs/controlled/controlled/attempts/b55430050a93ea67aa9f1c1e312fd9f52991e0d1bc660524bde600e00610acbe.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `04027aab2591`

`dg-e9882b4ad6123116c94d16d1` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/82a9c0b4f3aaccad34140a83d2560bb01b6b5dff6447e4170029d16e70d9bc71.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d41aae2e717c`

`dg-ea441dd2da2e12ab7fb096b6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/9d85f5930e175c7a16bbe0346725c6c65bbf09eec6b18b9de92239567e3c7d40.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7c06acb8fbff`

`dg-ec65abafd16d975ffb5812c5` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/1efe34a9b8cf8eaec50df01ecc9310cc78719221b07bc911b487163f60fadc1a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1652b1b941bb`

`dg-ed26ff14cfb03ca08a920814` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d2137cfad9b23c2eeded733feccd2df4513bf6808affa1fe8fb37831078c1ec6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cbc2f57b943a`

`dg-f097c01f403cfba0107829b8` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/88623cd493235ce1087003136cf3116ba6d21b45df274e8748c955bd23bec4cd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1a22672d720f`

`dg-f171b04f3df9c26faf120098` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5aa8142cfe219efc56a04a49b508546e6ba21db6f348440a9559f601eb6984b4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c0d944dcf776`

`dg-f1e0981146fc68084a239eda` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/181ad4f9a7f1c3d6528b010077e9891e791fe6af9d90212231c314224100383e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f82bfe8326a6`

`dg-f31992a173115f196f88aa20` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/f24ef92ad093803c828930670e93c5c1582bde19c88904a7564762c42f6c7411.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e5fabfb12085`

`dg-f3d6914bf2ccfdbc898573dc` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/daffc6aeb7cf259961097d3805d50bcde565a00d8a25cedcc3db95ba83a2c9b5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `409a7c081f9d`

`dg-f68903b409b4ebf5a51b561e` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/79d18a55625e295220331fa10b2fd196c60ffe6f5da921b12f0e2e5a6e9f8176.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0d1c7f7780b4`

`dg-fc4494d2ecb71f7bfb46ff7e` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/a4f280c25bd159c25ecaae4420dd68a3f49da5b76007138eaf1d147edfdae5b4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

