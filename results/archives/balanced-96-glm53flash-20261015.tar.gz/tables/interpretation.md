# Study interpretation companion

Evidence class: `live_development`. Model: `x-test-1`.

Generated from verified recorded attempts. Human interpretation remains pending.

- All attempts remain in denominators, including provider failures. No inference or solver reruns are performed by analysis.
- Block and tier rows pool task/label cells explicitly; fine cells may contain one observation and have no population confidence claim.
- Related renderings and generation/repair instances share families; rows across summary scopes must not be added together.
- Casebook includes every rejection, unscored answer, structural mismatch and valid nonmatching/unproved objective, plus the first clean success per block/tier/method in sorted identity order.
- Examples are selected for interpretation, not for estimating rates. Structural mismatches are not automatic causal explanations.
- Gold data in the casebook is evaluator-only and must never be passed back to either method during measured inference.

## Failure-inclusive block outcomes

| Block | Method | Accepted / attempted | Rate | Valid SAT / SAT | Correct UNSAT / UNSAT | Objective matches / comparable |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| controlled | direct | 47/48 | 97.9% | 23/24 | 24/24 | 22/23 |
| controlled | solver_augmented | 48/48 | 100.0% | 24/24 | 24/24 | 24/24 |

Objective matching is conditional on gold-valid SAT schedules with comparable reference stages; 0/0 means unavailable, not zero performance.

## Evidence review

Full request, original schedule, gold specification, model output, extracted specification and checksummed trace pointers are in `casebook.json`. Paths identify reproduction-archive members.

### Example `3450b18595c8`

`bg-071dcc04607137c07c53df2a` / canonical / direct / tight. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/f2a70f5dc97874538c79f8e60dae302a6884fa34be4846ddb8df0c45e79b7041.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `eeb742dee2fe`

`bg-071dcc04607137c07c53df2a` / canonical / solver_augmented / tight. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/9d29a534b315bf00be012408b8681d4a8bf6810607ae0f7ec39b5c24477df4f2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `68086e78edab`

`bg-128cfd1b3270276c03271cf2` / canonical / direct / loose. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/eddac950a98750cb50f8ee1441473761d78f4d4fd89df3186d28fecd9dac4def.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `da696325c952`

`bg-128cfd1b3270276c03271cf2` / canonical / solver_augmented / loose. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/3cb597140e691d6d0407b6e7c5613663b26f8040fe01474fdedab82ab74d0cda.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `acc9070aa65f`

`bg-12b4e9cdefec3402d2b9c0fe` / canonical / direct / loose. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/controlled/controlled/attempts/9e3353122938995bd9b73445e8a0aa2f0e3619c07d28f71b373af8f6db9c5b46.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5b8b1585ced4`

`bg-9ff6d130d56449866109a902` / canonical / direct / loose. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/59c4e2f919930a45f56e0d21ec9140c75f5f008448a9270cf79639fbebe5d23b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

