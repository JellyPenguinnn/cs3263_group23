# Study interpretation companion

Evidence class: `live_development`. Model: `qwen3.6:35b`.

Generated from verified recorded attempts. Human interpretation remains pending.

- All attempts remain in denominators, including provider failures. No inference or solver reruns are performed by analysis.
- Block and tier rows pool task/label cells explicitly; fine cells may contain one observation and have no population confidence claim.
- Related renderings and generation/repair instances share families; rows across summary scopes must not be added together.
- Casebook includes every rejection, unscored answer, structural mismatch and valid nonmatching/unproved objective, plus the first clean success per block/tier/method in sorted identity order.
- Examples are selected for interpretation, not for estimating rates. Structural mismatches are not automatic causal explanations.
- Gold data in the casebook is evaluator-only and must never be passed back to either method during measured inference.

## Failure-inclusive block outcomes

| Block | Method | Accepted / attempted | Rate | Valid SAT / SAT | Correct UNSAT / UNSAT | Objective matches / comparable |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| controlled | direct | 6/48 | 12.5% | 1/24 | 5/24 | 0/1 |
| controlled | solver_augmented | 48/48 | 100.0% | 24/24 | 24/24 | 24/24 |

Objective matching is conditional on gold-valid SAT schedules with comparable reference stages; 0/0 means unavailable, not zero performance.

## Evidence review

Full request, original schedule, gold specification, model output, extracted specification and checksummed trace pointers are in `casebook.json`. Paths identify reproduction-archive members.

### Example `3450b18595c8`

`bg-071dcc04607137c07c53df2a` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/6b140c7b827a9c46aec3c62137c640779968de3b27b5738c36861e6dcc254c29.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `eeb742dee2fe`

`bg-071dcc04607137c07c53df2a` / canonical / solver_augmented / tight. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/9a2e647c851b6cae78b28073418ae22b890f55c5c16ae9392b40dc67f8a6b644.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0c630f49a1f1`

`bg-0824ae608cf81588286f221a` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, resource_availability.
- Attempt record: `runs/controlled/controlled/attempts/b9b4a71f0a4fea538dffa365100de4ec73689dd3d79df14a9e1aad574da4dae4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6ca4b83f4bd7`

`bg-10477314983bea4e48016514` / canonical / direct / tight. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c1cd329c90976b852cb810e23a0f92e2b40286c746fd97d2429fa8d6c2e10e67.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `50589decfb60`

`bg-108156c83e77add94a2b787b` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, resource_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/fddb857ffd39f2ac9ad291d7f194f68b0fe04f64ad1e49673921720dc4adb6eb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `68086e78edab`

`bg-128cfd1b3270276c03271cf2` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/fa3e291aa7991d255ea5a07a4ea0f382548e484f2f141ff04d907588563090fa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `da696325c952`

`bg-128cfd1b3270276c03271cf2` / canonical / solver_augmented / loose. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/a8980798d0087378302dee344cfae8f9d90d188ba5bb521b6514e082042f5252.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `acc9070aa65f`

`bg-12b4e9cdefec3402d2b9c0fe` / canonical / direct / loose. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/e602e2e6e6f381bee416de12063d8e0e2981829ee7bc71354218dd706b2a842f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dfa18eb880f9`

`bg-16c5eae861dd22f2242844c5` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_availability.
- Attempt record: `runs/controlled/controlled/attempts/4c5be6c8b1403339434f94933c942779f61a1e48f55c71c9afdf6cd1d9055bdb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9b5cfa526672`

`bg-1fe3b420bf72f3415f88e257` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4af02b4353ff9c7af6f91de353d518c1fd6ef47182a88b92326c4cf75c1e8d13.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d0c5f6ffdc39`

`bg-2140243dce583289146f193b` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/c7e0fa0a8f768b88cc3661b0490caf487012640b9c04502bf4ea846b8ae7105a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f3e6c1db4626`

`bg-23c3fc647d9f0639547d5890` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/3467335db2b25137882f377016f1d5af72a5a51b286df6c5e759c8655c0e3168.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a4bb554cd36a`

`bg-24224451a9e67d3fb5a7244f` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/647d92807ebe750c875b44c0e5ab879f7b6acd6739e0ed41ad7f435c4f7fd18a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `be42293170f1`

`bg-27ce2a35b93fd474e882d853` / canonical / direct / loose. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/93c2128d54b5ecb90f6675851978f5fa23913db81cf8e18c14683a09174e2429.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f319905ddcd9`

`bg-29795705c03252b4bde9b1c4` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4a10a07c278765f2421d6f3476ec1c1360b10348c60a68ee5e7d7eb2ae2fb701.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fab9b2525251`

`bg-34ad8e4b6d4fe8f0cc1c284c` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b3adf1db71660f0c3aa785ee31d65ca2c81fdefa3da473d7869d017055fd8a77.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8b7c1f404106`

`bg-3d7595ababa66702605e4f1b` / canonical / direct / loose. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/324bf8c4051516cf07313ad9ebab49a2a4a4ea309c9557c764ca39d10459b824.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `29cb1936c852`

`bg-3ea5d3c02d448221be33ea45` / canonical / direct / loose. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a27cf99f93baaefee441b733af2f0d670751fa367a7222a6a57599ba1af05c44.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7d1f4974b579`

`bg-4820d9a82a894a3384266377` / canonical / direct / loose. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The valid schedule is worse at a proven comparable objective stage; primary acceptance is unchanged.
- Attempt record: `runs/controlled/controlled/attempts/9f0aedc8ee0008e052dfeafa2f98d43ee4974b5c66e62a476246d308fb34ad67.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e9622c79949b`

`bg-4948a92cae2f9a3b5671cc17` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/93ce23a6909ad994ea9e15606750f748cb6ca285ad2c8ee27d723102c35e680d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `79599517e8e6`

`bg-4f0912309f2e645f7f5cd0d5` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/26057f625026e356c0cdcfd4bd08c31b784973622d433a266226bfb3b6bf03df.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d21f84ec7cab`

`bg-53760a071a5cd58eb564d0a9` / canonical / direct / tight. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4aeb39ed613772165e65fd85387e57e795c2ebfb8a5566989833ba6d95bae255.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `50b7df9e45b0`

`bg-5578dfa785c7e6f8e2164909` / canonical / direct / tight. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1680a1902c09952e0f6ff448182b7944665a994afe3f7ffdcf39481270b5bb74.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `71e40c6af255`

`bg-6fd590ba9ee4c020a69b9fd9` / canonical / direct / tight. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5a7fed237316db0d05bb48ee46343ca445327a616d1be77754b02ae8dcf857a6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `af62f6c56981`

`bg-84478435d7ce4063d58df31d` / canonical / direct / tight. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4f7c15012d2c057b68d03c4033e812f133ed718525c9515864abea7c1309f42c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9943f757c18f`

`bg-84784c784ab8bd0152efbff8` / canonical / direct / tight. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/60ad6651830d1a18640a91953854403e42b023acdd78651290276be614ab13bd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9b5a24f2fb54`

`bg-89136cf520f1b9d22e2adf5c` / canonical / direct / loose. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/9bff945047ad90cc93f91ec1f0b292c7e3141d3039ac6d6c0135a84acfbbe664.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fc86f71187b7`

`bg-95559b011241ecc5fa480d29` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/8c83ec778662bdbe7f99231fd334be56c70760e35c990f56dfa54e3bf08794b8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9fd3fba696b2`

`bg-9bb03b7e102b9e3403fde39a` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/811fb32aadd0dba2c1fdeef5889e05e762e92a2b815d953674eefd3f3758731b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5b8b1585ced4`

`bg-9ff6d130d56449866109a902` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/41f33aa021c8faebfc8713981c9a91468a789145be228d36ae9fecd5dc4c7ace.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `42bb87ab854b`

`bg-a23589fb7f9b474554fd8e04` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, resource_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4112509310801872c61b7ad85b400f196a0030860ed3609329f85e5e0d1b5402.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `62e0b28bad3e`

`bg-a853e9188bf38152c6594daa` / canonical / direct / loose. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7ed32586eee4ce6bfaa91dfc3c001d385a00f3eaa45b7e5e07bad8ffbe2b86ed.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c3ca72db4bf9`

`bg-ab0d778a76c98f1988bf1309` / canonical / direct / loose. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/53d4cc0876f3a056a39eb39febfb77ff1099de60838c0d496641b21f97d19536.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `efbf2110eb87`

`bg-b281c248d68c03daea061ae8` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_availability.
- Attempt record: `runs/controlled/controlled/attempts/26c354731196a130583a9134d90f06fb6c76d69be8292559ec1ffef7bc4f6952.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `948991c4fa39`

`bg-b469d3ef19d9d8995283b305` / canonical / direct / tight. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/c8df6cc315ea9efd0772ada4e814ae6c2f4a95f664c1c00267f780f7dd05be28.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e603f04e5f43`

`bg-b6eb9a5bee2b24636d9ee2ae` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/61f7a2e9b9dfcdb5e80864a134f48ba58d014b838cd58ab64b3d2cb4302a234e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e4d28d4e32f5`

`bg-c1a3f3a9c2b04f1314b15b75` / canonical / direct / loose. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7ee7aa49f1445e7e4e0e4eb67f45fcf8fbb28424a848dfffe16c2ff5eea09d44.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9e0ea0419456`

`bg-c2672be102cdd7b8c07d76a0` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/ebdae0164dad787001da45cc5c5f517b0af7b7e374858c1c040ce1ff9ad09a00.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5ebd83126b31`

`bg-c90eebd9a63f7c434a84c70c` / canonical / direct / tight. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/19245b72a87dd20b8c1562c3879a4f39e3e23f922e1ea614aba5f9452b62d3fa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7c6c5e1dd390`

`bg-cfa091b20ee13c21f814eb29` / canonical / direct / tight. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5956440a9d224331fb4c6585a0bd6b79fe9acb7286b27f28c002f2edd0c1c809.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9c6ee36e41e7`

`bg-d4461dc2d88bceb66bc06162` / canonical / direct / tight. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/db6f22d341e2c6c4df6fbe149a609ac1f33bbfdfe07ca27ce7405438cf1bba86.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ec787055113a`

`bg-d7cd00e14d4a86bfabfb58eb` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_overlap, resource_availability.
- Attempt record: `runs/controlled/controlled/attempts/0f83a1d9e7e59f8d029d23f5581c09ae472167f23a81acb16ac78c9bdfb5e651.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c12164ae58e9`

`bg-db4548a1c4755adf86ef7fd7` / canonical / direct / loose. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a93aeb3bf4ddf306377ea7cd8da5473d2a375022e7c7af427a1b09db1fa27a9d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `df065c554bf2`

`bg-eeed3761aafff4a64d7b8d4f` / canonical / direct / tight. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/683aff1f415475de5e5280c4b9539b340f8dd29f4f74b9c5b002122bf9ca2ef1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4f4fc45fa4bb`

`bg-faa2464aefa6e9c5de3b771a` / canonical / direct / loose. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/2a92d5b64bf6dc463dea5f6c3f476d65a566e2494335a0e034a3e1385bbecfd7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cb2e83d46998`

`bg-fd277b06955143dcc9adeb49` / canonical / direct / loose. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0c5b41bb729a6e552b7fa637eeacea0b4942c79083452f6320d469be2d4cb837.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b375d9e72f0f`

`bg-fd978e6bc0f7000ba042ab8f` / canonical / direct / tight. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b7573b981316a14108fbb3892779836026503932ae8a9281698e3c11e057ffa4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

