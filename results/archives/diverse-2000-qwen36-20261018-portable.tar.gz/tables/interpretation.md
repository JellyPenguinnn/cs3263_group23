# Study interpretation companion

Evidence class: `live_development`. Model: `qwen3.6:35b`.

Generated from verified recorded attempts. Human interpretation remains pending.

- All attempts remain in denominators, including provider failures. No inference or solver reruns are performed by analysis.
- Block and tier rows pool task/label cells explicitly; fine cells may contain one observation and have no population confidence claim.
- Related renderings and generation/repair instances share families; rows across summary scopes must not be added together.
- Casebook includes every rejection, unscored answer, structural mismatch and valid nonmatching/unproved objective, plus the first clean success per block/tier/method in sorted identity order.
- Examples are selected for interpretation, not for estimating rates. Structural mismatches are not automatic causal explanations.
- Gold data in the casebook is evaluator-only and must never be passed back to either method during measured inference.

## Failure-inclusive block outcomes

| Block | Method | Accepted / attempted | Rate | Valid SAT / SAT | Correct UNSAT / UNSAT | Objective matches / comparable |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| controlled | direct | 308/1000 | 30.8% | 1/500 | 307/500 | 1/1 |
| controlled | solver_augmented | 953/1000 | 95.3% | 467/500 | 486/500 | 467/467 |

Objective matching is conditional on gold-valid SAT schedules with comparable reference stages; 0/0 means unavailable, not zero performance.

## Evidence review

Full request, original schedule, gold specification, model output, extracted specification and checksummed trace pointers are in `casebook.json`. Paths identify reproduction-archive members.

### Example `d9b7e9c9f306`

`dg-000756b15a53c687f0ef2c96` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/c7f3e22870db45249956679496c9b8d1f0f4803e3bcd914a244347786240cfd8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cf7dc7c5680b`

`dg-000756b15a53c687f0ef2c96` / canonical / solver_augmented / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/0fe74f07d769c07d7fe76876370ca4ca14b4a826f1cdce1c4e8c3944fac5abc1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9303e2e47bf2`

`dg-00528db31996f031dd6424ef` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/e8092e6f9aadd34678c87c1004f7f0d7b0317316bd8fe10d3224767403171eab.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ac87f058531d`

`dg-00528db31996f031dd6424ef` / canonical / solver_augmented / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/a2867fc4c5da30423e88da3c595289c833eff2143c4b83fec12f79a8934f5739.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `96f198f2cfee`

`dg-008bb67c4b98a343291aeca1` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/f75c53354c3132ca91e0bf32120006fbb98a3202b573a371d4f4b449e7e95c4f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4bd47cbf5342`

`dg-008bb67c4b98a343291aeca1` / canonical / solver_augmented / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/5b6e26a2bdfdba94e5924a13f9ced15bbbada5eed804c9a227c8c2a0d83336bb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3f1e33cdeb25`

`dg-0138f5279b7834064ced04ab` / canonical / direct / very_hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/5803d1a61f3395954f6197bac40837037c445c0a933d991276351bf395763cc6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `182f3bff0edc`

`dg-013f991d5d10a4f31cb7f8bd` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/9ca5abc82cdfa9a44accdeba07d8eb09ba00b1f3aeb364ccc61a75b39c25bfeb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `acf34b67090f`

`dg-013f991d5d10a4f31cb7f8bd` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/7e1217af4b2df428345978702ddd6067297a3400a93ee9b523960408db3f2db9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `058e6a213a9a`

`dg-01abfadfd9f57ff36ac1ddc9` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1ec7a58040d7724b9e3a314c46488080ab20a4437a3238d5c6e54c267b7906d1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b843ea997ec2`

`dg-01d3b0173f90e4c4ea7e7026` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4cbde5c54c86eaa27d4352653820a095d22e9be621856ff695c34e352eb9afb3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `39aac963f0ef`

`dg-01d3b0173f90e4c4ea7e7026` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/371394fc844845fb664762a61dc02d2ed01eea83106f4ea8ec158e7fa4280a19.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5f042de39012`

`dg-01ec17d777f7eceec11b5470` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/818275eb3a37fdc77d20c55d9d034c8c19b605e6d07796d6127e918df4ccfd88.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `82ed9d181e10`

`dg-0217aaf3cad3c23363505c51` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/7f600775a57d4b0228d95b511faec002031b929752abb9be5aa9652c25e50617.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8e4a9122ac9c`

`dg-0217aaf3cad3c23363505c51` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/dccda2b37f8986efda6d5aaec8d6eab2dafeb605bc3ea3219bc7942835ac0668.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `66025a217955`

`dg-02211f1d803e51e17858c0fe` / canonical / direct / moderate. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5c314bcd44136255c74092ce0919eed5592816eff2bc54541ed7c74f4dc46a22.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cb1c62b936c7`

`dg-02211f1d803e51e17858c0fe` / canonical / solver_augmented / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/083c554b83a93bb72b85cea5b5db7396e53c9f455695e31401d5677e695e1897.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `905a196614ff`

`dg-02257aa39cb14889597ecfa5` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/6f5d10ce42d008038cd7d5560090cc93957ee619dbf88235f7914c830da16a63.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `331fe5bf3b47`

`dg-02257aa39cb14889597ecfa5` / canonical / solver_augmented / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/dc940c633a44e89d1b90e27c1b404e29e2e82b9883313d1e8777315e49338e6e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a8fbb39d77b9`

`dg-0258f1c21b0ea3ac97a310d0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4ba26ccc4e772dfc3e3f7d396d2fd287ecac548cc0ab0a213d435b110e44e07c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `94d3e417e42d`

`dg-026c2ff23afbd457193e36cf` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7a42fa245eed2481ee215993a61aba02d7356adc871d549889c9d1a72e395898.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8bfc268729d7`

`dg-02743e3017631ace11f8fc6a` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e268a9a52caec7e1ff1fe37843a8cbb6e318dc8cc57beeb00f05749ac0f489db.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3bd673f1b29f`

`dg-02743e3017631ace11f8fc6a` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/c99a6f069bca00545f5de0a06196df66c49de79a0558ba920e0e35149a9faf6b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9b3e63a5fad7`

`dg-029edbb95d8682ac6092b9d3` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/ce4a0282d022d47b5662f1927b8fbc34025327dafddee9489a76e10adcb61c68.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `07f51bf132aa`

`dg-034077d49082a8ca4b142bdc` / canonical / direct / hard. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/58cd87649431a79a18c8459428886e01a3925d8673f719fd13e649472d704594.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3ee9825c94d4`

`dg-034077d49082a8ca4b142bdc` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/fdfd403779d3298d626704f6efc9fb641bdacab7464dd881d5c1612ad4638a3f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bce3955cc1e8`

`dg-0375b9b6f16f2566826e0a18` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/fc1bc1d24b65c0ac40adbad836b00e991f5aa1a6d304d493739e9ef826d6c48c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b86a0584ff31`

`dg-038429f4f0897776a0b74b83` / canonical / direct / extreme. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/33501c7b5a92e9154c22a20583d08c03190110bdc9d91cdd8408c7355d6a2442.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `68cd4bf78351`

`dg-038429f4f0897776a0b74b83` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/02dcbd15f51ccdfacd781285136b715b323c0521e179b7268a0c05f09594ff4e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c4f2ae896d99`

`dg-03a09ff7b635071f5da4e226` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a7894eb847694a657759a73f1d169cc99c7553855c9f87114a26f31559914c17.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0fe6c4ea82bf`

`dg-03a09ff7b635071f5da4e226` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/4f59af9ffe384ccb880a419fd002d326e7f893930d4014a4a855ff442924a06c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f1468b25d5d8`

`dg-0405b47d2aca43e4a7ec0e29` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/7cb8b6e0eab8c24d9e7da164bab76dfd3df8d5c5de9881e83b6fadc8815eb840.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ab58e997c847`

`dg-04bc336ec1f67eec8368c366` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4460da05be1b4f0300ae1a3d5d44549a8bb8a076585c8425c659282dfc1a39e2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b6e8af8b1aff`

`dg-0539d07e8caf001eee27c79c` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1b433f42121845955b6815e7362d452f008260a3cfe3a4c4f08380a7d1e1bff0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `937e0f570b15`

`dg-0572becf29afc409a5d567cf` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a935497b21b50d244534a1192fd8f2f62fe04c6b613dca545c4d24b679ad9a39.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ea1e7d1a88de`

`dg-05adbaf2267cd80dd0bc8323` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/57b3b4afa6976fd60e85e6bcd7470a0ce8fce83e226375016ae73d4236a9128d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `21b545510923`

`dg-05b85c3b11341338e7e647e1` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/426308de7ee6cefed929f4f9d6511e1283cdff91af71f91caeb00c107829437a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `feefad8cc93a`

`dg-0631fffcdcbbf999431cbadc` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d3d05d946fdb9ab7603095e160478a47967b34cd9e8b70f44083825b0d70e7fa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0fe744caf5ed`

`dg-06d62a89eaa40b190d9e0c81` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/39f61d88df2687e8a8b93fbc24fae4e45adf97e93984b3fecc7d65b68d052d72.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `82eeecdbfd05`

`dg-0721380e52645fc7a45437d7` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2530aa30d29982296ff0b1d15c0a10b222f5bbaa152888346eab01cc887b8136.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `88784a52c7b9`

`dg-072dea3c1469fea21496558d` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4fcf6b770971e5f43fe6d164f4b731a5a9c179c842ec9db916d538f7a4c2cf33.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ce4aac99bff8`

`dg-073fdd9973ce87faab04b8fc` / canonical / direct / easy. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/a2bbea784477373c7e5507084099ebe0e54ae6e842bddd20b44898670f0dfcdf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6ad2b01150b7`

`dg-076255912cfc060e955577ac` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/eb9b2ae187cd77d367cc578b061a0bd436418d2804a521076a32e4d237440cbd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `40f56348bbf6`

`dg-07679c8dfacde9ab5db16941` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b1caa5a32153f5ca5ebdb28696bbbbf98c5105443773b057df33e397e19791e7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ff6b0d03c474`

`dg-078588a7464d385cdb612ef8` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/f49a6183265c06c983fc71414eca339dccd4c16748eba8b2bb537c9066ed8416.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `62c1b7f39a5f`

`dg-07a8a364db88956122484ec6` / canonical / direct / easy. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/f9201e36c70f749b756b851cdf916d5c4499de41f5b4e0006e37f6bbdbec66cc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `85770edef303`

`dg-07b6a208ad6e0bccb43b19fb` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4b8acb6979ff2ab71d9908d799898287a9e20d27c4881cf2a10ba6933146f20e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7064e2d2a251`

`dg-08cf4481bd3f2e519ea81f2f` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/80a6d190d43f8881fd4a3099c612f6d1a0692162b700ee57fd3b84228aca5494.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2b86ec9dbf64`

`dg-08cf4481bd3f2e519ea81f2f` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/15f43788de21df7d1d5db5c5becfb4d7cc0bea39e25bd6837a2c85175fb6c936.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9353cbf7013c`

`dg-095e2a01a5406bff8f727cb6` / canonical / direct / moderate. Selection: deterministic_success_example.

- The answer met the primary gold acceptance criterion.
- Attempt record: `runs/controlled/controlled/attempts/54ac9beb12b530a3f44adf478e3b7c48b1323123d8e10a5135733768229e8bef.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `21e30cb78e10`

`dg-098c28649b5e10cea8f02c35` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b89d496826fd6644435dcdfca80bf624879ff616bcee48a6b53cfbd8ee522a66.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5139911e881c`

`dg-098c28649b5e10cea8f02c35` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/15f5a38d39470b51eb4e5df0d783068eab723af0b7c97127de8d1318978a5d46.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d9dcfe72a245`

`dg-09eb5697a68d89c126cacfd6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3d7f20d0e82d3c888af7fb0e5fa6cbee6376085b486e9b5e535f1564c3dcd2fa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f0275fd2ef00`

`dg-0aaa895de71ab761f57233aa` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2c7846197a46a8b5dc21a79f1814b2031550846769be007fb8be42a5621b3ae7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `376c1a311119`

`dg-0bc6a2dd86be8836e73c8031` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/83e5f428e6902cc6fc011cb9401f2d503b9f0f9ac8cda4ea9b26485749524f95.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0ed555d8a8cf`

`dg-0c1e82b123b8e0169fc5a94b` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0bbde430e7fc326029f4ddd32847eedc9b7d6193b7c4a4bb9f54e0ff97ece6bc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `340d4de84891`

`dg-0c682f38c642d25686d9b72b` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/8fc300ca6981d0d574b5813fe3a51420124215b89e9dccd5cab66ab941eb88ca.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9beaa2c1010c`

`dg-0c987099207f422cb2d9b7c7` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a028a5a52c89181f99cc689dd07db6702ff8842f769cc098e76913a1173323ba.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7799e1502c66`

`dg-0d56371f3693977d89cb1520` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/504e590a44b87af121c037b963c392632ee2283c118052933ade1d6a36c5bf39.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3a9f63ee6c05`

`dg-0de48d3f1c1e28f419a6a391` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/43c3cdaaf8ddff8580de5c0cd6ddde7eb85bc5f5d3b3eadcd88fbb3cdc5c0dcb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2930f5d53e6a`

`dg-0de48d3f1c1e28f419a6a391` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/8160065aa9830d24de3e3f7facc1f2fecc38662936f3f362a6e43d6a7d98e8cf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bb99e31e25f2`

`dg-0df0a8c8306ba247bf6ad049` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/c8ca1cf827733b26acd16a0ab1066a37e0b8023abb40867ba3c01a8f371e42f4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cef4758fbe2e`

`dg-0f4d61f34fe14d1bde3fb7dc` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/36908a4ef73bb341dffa7ad92caf68b0453cf3a75e72632018bfaf91018eb08a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a217e2c882f1`

`dg-0f6bfcc5df4eee13b0cfcf5b` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/b0a7ac6f62c70e86a9f934ad78bd93bfa8c5dd8439f12f1b3caae05307331c28.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d6288dd9834a`

`dg-0fcf9feb1d1ff1ad1ced2f92` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b0afd7fd476e75c5822cde7a025a273bf89aa1708423823569057094207cb74c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `63421c55fac5`

`dg-10657d8062f709d9e5175dfc` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/cc596275598d382cf2afaa529add7d0ebd49995ccb15fcc193087aee9834d201.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7b74a337a31f`

`dg-107a7428ce3b473a63c4a688` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/886826dafef132b2a3bc0803fb0787e8f390ad0fa84473a721ad2b59181b6262.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `57b6001d4748`

`dg-10d17769dcc42f998c175025` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/409d8a4c6f21e4040976f421bff80c7a5ade0d12eb713f851e234074b7dd708b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `abbdb9592e9b`

`dg-1177674ab886633bb92165e9` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/70a62adecf0b961f5cae4d930206b366cacb80771cd38e2c778a56fdc23bb817.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0272a34dd6d0`

`dg-1177674ab886633bb92165e9` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/ad94bcc914821d568814940a54e0c59b62d049fff2693a493c6b7cf8ae9628d0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `64c0c8d5019c`

`dg-127a15c44046beb3c3cd9e59` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/d5d8d343eef28dccd1d8493279d7065102c07d240d5dbdb197d4cc6807d47c87.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ddaaebf2e329`

`dg-12caa5fe1502186434731c41` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/223bdf0e764f7fd668c8761ffca5fd5363cfe6253b17a3280e810b5007ed4a61.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `47b1c6800199`

`dg-12f5ee06f561e5069086e4cd` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/576b665e820337cbd0c248db9a9842cab9647135b3b8222dbec2ad083cd8bf90.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5b2338c1942c`

`dg-147021efe8e5b6307b38828c` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/689fe1881a8ec97b211ed14d865f03badb37a98557b41393700f834b06994bfe.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `455bd5cf3542`

`dg-1490bb24e09d52652539dccb` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ceef8fb5bd94f06ecdb1d7fa367a8741e57fed08db2ff43f4293d0ba48cf3a9d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `70c34e1b39aa`

`dg-14fca203f4b4efd341110425` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6cfed730aa52ac3ec492ce0a13f73bfc2f6124c91a2e17b9d831779203be2c5c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ba59b4362e31`

`dg-1542f4325677067205c7e071` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/593f7556f00fbb6aa6912f1905e84828efc1416a9a57cb2c7eeee8945d28bb42.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a2a8d0c68e77`

`dg-1542f4325677067205c7e071` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/04f0d72b80987e1578a8fabd1d900d67e7fd95d9843cec4e47741021ec657205.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `17e10e45ce8c`

`dg-15cbe326f87fa8d55043752d` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4edd0b6839032fc3f8e25d04f7622509126430774940bb501427303e5903ef6e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `103118fb95cb`

`dg-166e3c882041cc463f7b244c` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/97d04418f16ed8bc3be6e9af8dcc569dafa4223b95b89b263ce2d487bc0761a1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3f556a944bbd`

`dg-1676b916076cd86c64bc318a` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/409b4e7b38d78f14413f540faf81341f99fcfa7e1ea931bf0dbffff51363dbc3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b274e80c921f`

`dg-17a32a7773dee6a7f3ce9900` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6babdbd9ea7702bcd626875070fc9043b4bb0476c7334fb602bf2cd6562d64b5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `81266be4be60`

`dg-17ae8580975f7140d9daf14c` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/2482b85ad486513fe4f3d29bbb42615f610ebe82e908b8518a8a25ed4ec96c44.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7279b2cefb76`

`dg-17e0e1a19f10fe3b50625d5b` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7654df34de2156757644a61ca4c2c11d52cdb9efe352036673810c6b987256b0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6e9989ee9f64`

`dg-18afdfc38a50ae7261924285` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/01c5c7130fec8b3e088eeaaa6eda19672a7f2a86ec253e7116fa7ee79ad13810.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0560a4028b2b`

`dg-18f848e87ef4e7623872b6bf` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/53669761650ab57f9b89195015dc0a7ec58d37beffd65bbb08234e42bb47897a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a662d7242e3`

`dg-190c0b97a1e89b5afe58b64f` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/1b064a23dca44d77063b1be5c60a673f9518e2dea6ae36f4b161d4c004bf969a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `091eb92f4d82`

`dg-195a275f127ce9c54a41a340` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b3ee05f105f1e5f5c80ed66321e1916dd1242d6a2648986b266f5f8810c58172.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `577599887ec2`

`dg-19ca8133bea34dae2ab71fb1` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5f50dea8e1def347d090c8bd4d04f919fcadc7d885b864ef7b6d541341e5349f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9e3e58fceb27`

`dg-19cd8a4021aed8304e614455` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/0b24e6e37f5720fff2bf75603d19bf8be68dba74f0b56d2d039c6429b2aadf80.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `355afd5ef29e`

`dg-1af80e680675d88b23193628` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/533dff8b2eb0d8ac7df7334278fc5e1c93f20671e44b82afa9134e953668a182.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3948967729f5`

`dg-1b086d06de9092e258502e08` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d0bdbfdbd04bc2cb17a7180078396fe4d092258ad3d8d2131e3894c0653170f3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `28aba330bde4`

`dg-1b27cc0e38ba00910dd651fe` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/52ef9b7913da2182cc5444cc9a840a56705371154bc7b2e3f05378280dc0de82.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `153624b59f43`

`dg-1b82ba69a0e84517f5f71cb1` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/6ce5ab4069baf395b6f3dd0d759d9fe3254460e46a2e1a6586fe47a2f0cfab93.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4e12345004aa`

`dg-1b916ad592ce166f929b67f9` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/944ee2c4a74bf1eb4a08110b06862ee070b19323f590fe67ee89c703d4a75bd7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1529794837ef`

`dg-1bdb77871d876ad634cf905d` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d974c00411becf9d8f5ab690cc291dd4871d960dc108ddaa39b3057443412313.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c248acbdba77`

`dg-1cdbd7c8395bf0162913adf7` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/13159759f82314dd43e5b69350dcc4fccbfb304311609d1b8db41b6a24e0b9bc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6d90da2de873`

`dg-1d0e675810301bd20c099228` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/aca98ad492bf48fbe3215bb2970302d2c0596d909d36bef061d4b28164f0f7bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3858a5f82e1f`

`dg-1d65f234307ef6830d7a29f0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d1bac1bf40253f4eb7e7bf6d8c113585f609bfe779e7d8ba583b86375a122a7f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9a44a66e81d3`

`dg-1d7e206ada49ebe5ffb136a3` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/573aa7a3bfc0156350a648eacfd6da3946cd4e156063158dd2e2d8beb12df127.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a6fd40279bc6`

`dg-1d7e206ada49ebe5ffb136a3` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/fa9f9ab1526953d848fdf6e0c1f746277cfc4e6be9f1125ccc3c6e0b081e72e0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `44b80b4940e5`

`dg-1d8e79954de189ac6e39b3a8` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d67263f5fbbbb499a0f877f6c456f3a5e7340e08876de5320d7bd2f5727cadc3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9bc3f166faec`

`dg-1d9bee68f9d1e887598a052c` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/27ebd0b2c90d5634b4e428a37a9f49cbe6092b27a0aa1bd5d59ca487477f7465.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `682d53e6032c`

`dg-1f2f7dff05ee73bf5419eb12` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/27aa8917d416e61b4b8d9e83a5a8983757fa6a25ce8233b8f983e454add06b43.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c06cebc9b1a5`

`dg-2059bf2cd1e9191db4dc44cb` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/f9dd907e05a1c99ebc8934f03e284e9e51c0a0b6568e207c016fbf4e47b1b67c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0045f7cb3148`

`dg-212e8accc24f0a32318c158d` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/afdf2de3752f7c28f61b688f2009a79dc59b28b4bbdc69ae010352d60d032bf3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1bdc2955d799`

`dg-217ab199cfbebe78f1a32f8a` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/597181aef5513ed1134b368d78e75c5b7429fe7fb92753e46cf5aea4764548c2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `77dc9f4b5db2`

`dg-21a2b01f071f677a0867bf8f` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/66418f1d2a3a16a1e1e0ee1b47c2ab9a7cbfc675f089931dce21c1426e54e50c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7b2d83bcfaa0`

`dg-21e94c0d901bc1f9a57e8c98` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/72ecee05abb5cad91c228cad25a8db9bc8ac6e4124d34f467a197d9972cff084.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c5391265c155`

`dg-21faf4463d7b52e86e587d00` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/cee57807958e69317f5e56f7b45f0c1018bbc339deaa023884386417bde5f2c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5a6e612a0527`

`dg-227482c5088586f419fa1fbb` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a9d41e37b8a0de5bd81bb8535816517345f521820319c47a3b365d2660406cd4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a1551f4f769c`

`dg-22c2f6f726dc12980d0c395d` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d7af6ad6307368ab50c5deebe01a5e7d02e3271a50a379a38f8b435d0b3854e9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a3bd1fff5464`

`dg-22cae3e9d70495976e31ae72` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/18194825dfb95871fd538a8a6727c7a7fa3e41ee299e948ef15e2fe3cb9dcab7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bdcf8819f352`

`dg-22d2eb92b21e0794f317294f` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/46ac9776b774b6c27d244cd20ba49387c9ae959932fa826126a0017d6576ebc5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a659af6b8f7`

`dg-235696913fefe935c94d914c` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/607097e6a3878c6918d72945ae48e60617136748098012da79af82173caca34b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ffa704f26bd1`

`dg-239614cf90ad0709428ab43f` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6da8777e2d28a8bb92baf71116f80fe611c3ece891da3fa853cf93907749bfc4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2c76cdc8dfe7`

`dg-23d9ee75ac29433591374a27` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/35ed00ad8360dc6a01589c02a27a1d338243b7a288dafdcb123e042c81393b64.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ecebd98bb3ae`

`dg-24157befa346d7a505b10676` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8c09fd43ce23841e9f17fd2837c5ee024c2a187d16e5cee36c3859bd7d67c40f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6fa240ede54e`

`dg-24939b088a3606ebf88a4085` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/95adec997aa79362cb6c39558f8e380c910a612943f4207f6843f92c2de1d040.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `117a22074936`

`dg-24f13005f83d278224f16481` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/50e030245efbb35b8cc674517359ab0d9fcdbe5550b38a8482138c82cb2640ef.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ace236554a84`

`dg-24f13005f83d278224f16481` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/d1f24b699de860b9835abfc6e65a1b382e6fa9b7166ff1d6a9287f8fb5c82aec.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1846a40e1c99`

`dg-255aa0165ac17547ff3aff2b` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5b30fc572b7560969499f5e8892d953985cd37bb628622cdb2b61ab250309cda.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `47adc2112468`

`dg-255ef0d496bc71736aebde51` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/64b4eca7dbb5a3419603c97216d17d75d78206600942f0c1bd25a79d2249b65e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ea6e654ccec3`

`dg-257e19d8b03389b82be92ec7` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/bd61802336aba424c73dd3fede9e3a8c38ad8eafa44d01709eb75768deb104d3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `31564d8d0e5f`

`dg-259b49514a5a83c6929b3357` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/3a92c14c9b80f965b7b5811387056b8c417fcc0c1977437fff6740c5afcd3489.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `567e9430e598`

`dg-269bc9161fc26dd1beb06279` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/14939ada60781d5f4b73ab2795495041bfa7365c6f1114ec92ec89618e872944.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b88d2c2bfa21`

`dg-269bc9161fc26dd1beb06279` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/dd0ab15c5e5e310052b42e1fff9bbdd3418d3c81047abb8a908f01a739d69d22.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3cf7c54fe9c3`

`dg-26fa0ea0d0a53eb237bbce74` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c38a31da56de0a24c2f7d3f6c10979c5eea6f15be55fa39f0fdd417e7728463a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `24b18615ac03`

`dg-272ca697362b9225098ca6b7` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1b93ab8c416b218d8a9bf48ac773f1bfcc21023ab6eaf2488799daadaa259de9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `47cd11fc1a8c`

`dg-2781e8410ac2dcdbbb7d9e20` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a04c52e9b0f54c058948822543a9d107a06a687d5f78348994773cf8e6dee240.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c578b6f79d3c`

`dg-2818966ca1f592b51f5e5cff` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/f4eef17fff4d3c832954cd51a8d414e7683228e8597c56bd4400bd527aaf9fcd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `840269306605`

`dg-285a5365a652331d34b40ef2` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e207ef96ea88c9fb6fa7bcaa9ed83cae0ea0d75edcb0de8fd997c0e3df625ec2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fc32b07c79aa`

`dg-28a891f809a096e007965cb0` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8bb3b56c54782d3ed201a4b39b2b8727f9c410e0a7c89516542a67fbc821ef0d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b7b0771df8d7`

`dg-28cf0cd07a27b32383372fb0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/5132a34cd03fc3ba246b5dbae9d3fcf6e52b60fa34a13330c01722b435236b06.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5c47a62ac84c`

`dg-2910e2d8c6e26cc9431b7652` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/c6dc0ed960b8df997937cb36d64be3fd7a63d8bf7d0786b1a66cb161947c6b4a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c111e88329b7`

`dg-295f1f35c7e8038cbe4d07e3` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2db284cf5c5d9593c814933ef628529e8cb836e4379a5871b569211f312f1cec.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2f1d428ccf5e`

`dg-29d0584134949484e0adc842` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/425fb76d9a086833bc31c89d9b17d931d200f390d84922be1a47f8e7f6ceee53.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `929e42d6f426`

`dg-2a1f0a4d865a0bbd5ffc6ccb` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4729e1b6ffded3c0611cd3e3d9c119b4fbd8cc3d5486f10710238e451feb9917.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a9eacc44c0a7`

`dg-2a240991df5f3f474ebdf2fe` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/704dd471c0c9b5f07740831656df3f525ce3faeba430403519939063e71b70a7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `29104b2d5588`

`dg-2bd03716419849008db9e50c` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/1af56ce7a0178ec2431ee5fd051695749fc2c6ae3e005f79c47e2933482f9e83.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `06c6c5dffb4a`

`dg-2cac015e576698a28d7a7590` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4b85fb33e40d8830c8ad119d3d8c46136e638eb86101afc324779c815ca83101.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3f704212e815`

`dg-2cac015e576698a28d7a7590` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/0b9cc40cb22440bf33706d7d231a6efab31dc348486d6352820a520b00d523bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0cf94c2241f6`

`dg-2cb0c79a51f1ff7194f56c4b` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f2bab73e25cbec505935d28737bffbbe4f22e1af29741ad28f9a3ed7414d0ef6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b898670651a6`

`dg-2cb9a7996b2bf8a067bff241` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3c165164bbd1ba1789a5d8ee9b525bd60530872c0f1c0c97d2ad7ed448abc02a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `456dd53994bb`

`dg-2d2584c3e21a0f23ae87a12b` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/e52e1b4916ca755560e3a5e5037663b83e1fde4f2c37d18ce1824716ca1fcb6a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `267803d1da7c`

`dg-2d40d6f5455eea116c0a2a55` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/05f56b7296855f2ddc8efe03af378a31082b73a1d0cbe6f23a4efed876cd7d98.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6f7b191726ba`

`dg-2ef0788cc702203a51955472` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/623ab4f4e31109826d1cc462f02c5016eae4e0f12ce546ed783fde0a40e60bd7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d8e17e534188`

`dg-2f98e4526b788589de65549a` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7b7eb09737989bd5e0855bd3744369dc9e5afc407edf6b3eb1bae9c21a43b632.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a6ac855d1ba0`

`dg-2fa71f795d17ddcf51d4b8c3` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2c5326e5f966077cb23775911396258e07189ae03371ceba6ce3a50c9353b850.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b8c456b8a966`

`dg-30463bd0428eaaaaa4cad83d` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/86dfffbd15ac82a1cf54d3ca8f7f1d30cddbcdb0ec67844a93d8be6ef7387fd8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `70aaae8c836d`

`dg-30557a9bbd6deead47ce9c02` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2ecb05d94e64e9202e0f7d2492422097ebc7ec34aaf3b70375f3a6880bad8d02.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1b7d19baa911`

`dg-3151d86a400dae402087b540` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/67f7ff8d1bd4f657b0a2657893d19f0cde0e6cd52e1ca0248db10b9742bb0340.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a29d4419f36a`

`dg-3176de0969e1be9bb6033c44` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/af926840ed8e61564f2db3c831d26b617bd7033a0b675f86bf06dd69d350a198.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8dd61d823d85`

`dg-3176de0969e1be9bb6033c44` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/82461c8f3885ecad91a969713b5745fa09de0d55bd3a41e61b01c23b0035342a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `971d5efbcce7`

`dg-318fe87b495d48d09708a7ac` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability.
- Attempt record: `runs/controlled/controlled/attempts/d47632bb83535c7943fc1f9bca0d1070b3e4d193034335c301188b60de264ff4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c1a33c376b68`

`dg-32a2eebca13ac203e5d9d557` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/04491f64ed3c025b93dfe8fb3b6b5fe804b1fd1b0a2d6e915804ae1a919f23fd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4a36211888da`

`dg-33061516a929e025fb180e44` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/72dd3130670b445d323a9ba35ebcdec06724a04d623ade05c785f421a23e2b4d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `eb623fc0d534`

`dg-33804c9155f7d7977363dff4` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5996708d8cc84fa6767adf12b92e6d7866759135b0e09de4a1e4699afa52b559.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `93ddab8a5a8a`

`dg-33804c9155f7d7977363dff4` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/ef6c3b1bd44dc2383890f61f19c18d6e81a35883121fde82c103fe0ff9ba4743.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `14a7ce69d8b8`

`dg-33cbea1b1ace9a42336999fa` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/931ce3875d6e861ca01907a356c0371008d88fc7ad002da0e7a3b9bf6ffcdef9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `69d2d4d7b280`

`dg-346dc0bfa573701d3b52df3d` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/6e110a95ca2c0bc402d6884f7d5f08462853deaa692b483f2f7208502d9a961d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `89b068407ab8`

`dg-34bde37f276ff923140cacf0` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/1c13a9329541f4e9584f52bea38a7598f112172a99e988545fa72976546d2637.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `65c668b94b7a`

`dg-35ee3494b3f1e748d7a427fb` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d612fdc29e4d48cb0e56418eafdb180b9e6ab350c9d0faa2f9aaa5e73fc403a1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2d260a17d573`

`dg-35fd1be783844a4bc5a7cd08` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/92292c2dc6c0a2c51d9af68eb4bb179305f80509c3c433fdfb325e919355ea4e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e93aaaf5f298`

`dg-360b5e65b16f36c124a4bfe8` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8da83c318a856b4f58e308b8588f95bb3168edab247bd851b6f908eeeae0bd2c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cf572ea6c187`

`dg-360b5e65b16f36c124a4bfe8` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/bfbd8c5d3df6f26390071c87682ee0ecbf15e636171657d9cf40ccd63644738a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fc2a015486ea`

`dg-369eafc6fce4b7c16c1d4934` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8a1ad9708cfe49dde6492bedc0671f7db171e7202cf70430ed2756c0537851e0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2c69316a7e89`

`dg-37033757f40ea513abecb609` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e97ca39f6ac3d60b8b15c075eb5a38f6b24cca8a7d3e36daeb30fb8e64f9c0b8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2601e530c40f`

`dg-370e8d0e2ac8bda7a03ca853` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/13778b66e316f2ca095559bc1abbfffa60710a57b1f338f81181fa44c35ffb38.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `900dab612f26`

`dg-37e589c10dd8b17beb4d8861` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/34cbfc7f3f06b8157a1416466e45f0d161a0e79c229cd5672e5bf6e0008b49c3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aa2938735dcd`

`dg-38aef1ab5d1a6a0fd9b51137` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/159bfd4610b9428cba3711d665991c544d46a0d7c573587093296e294161efe5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `16903052ffce`

`dg-38aef1ab5d1a6a0fd9b51137` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/12e4664dcfeb15a03187ef7c137fbed78dbdf06c6559f03b2ad437fd3f13c1fe.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8a3541e58a2a`

`dg-38d8e9d45b77c91cf553f614` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/838a0ad61469d381a7593c5bc96bf65a9940448f3141e32aac2add136e1c6cb7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9d4e801e9210`

`dg-395220210e8a80f4842d0f71` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/2cf067aafdfd984c242cc7f9d9110893dba2c6222d77420b31c34fa8f419ad32.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `20a225c53243`

`dg-3a44ff9d915e10160cd4ba43` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b5496439268d159ad4907afd6d9101ffb127166cabf8215a86ddbd256558f629.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `24e39327f32c`

`dg-3a6dfe4fb73fb9f36ff39734` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8ac893098e6afa1bce777cf488f8dde1c9070245f869b80ac844b9022c068d92.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `764a34c56763`

`dg-3ad8b129bb32504958eaa495` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1dbf456f171584839a0cb83009fe412e08201cf712cd9ff4349ad3222fdf0b93.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3c3e007f91d8`

`dg-3ad8b129bb32504958eaa495` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/1f7c369f364e4d2064342680fd7af5ee556cfb0406def859aed64528ddf95e2d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1186b9cd5cdc`

`dg-3ada01e9e3215ed8604c290b` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/1ce926487c6d086108ca1b57dd2cdc2a18c3c025f722196ef62b24c54527038f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9244dff2f3cf`

`dg-3af39416362d1d0be180b559` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e61f07ff01b35c9d9f8b01f6a92f21047fc0e8d72b30946455fe4e10d8c7d443.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f075609b929d`

`dg-3b4c59d7f0974f5d5fe674f6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/61153ef41b6bcae0febfba07f8aca34935f6d92867d8608384e1904295f347f6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3a91022a5d81`

`dg-3b7d86c56884daa6ef967c45` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/56d9fb39f42d5f34fe041fa2c8604b99531639b08f49a6479b7111f437e5b13d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `51e54239d6d6`

`dg-3b7d86c56884daa6ef967c45` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1dc85ffbdc72d41e026890ff21f4797c8b3c96a40feeb76674711d42f0f5d696.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `143f7e5caf02`

`dg-3ba77fe69b3c00e352713317` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, horizon, participant_availability, participant_overlap, precedence, resource_availability.
- Attempt record: `runs/controlled/controlled/attempts/7c6f8a6917d6813c8c49483c2df6e535e3eaf9a08ad788a7195138f1c16f11c2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cd274d14e3b8`

`dg-3c504e8082c2f2329221550f` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/bd7a3a8463c1f3f1746ec35d04b4df9debdc3adb41d39680aeac69dbd77ffce5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0a3a0f012b59`

`dg-3d10150669fb6252739e4d2e` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/48ae5e7fdf0de173b74255ccc9a98916488a05fa0ef6758aec53f21811fa4c1f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `33f4b4b63ef3`

`dg-3dd56d2eba273bc26e6e3886` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d0e28b55f7f26bd64bba919959bf563f12757de686252bf44ee85d2f9917d30f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f27f031e5a84`

`dg-3eb091c54206d296241fa26a` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/58ab9b1b0291cf066bcaabb4a02bc81068f3104939634ce913bf0d563a36e8a2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `72bd3926e5da`

`dg-3eb9aa7000b7b258bad96b30` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6e9624a81fe4da103706addc9ceba27a6af0ca56c24d2a66f85d077267b73955.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4757f7a9a1be`

`dg-3fd5174321284caacab1f4a9` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1eb9b8bce0381b67e305f03f5335ae96b8edef2fd8119449fc6022244c6dc116.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bfd626ce6ccc`

`dg-3fd76f429884525fa6dba83e` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/44e45e3da03c6753a957d16fa315a49467a8be68e43ecab958d7cf10527f0894.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `978c6e7c59f6`

`dg-3fd76f429884525fa6dba83e` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/ec58db8497ebbf9ea82319416f959af3a87240f6720ddb80cbef60425e3c37bb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9beebb07961b`

`dg-40441b9d3ad130f00c8a93fa` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/eab5232ddb190bb22122d54242209bdec49fc3a950bef80ccf5b2c24afb08e85.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5459b7dae324`

`dg-404afe43b412311fcedaa4aa` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/433b9ed74ee9535f6d971e9e644061099f046598f6a1b553a759a807c78e5830.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a4881f67e502`

`dg-406a917163e5840d6ec6fa58` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1a71d4ddc0332f2fede737a322aa1baf70631f5fa3085cd8155f9560a93ed978.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `116282699dfb`

`dg-4075ed586aeb62fd06eed0e2` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/045f2798a1fadb8b985561d2c4f5c46934e24de811344e8401b064950f5ca2d6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `83a9c1a930ac`

`dg-4094ed10715606de7cb88253` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/c667f0d2b50ce07e7f44bbe8768b5cadd2c1b6b03d25d3790182f1794fd25242.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a9ae0a2f201b`

`dg-4094ed10715606de7cb88253` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/54efe84ad31221d16da60dfe3f9997fa122b7322b3be3a88b028f8b18ff40b72.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c0c7ce33d031`

`dg-40e31cc9638a1a77b7d46055` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8de30c1aa450774c33ac41aa4b92bfaa771cdf20b75b4ddaa4e41483fefc8db1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `109ead1e28ed`

`dg-414d94c1830edd01aedbb268` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8f7808aa2c7ffe8783d742be185977eb922ec85061b09cfff7478a4afd884e84.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `87ff2452e2d2`

`dg-415827410e1d74c2f134eba7` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/9c79e0fd3bcd0d1b12126fa711a8cb1d1f8459067ca4d76a958609af9f05ab17.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e9f6f9abf897`

`dg-416733ab3509ecd0d2653763` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/30016d4a857202bac28fdffd83eda0bfe5dc03a723acf9bdb275aea00a00bc51.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f7698ddd0210`

`dg-416bbcfa1353262c88199912` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/e8486a9870e7932f77685d2dd88b23ef1d9a8c239a819048b1e7ab74ae8d7905.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ed8e89a584e7`

`dg-416bbcfa1353262c88199912` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/63bc2b1c5f46fca077494ce8844e76fa130ab23210c04b415eb2170775820e52.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6e4997698487`

`dg-418297dbcf4f66e28037fd6f` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b2ae8b30089a3661ce3b281957fe40c2222bc95305cab39559729c9299b87930.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4808face67d6`

`dg-419c8cdbad90ad20797b5b58` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/6dfb9cf827925356d449744773274ec7200cc46d6b6a0d85b2f088000fa67f22.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bb604a522baf`

`dg-421c9ea86045dbdcb6f1e203` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8b0817e77cb331671b670bbcc0f84864b657bdb0d9213f0158bfa3a2a34497c4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5a4bdb888b4b`

`dg-421e5bf6d360c3a758cf470f` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/6b003f2431b774410fa55d117417d2b48ae6721851acee192b2c15f5287d42ea.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e727b30c10f2`

`dg-4223d2e0d112593a5b534873` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4beee656240bd92909e1e70a755cca5e0848cde469b35f871cb9072431b1e424.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `17676febb005`

`dg-4223d2e0d112593a5b534873` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/e302ebe618b9906ec6abf77bd63721bd29295a5047265fe85d04936e1118a5d9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2e79d4378938`

`dg-422cc82aaa7d24a45064457b` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/900c50a11c62bb7bd0fc4e6043a246ffae5c70c0f462013e7b255962c51ed189.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c23d67295a00`

`dg-427b9d2b674fefb2e6529647` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/517903503424b51346c02661d714ff026c4be7365a8b24342564cdf28a3ac6f0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `150bfd8d2df1`

`dg-4287aa1279478eda23337c72` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/34461f9f734ea67007e104d79093d5e07a377d034dcdb06199212e58ca8a6168.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5a3a6f3a201f`

`dg-428913d243eed0f437280180` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d52253a2630693f031809b108ba463d75f4f8c103c5c07e7e7b907661cd7013b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3ece53a9187a`

`dg-4366fc616bdde0bb9f96ea2a` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/82f90c92353a910961d2350611ab62744752b0e1d3b8b3c06e5fe12593b2aef0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `054db6402b20`

`dg-4366fc616bdde0bb9f96ea2a` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/04537d4677b5816e2f1726055978d6ba4db29d39545e3183bd459757e3df0a7b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d23333f3a918`

`dg-43ad7df9797005de83067bfa` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/c3efa04968bd3a74a650d7191c1626a8dbe20e3141d8a780d61785d27ee14223.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d5a92d816ed9`

`dg-440ddc68748cd9ade2fd8507` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/0f235b7c5c4cd984883d493388c8ab133e0760e10270633a2f37fed93fb5171c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d36bf59a1acc`

`dg-4419fefe43e85e10bb233d37` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a45cdba8ea1663199d796d314c948f9b02098f635bb89a823bb17fe81d673f2f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d4cbc08ea959`

`dg-44dba3dbbca305d007ffc641` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/709e08c89e7bb7963719e21e11168d94930ae9d777133d80841a2c3b548c1627.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6473a22492ed`

`dg-44e28bea295ae73e3397a927` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/16328043c8ced041167a3a77b00b1f06de98b6c99c00c10cfc3fdb493b9ac802.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5ab1776f6f1a`

`dg-44e28bea295ae73e3397a927` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/115951455301b9912a059b0f438a72d2be076fd4d6baac5e4a8e804cad51b397.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ace559b750e1`

`dg-45cafb087876a4b240b2475d` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/315ec9ff2002245bd0b87a8bf489ade1ad6acd96bf853f96a84e1a1c14ee1327.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b3a5cf62ff75`

`dg-463b7b0ca9f441d58e3c0b1c` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/56edb94f0e67c77c901db3fc18b4afe6b2f338ed9b17c0ec1db31d4e50e51bed.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `199ba476649c`

`dg-4662bf55c933a4d1a1516663` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a732df6689d74fd8e28d121db1f5daa81da72b90c0ac484aba1d538b92411e68.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `21d7d3c245ce`

`dg-469331304529aaa0eb3f95af` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d828bafff2cef5121ee69edc43990a2232e2afde2a458deaf10ff4a7e4796df0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2634782e0d37`

`dg-46b5bf6bab649fadc3de08e6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/f18d0706126cb084495b70a126274e7083d5ad5c9e01273d7a94bbb80d87e5d8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b01b470a425e`

`dg-46cdc3e31315ea1058e00845` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/ac4615e99d76c14c08837d12a0cb9eeb3d07ddf15b00a0e3dcc171d7872a0092.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `23c38d0263af`

`dg-472b39f2d0c3c1ae722f3fb0` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ec1c4488e07cdc09057c9d2c1e785d6a1bd36882535e90f2e9fb21eff971f713.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dd6e4c018a56`

`dg-472b39f2d0c3c1ae722f3fb0` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/5c5c1b9f472d3496886388b18a35c6c29f6a2aa4118982558d2ba046832c60f6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0c58d996d927`

`dg-47930454d8426d5a683deaa6` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/105e44f05de4bd3c559941a011bc9344608ee9b916487a08ee989066b1dc6cbb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2b1bcd187a63`

`dg-47c106eb935232bcd18a6327` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/266fc85f34f81cfa5f2cb154e12c36bc0bead1d3ec9baf4c8d10c52eb2b10524.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4d3d73a175f4`

`dg-47e953ba186f0521c0850783` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b38d8059d2503f7d944ad2399dc4cc600a6d5309fb3b2ba72ba941cf88ca8fd6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3253e6f72ac7`

`dg-48611e0f4331b2dae2f66ea9` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/18a29648eee6c23c6a203fdba987d3ebe47a289456fee79158e5fe07f469074f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f672db54316b`

`dg-48aa96fb33fbf8d089fa628a` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7459fd6f1da9de704557da8594ed34ed5b1b2e725becbe88ddb41c1d43b9fa97.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9c66f06df58c`

`dg-48dc7da2977db68f45c49314` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d5f600775b19fcf40ae0784422322323d0535db4ec0938a0b676715dda5579a6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4506f5777629`

`dg-4a1289dd92aabf610483c437` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d7f0d4845acf829606412fd64b01e8495827d1e86e24c19c2eff1c7d8ea96ced.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aec2d8963ac5`

`dg-4a1289dd92aabf610483c437` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/595670fc23189338dcf8cc01fedbdec3e91d4562b5c2aeca5313da0faae03538.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `edf8fc4923ac`

`dg-4a5e8b175b1be1bab7b312b0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2649efdade8472499db140f89e63f9371f918f5e6199815e399faf7affa72945.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5c24de16ac75`

`dg-4a9eb19eaf73f9592f6319d8` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/393d94ab0f735fdc24b16471dce1326660acecdd8bb754591abb8c64995b98a1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `00144628f8e3`

`dg-4aa54d95ea1084a0ab1509fd` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e3316be41da6d9c41d08ffd349e0abd14334efe737bd91e5f3c04e1ca59506ac.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5f8f6c729c7e`

`dg-4b427e9b2e5c9a41bcecbe6c` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/70383f394629de4ad6acf1ee05f64fa7db521cd462cb1c674f35a56cc61201ad.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6b1d20248fee`

`dg-4b90ba0874fa7cf534217a08` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/8551c7cc96e7a6905221c32f890efeee022006a75e556dcf01aee9f0c14f6ac5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `169b6b4cb9f2`

`dg-4bc618eec71e06e5dcaf2c05` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/c8eb005d72fef6352c4665fb76e7d5735b20d19c1f246eddca0718a33165fcbb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1e3adda764ce`

`dg-4c5286374642e98f6de15c77` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/18b0bc0fb68c8a3079e38bfeae5089414997cfa0c23bbe796a9ec4c2d9a9efbf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `520f6a5e340c`

`dg-4c8bf0b9bb3e82a0043b5837` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5408ba5370b6b6a6dbdfdc668a3ffd9d0441466a38a54e581d4f747f742b67e3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `60f5efaee78c`

`dg-4cafdd2827e1336d93148317` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/ef6178eada2243ca0c394e00cf9e4be9783c9b1c22ddb8d667cafc7f4bea0553.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `744331135255`

`dg-4cd06ac0c94747267a6a4995` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/aaab3487baaf4b937ff039c274b12f8a2ca92bd021590963286fe1a5292555d7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f47bce8f5908`

`dg-4d7860059690ba543513ec4f` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d294c3ec3d86d7388d93b2dfb8e4b0aca0ca7be5fd71c5f76194d575bf01af94.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `029f7830328b`

`dg-4d7860059690ba543513ec4f` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a22c5b383520c934d9f932f5b5012709b5e61c5c6e7a4fba1e1f4cfc2355955f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `22c5ba99dc41`

`dg-4dcf169ee0877fdc9b72cf2d` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/1c8d49268d0b5c433f7b91534cb29e4b3306a74f04f8ed1cec7eeae9960b083c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `275069533420`

`dg-4dcf169ee0877fdc9b72cf2d` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/97dab70a58c25eba43f7bc4465f44954013b1510392a0a3186e2bf2891e60ea1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9e2b246ce4d7`

`dg-4de64d6adaa87f4ee7d5e706` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/469c7b0eee5949dc41946ed19c0626681e432a39172c2b668c70efeb43cb2fda.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a20ef880b9dc`

`dg-4e167fc93d7ecf14b53fb8f1` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/60c84b2b5df41fe4c2e90609d518451c2afcdc27278f470d647952dfd6957971.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2dd7db6b5e06`

`dg-4e188e57b74ff716cac1eebf` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, precedence.
- Attempt record: `runs/controlled/controlled/attempts/94e2b35708f7a60549ace8e11da3983475b55c16343f3b40b79a31a1a7ca5412.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d30ec44c9b71`

`dg-4e2c58d9554ec7956d060d47` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/56ab3e76ec3687287c83534956e00c6400dad45ae4729cb32f10bfadcb2ea17e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4e8c1644830d`

`dg-4e3c1f68f4622b3dbac7c16b` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8a56b9fc6da842463c5f2f12db36a5fa6ed8c3c3f23f9070b8933c170ae45947.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `24420cdbbf25`

`dg-4e5253062b7e62ffc92eb9de` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4a5a584b4fc7b33ff1ebd83a256218f001c97833dfde97be2713278d254b02d7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f0e56c8fe745`

`dg-4e96678d5789d506a25a3124` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/47a17100e8e65487217c5cdbb83d4d70ee51e1fc9974b98a19b6f20d52536417.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6771cfe6529d`

`dg-4ea85002f1c38a154a8a95e2` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b27196a10bd0f8eeae3d3569c22d3a9b4fbbfdee7ee7d755c88124005d1b695c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `969fc71c70dd`

`dg-4eb59a97acc4e45fa2fcd9fc` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/bf7ba08d9d561d573bdaf2bb792607ac9baf4b20a53a4498e766588ee63ee302.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `52cefbc0327e`

`dg-4eba49a6b4c89a5f265dab81` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5331ea4b10a1b1d2fa02fdfdd0e81ed44dd89a52b502364bbc384a8cb666f053.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `67c818e39da0`

`dg-4f2bc14f689d8d49fedcc6b0` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/686001e5ddb14e20886d6157025a363241f82baf6f99ffc874381b36900b8a03.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4490e87c5dcc`

`dg-4f2bc14f689d8d49fedcc6b0` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/95e6a5c942a5a3521213306411c40f48654517a7c40f654112e2c36117ad3b87.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4027a6c4efb4`

`dg-4f950b00e4a73fecf41529a0` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/19a5731568d1bf898e630389bcc11c9ec835b32199881c3de8e711e3ce74a9de.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b90b5d089a84`

`dg-4f950b00e4a73fecf41529a0` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/b8a2de474b834ba7b733b59245964f9f708706cc6bfa7ad9c7afc7ffbcb351c8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7cf9046029e8`

`dg-503fac68a90ff20d49e65cea` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a76b4ff56f1a2ff1adb54e80a8d853fb8cf8f9ee5f27d714a305ce1ef26ccf5a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b44c68ca8b81`

`dg-50441def267850466a499da9` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ff30aa0550af876da98160bf57f419e83fe5198caf8e3d199eaa31f9c077807a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bc2861efe818`

`dg-50921326e1815afc0eeaafdb` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0e1563af4cc27ffb22a8f3bcc7e252d494088b994ff3b7187e72e9e55fdcdec5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1ec7cb585c0c`

`dg-50ab1dfd631d6fff733d2a13` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/da40c6f6bb2b329b0731a341226ba58300c4f195636e46db7bb1c1d8e4893625.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f5b44ef75d28`

`dg-5191ab2f9d09d179bbe04171` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/058ad6c1e8aaf74d221eaf29126a4425cdc45795b08ab48bf55db82469fa0b07.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c3a848d092a6`

`dg-51db182a4526e69f86e3154d` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: duplicate_activity.
- Attempt record: `runs/controlled/controlled/attempts/78ae10bd8eff19b9087808cf2dcc53b2ef363a9c7e3108125add0ed9e6e112db.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `eeff1afe98d1`

`dg-52896ede44c587ac456de024` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a339b7f7e155a47b92a41c42e79abc0ea818b204aa5b82acf3c02f0080f20198.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a21b80db4015`

`dg-52ebde9e83c1e5eab3ea8459` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/f2d48369b06573714aad09efca3affc93dc111af98abd551a6d3e3de8211a23a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2fc87a73b71b`

`dg-53236b8f7b0513a9e771d363` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/1e1fb0e97b93da1a2f4c0188013ba2850082aa0e1ab9a3c63587bac2b7df4dc1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5a003baf9900`

`dg-535ace5370eff8b6098c07ab` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8639e7c1451b2173a7a5ddc20f82839df341ea4926924f865afd93c4de258ad7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `63166b4f40b8`

`dg-535ace5370eff8b6098c07ab` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/134df3ebd0aa81db3023d1f20ba87f7d0a7248f6939abc0aac06acc807a5cba9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f56139054c37`

`dg-538ef063da7e48a1a2aa4522` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/da12ee6467cbe4cb1b525cef0e95cb8f74a2cf934a21890718ca669a5ebd1b67.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a04d92599700`

`dg-541d0a817c629e1d63e1168e` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/b7ace9fe22b321b7efb5d007b6ce7d29279a251106a74e578477e72f5b74d82d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f19e4d84b8c2`

`dg-541d0a817c629e1d63e1168e` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/1c604df1b49094e5de18c1cf65ae1686f136048784d7359aa9b906280f41e4bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `389d76e69ae5`

`dg-5428718a40b10aa3712f0377` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/a524d077515505d14594262abd5c421b74fa80824c2737282d6cf0f9e76783d9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `866378573342`

`dg-5428718a40b10aa3712f0377` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/9ecff07cdf66adea201eaa40ee8144d6aef179e946d063bfff9fc7cce62ab470.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bb0d0cf3262b`

`dg-5461a5d09649770ff013c8b4` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/88fd01e8ffbc80da516886d7c1181aff706a327db435c5486ef1be78d6957d02.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bd1f1125f9d4`

`dg-548a893de96b9383b0f93d42` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8c8bafc41178d2a38bb653b654d7f2802647f468799c99bae3ad225d543fbc90.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `63d1e5af01a2`

`dg-54934ea04c7c8c0a68056b82` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3a9bc715ce543b49bfc0d97893d0607449cdbe9e026c12e5625ff61ee828751a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c65f43391685`

`dg-54d5f34201775482c1518d86` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/b636858efa2e080f11df55faf00defab636282fa5668606229a77860e8c313ed.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1301c2a52862`

`dg-554d581a19d6f0396b340d2f` / canonical / direct / moderate. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/fe8649ed17da43de8b2247ba79ac06326b71b7805ea1335d504698e19b1d75a7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aefe89661afe`

`dg-5554dacbdbb9a7d9e2e19162` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/294c927710032c47bb303504f001b838a693e484e0fdc98ef442ff6e56703d1f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c310d1654909`

`dg-55ea33f7400698ff604405c9` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/9ce0c826577d8add2e13f8cbcb98dbb394a51ea2160355168cd2867131d168b6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `df6de32bcb49`

`dg-55ecdedf1763e2866e0deaf6` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d3ad5c34c29a5d64a0085e4da9a6364a18745590f993984899102f4f123648bc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9520d55db3b5`

`dg-55ecdedf1763e2866e0deaf6` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/fed3fd41445298047c84cde3a58ac7e89650e7341af55b55189375f3b842d5d8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e9ea4ea49bb4`

`dg-5637a6027e00c6a45c2a2581` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/39251fa7472924fa119c3a7493cd5b70877263785671c8ab564561bc158ddeb2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5e95c7194809`

`dg-5729d152163896580764ccce` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/eb1342e4ce5713ee1fa106919e7a88529c20eecbeaac1cf2a7e0cca4aebab6fc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `488cce5870c7`

`dg-57882d7c8b779a0b11059d5a` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/7331298f117e10d26b4720073c8a6329b8fb98a6135764cb21f22a9571cf8772.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fa0fc2dbf065`

`dg-579c086c4d51d59aa65ad345` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6c59a7c74b2c1859728fe36134d67f1262d3e875bb8f061efcbb70b06496b920.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1e027a87874b`

`dg-5850c09b4caf703a58b274e7` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d24ada6f654c69c41bca0b4ea32a44dfc6128e990f99a8aac41adce56037a9c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1e0eb34abb7a`

`dg-58c8f1767c302b67b7b0715c` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/69c638fc925f564e22d1badf7887aacc8b6f5f43da1035084c035d6a037b8a3f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `78409d1764e9`

`dg-58ec86e70a9442ee790765cd` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/17c3e2faf7241bac270782ae6e51efdae133670a9191911c0aed1d868d79ba6c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6e441a34d68b`

`dg-58f5d546de8a5d55d7e1712f` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/e6ff13b3b61d624af27d442d807d1f1a7180d759350e2236c085b6e35ac118fa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b517c1cd9a21`

`dg-592a4a3a2e69eabe6ad2cccd` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/e1da2beed69844b750d67ad75846608a600905929de6524f02dc6678ec46d058.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cc93b38a5565`

`dg-59c12647d4536dff55c4890c` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/260bd5503b9909e51290831856ff4656a32c8ac6ec8091a598232ff0c598688d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6c84c0d1ac59`

`dg-59d5b2720ac6cf32533c57e4` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/87836343ca376202d8076500fdb699a5984274f8a05859c25af4d172f05fac57.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7a328a0a0c17`

`dg-59e2ee68847a67f9c178508b` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/985bfa5e1697ea02e0ffd9734dc5b74a6c8dcbb9deeb7a5710c496c907d0735b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d2b2caba2477`

`dg-5a02fac0d1d613011bccbdd8` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e28790c42358618c1a998a3d14c81d11432a471996856cd86b873f3c23d5d3ac.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `224e3a599f29`

`dg-5a4cce1f75e0560c760cc519` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/9172de31fc87612037353a6d772cb7ab22b680b729db570f57719b6834ba85c2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `feea3d38d466`

`dg-5a7bd03402032c1ce7d3783a` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/97e28665df43216ede5438770eb9b9e26e21bfad7f2486442568a3fb77e9ae69.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9ad0f7c8e2ef`

`dg-5a8ad9702f3412c5e9886538` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/caa25fb6ab551f171edbede5863470d80e219529ce08a1f6b139a1aba1768644.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e48c3d9d8f95`

`dg-5a91de02e198ec471a455eb8` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1ee850f5a982bfdd26aaa16e64850b77baebd4946761b5d0dd640656ef027afd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4ff38c9a5068`

`dg-5a91de02e198ec471a455eb8` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/fe13317ec71948e22d4e88c1955fc81cdce6886e4623509ae5641ea88fbcdbcb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `08770abd8c4d`

`dg-5aa8fa87dcf043a0127c7ecf` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ef2284ada3878ebee75254ffcf0332bbed36a78f3ca02508816140b314433be6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `94f73a62c5fd`

`dg-5ae8b862f554705e31938cd2` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6c72bf13daddbe500ecd5302f47c34f0412db86be1c6a68ea2ad09d21db1b382.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0fb60bace7cc`

`dg-5b5352e348173083a27ec640` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/0192670913633a433399dcfea73e20853457971d2dd4aea4604fa99872db74ff.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fd81cc7bcb0c`

`dg-5b5352e348173083a27ec640` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/92c37f1506e3af81664502eedd7c7398583f2efc76fb3cf531c7c8f14e863d4c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7e2e7be9d9ba`

`dg-5bb0bcd3f56c1b06928bd7e8` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/aef175531c64a8207310d1950707155aab08f0439a9b3e24ec391fd849e27e6f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dbbc31725664`

`dg-5be670cda8ed0c6a3bc42f6a` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/28f30fbba43aee83ef1d134e29e460219e5e450b4369a227497667804d99aaff.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e0b341cd14f5`

`dg-5c332674eb74509fa804c2cd` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, precedence.
- Attempt record: `runs/controlled/controlled/attempts/6c7c862f56aa4c4fca3fea321959ba0d9615f3a8fb2cf861e6037fd3715847c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `462c26e9128b`

`dg-5c64bfe4cda5701dd0a49423` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0265147992fe78fee0ff2eeb57d8fcb0d5dfd7023840b16948e5fe0b58996d41.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c0d3815885f`

`dg-5c82e7c116eadac5338db2df` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/73363d4d05ca34a44bc21a26ed3a47dd9b634c8e96834d4491e41e8dae96c560.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `58feb0156751`

`dg-5d63830997dc66e8649b300f` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7c60be6e9b7afd7e2896740fc007c59b0652a41a0d771d677aa296c0dfa1dd59.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `de8ae00bbd9e`

`dg-5d6fc6e818a6428da2e814d6` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/66ec38291881ce85338a3f16575fe94402e311eb0be9c0fae9562e8ee0354fc3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `af7037668109`

`dg-5d9670f061ef6bee8e1591b1` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0be85882a359c58b519cfa17264d9e71ae4c3305e61887c37ceebb6761bc9b32.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7396b133d65a`

`dg-5dd670215ce3b1389c47f81d` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0eab5e4dcefaa376079b3dc40fb00ba8b47bb6df851ac3593f25d314222ac622.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d1c4e7850379`

`dg-5e28a166a88ca9cc8f4a1d2b` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/34aa5ec527cb43c165981ec43f38e88fc8bee815264a8d794b6be5b6de030c34.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ce2dbbff92d5`

`dg-5e6f4367a38b714484de4323` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a1964c710f77288b0e2e8c9a843d43bcc733541112d9389bad6d6b05278c51c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ba6d38d97637`

`dg-5f193a8ab9ad44c2268bd195` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b6a64fa5e57033e65a886e266e6a09736c5d7c26ca0d877fb56255d5f5b08401.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7e749b16265f`

`dg-5f193a8ab9ad44c2268bd195` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1c7b559ace3d62fd760963f866244d7e1543bf4704e5b33d935619fedc48cd30.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `17a3a738b7dc`

`dg-5f374958d50f5fafd1cbc5bd` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d5ed5d2f30ceaed17755f384e717ccb82b8314472745f20ba21b263b0cc9dae7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ed68fc2663f7`

`dg-5f5379e96cf1878d7141742d` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/db0f201cb6aefd7b7d7db937daba5317fce46d8178d784127554dbb92fc2c2cf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8a0049e76cf9`

`dg-5fa01da086033450641a327b` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0618707e3ad45c4e05a8a5b61150b0628c5a744e82a06898ba8cd66c0c563a13.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5cac72979095`

`dg-603695af06396a5e31bf40c7` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/f974339fc95316c72634a93f4378f65a95784013014e49ca4c02e5f8e2eaf012.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `021d10c5340d`

`dg-6268a27b6f889be42a36affc` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7bb0c620d9c0540bdf9ebcc2fab2dcd2d5452465a13537faead52eefbfcae621.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ce0611995e78`

`dg-6397d11f92e845e36602923b` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/7b1165fd517b0a93491eb1ce07aae2027a02f7d0cfdb4835fe57fdba06a9d441.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `32a1137fa918`

`dg-64a52690b033be770c89166b` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/5dc5026994fee8aa54fdcb594e5b62b0f3c0cf39186565951a600a49f80b90fd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bf9e6c5650f7`

`dg-64ac3c7fffbd975a48e0000d` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/62a96c5337c0362111a9f0e761488478389a67d9bba76ed6031b4a7dbb55337e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d9de5628f7d7`

`dg-64c223fff47cc0d1ff8d10b3` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8699ac555715b3f5603aaff0eaf66bbaffde0af4a0fda9051f19751cfd948bd6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7f5a52ee65a1`

`dg-6510f8b4fd8c18e97d1b8315` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/e5a17577a78913ddaf97bcbafba6900783b487ff6005739188941f7cdeb7f833.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e070fe5c874e`

`dg-653a62382b553eec7f2d58b0` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: duplicate_activity.
- Attempt record: `runs/controlled/controlled/attempts/ca77ca15d7a34accb1d2d71fd839deae8e3f94e7983a1a10dd7aa860f7b00d5d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `39b8719a2060`

`dg-65a038506453a7c616b03bf2` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3c5ff1358fe08aa1132b57b4950246cd3ee069904f4e8b9b7c3e9d66fa2a6336.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c60b324d253e`

`dg-65eec868138417d519af2d6a` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0a097abf2c80f698a2d42dd2b0604584a690c1c4c1f9c59d4824e76c87158e07.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `14fb1fc124d2`

`dg-662203e1f575cf840cc3d837` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8335a1e7c7d5ce72f52494b14bed40c37e3e12a2c1e8db07c8e8c211846d726d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1ed213f16bdd`

`dg-662d7fb9ae07aa2ed7cdd79e` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/94d19efe88739c1556787b5be4fcdf381bc2d591d86682bfebd695c602a57918.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `acd2d383ef6e`

`dg-663aa621a323c2c4e272b208` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/e80e793f95744e139ac8fcc3ee944d7ae46e9f74439b7137b03b006309ba6009.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `97fbcb5169e4`

`dg-663aa621a323c2c4e272b208` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/f062c16191c8aff0172f01ba798de4ef0285ed6524d2784f196bfc7593ed9d3f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dbfd78f2bdd1`

`dg-67258575c2ac0a206828ac2a` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c7e0f76bb999b24fb0527ff92f8ae28b5b817320f56028e798942c514ac932ee.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1a9ab2439512`

`dg-677979f1ebcf929488e305e9` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability.
- Attempt record: `runs/controlled/controlled/attempts/c2970bb64d6f2fcc8cde961cd863cfbdfb55ad84682b752d2741350affa0d449.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ebe1acdd4627`

`dg-6794e60fa1420339c3e125b7` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/65372d08eff347bd13af0782dd726643ce3fe0dc8cb6d1116df7354d1c36e0d8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9b7749c8eb69`

`dg-67b2c46790316d3205c78460` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/2844191f1d2331dd528418be113a9f0c12db8100062d93313d378a0c1151ffdc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d3d8bc774cac`

`dg-67b2c46790316d3205c78460` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/7f1dc76cc9c59ff8e3c6f02fbdf7a8c9142141b268493160b9501806309e6f38.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `871b5a417571`

`dg-67c8b74a7d4ba388295ab96d` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5cd136d5362076281d4cc9a91bbd1231e9745e903367d25eef4f1d782e5d9943.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `594b1db272e6`

`dg-686532b02799b75c91b9b9e7` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/2d3036127fd54fafa8649fc017af2d49c04f40cefc7aa150a15e33ed58d6d6c8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `77a291bb9be0`

`dg-687c24e6ab04d67a5cc3b14e` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8100983e234a89dd0cb2c028e8233cefc35fb8198b469adeeb8a7bd7f0fdfc9a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6b18de9c0d1a`

`dg-692ba437971c431c6848d46f` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4d9e115f2002c1909edc8cf1ac3d97e9e989953ca869cd640b25cabea66c5838.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `027c109209f6`

`dg-692ba437971c431c6848d46f` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4c0e2ab7da4fc943b829096c372d8a7662ae448b45727278a98e530457f4e3d9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3a316c019d81`

`dg-695e6da68718cc924a35f82b` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8abec01210bfb6a82179b7c2ccc9908502be4369ba229706c8a94dcad0877f3f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ec841ff2b253`

`dg-696f67d48aa9bcc1fbdbe0c4` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/54bd2205c5ae3ec2665686fb07302c4f2e5da0e6a63a9246a7ad7d69c49cf792.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `725d08a4c708`

`dg-699a2a6266af7a8a21e17ddc` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/18504dce2b01fbfa92970e12866e90e30619ba1c501ed21b3d3ef1db869428d6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5be968bb5ea4`

`dg-69bfe53f1908ae519a0ccf73` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/00ee4a7c769267fd43b0951c9184b4feca007726c2da4e27be2f07e72840e67b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1988d339991b`

`dg-6a31c9b60713bb2939ad4fb6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/873b06481f3c8d9389a9d232cb2dbba21694834d934157468cb2161d2badb498.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e74d252129db`

`dg-6a31c9b60713bb2939ad4fb6` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/485acfa24f5df300a4bd6adaa8a6194575ca361d6a97d710217c128212e651f8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dc6ead21e5e7`

`dg-6aa58461b8a766cbdc9fca99` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0bc4939810fdb225f6924611a7a1addad1a50eecc3dcc2b3f38106861a3ce5f6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5439318c33f4`

`dg-6ad8723b8e0e0781ea916ed0` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d3550535e368c153d35948720818b244ca0d55534a6800863a47bcdd52772877.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6ebbaab54d9c`

`dg-6af99b4a6c0b37ca8e5d24fe` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/01afe9857fa28a17f493a447e89884c30d5542b47d11466b98a913ec60c29684.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2d488becb246`

`dg-6b1ed528e044eaf9505d6169` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/109d2554deb777c29cd85e573e22fff11dc0c0cc207eb7a977e71a89b413b5fd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bd1a93cc4458`

`dg-6bc48ef96d9f37dac76fe52e` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/994b70a4a93f5ae228ca1c93000dba9fa0720a3da4934f41ee4c3e3acefa8062.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c74b5b62b2be`

`dg-6bd29b12238c469016aac920` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b93684eac0712e2b731c560aed8bc709f5de71b74554f7b64d0f440267d2b892.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5641a57ba6f8`

`dg-6cc87f271d0d6d07300558f7` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/22245640f66ecd36fad2b4db3d44ea40055252ad2f26d9619eb1eb374515ab2e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8c1f62fdc16f`

`dg-6cec1d6ad98ce0ff6eb07801` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2baaa5dbca6cb98352729db41bb61a2b0fea5cd4e2049599e558d5b61ebf1aaf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9ce1cd86ab32`

`dg-6cecf2bc643820616aac279e` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/fbfc50385c70c7dd82c5522fbc7bc5b946a50ad9864d631ab3450eaaeda6b088.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `58f88ce0dc9d`

`dg-6cf52465b5f7d26eddef0d7c` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0f460c7edcb8778220122b377e6b76c1d444a1380a7e3d57f58ddfddbc2f6305.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `329ace023f5e`

`dg-6cf52465b5f7d26eddef0d7c` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/4f3d229a7d692a41eddb9b300bbf9a33f5e55a954bf7ba98a3ed77f2c56eb5e7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9e1b65aeb9b4`

`dg-6d0f55e376c810e3051d98d9` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/56db9ed6fad633c56d62b1bf717450d702f8a00500e4034714a1e1b58e6dbe11.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8632c75be28f`

`dg-6d849f2849ec0a1f43772e39` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7585dc4dee5e25c1a139341ff4f049a965ed8d8c0d777d1b511fa55f109d6266.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `263046fcb3e0`

`dg-6dc685f44d38daf4b0e7445d` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6242b6fb97eda0498a3032ced59ddc78e841688e3f12272f40eb304f73251c15.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a65bda39e82e`

`dg-6e34605b4b7543ee7ac8f24c` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/f792932d3b28c3cabc634bba03a573320ef392ca48dffbcd35d3733797e03831.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `266bbdd3cb16`

`dg-6e60e15258c23acf5f39dbba` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2a71f516c49311b7743238a48a9409b1e6a3ae6cbf160dd8e762f68a5be9ce02.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7aba1e5448a5`

`dg-6ebad33b32a6be277ecbdb57` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/380c3d36ecde92a0ee75c8e4280de94b1fba3435563dc339271d6d1b88f977b7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c11091414e7c`

`dg-6fd8d261f43d77ad5c25009a` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/81f43d582f35b066af4db0350624b6be50b313b412e4a84ce7b06171c038ae3a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7fc93d05bcde`

`dg-7021220f5b5cb1b5542dbed2` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/867bc2b13c3590b54fb612a1b3b4dfbcd23401007ae4731526b748305a565651.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8979b9f2d67b`

`dg-70996555ef694f5f8b7941a0` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/fa89be1d6b5c71006a9e6f62d92286e48e2b9c7d08f938ad6c9001a677a5f155.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2d26c6d8d2e6`

`dg-70c6eb465168b575eea257e3` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/66b0d5485da51928d1b28a4a193111022f0f8fb097ededa1201271c5f968cf2b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f5aa48e0184f`

`dg-70d688ed421b977490bf1f6e` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4ff9b55b01cca488740d8a65681e1bd15c132da347493a1d06df8f495487b783.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7b3002097420`

`dg-714cf17fe661c576ac25ec6c` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f7713687bac771731f3f8d847caeacd927428266551b398802fd566c038ecda6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bbe35905de09`

`dg-719833e5fd516c241d043186` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3431d849d3f9fad52187e26494fdfd229d657a5bb5e87cb532f613fc3b085532.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0d22b5b0ef35`

`dg-719b67b7969a772af8d3810f` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/2e13fbbc02accfcd121e59054d8574cd746c8432c8dfebec81e81e1b58bc3eac.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a71eda2ba2c5`

`dg-719c4b8a73b1ba69aeea0e3d` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/42c2645110d39d2455918bca717bd0becadc8262b7758236016ef911fbdddaac.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1d900911540f`

`dg-726c944fe360956afda5e0e1` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/fa855c086c3c7f2bacbc7bafe0435ffbb63bbe0b5c4b72d5dda996260e47447b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c13a71a38574`

`dg-729950e61e6586880d57c394` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ac17c7b0a89176d3ad751624b9aca298ec951bf7053ddfc7b6d7d4f07ea813c2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `82e4ed9664ee`

`dg-729950e61e6586880d57c394` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/251a8eaf23bf85e38d8b5fde104d1fac2265de7055c0a2fefa17ed7ae08225cc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c2ed79059f8e`

`dg-736531568094c1a2a3443951` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d6cb8849622547ab019ad294dc667d9d713a86c93173a935b39f21ae2e341915.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `22924faf473c`

`dg-73e392bd2fca692480fb2f34` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a6fc1441cf33bbba4169668202c5e57d0892116debc42b11025ceaeea84d60eb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `278073fa5b09`

`dg-73f70a5a1ade78f5f8cd9d3e` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7495bf10eefff65135a22eda8c8ef3b1ad37998e54cb92c8198f01c79f390f16.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1b2e30d66f78`

`dg-7411bd6ca97859e07198e9f0` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/9837387c8569339b88310eab4dc5d2aa6f5fdb8e00d939c8cbd063bf06454bf5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3265a353c556`

`dg-7479c7cc3fad01034248c9c9` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ae6131ba013b3d80c53852f5a2f319585a77d3aed77a253c94d337160b76cd34.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e72c17d609c4`

`dg-74dbc856f258897e6aafc8bd` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/29cc224261c65fb46a992af329d82de949f9b96341b50d6cb402d697d0b3cc48.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cbd9281f4292`

`dg-764e63c0bc7617634a847d80` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/8464fe13cbb016dd21d0739fc93945340f1b02e6e7f52045aa62c7dff3c7e792.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a4c074ce2e31`

`dg-764e63c0bc7617634a847d80` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/6c3bb655ee74b91ce0e18a4f820869f657f3099d5d89c74587d95763481fdff4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c19dcc821a7d`

`dg-766b11e5d24dfa4cd7e91d85` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/97c45b0996fca33c392033054e3c514577454bf1d657a825e5965773f8e00af4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7007fdbb290a`

`dg-766f77f84d0bbb439f4e743d` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4a7a67ebf9bd90cb4cc9cafa91754f8be654ffc995d711ababe13def566e6ccf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4af2fd014d0c`

`dg-76cbd10037ba449a504da04f` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/383a4b4e7acf1736c00ddfb631a98d186825742c5ba8a30fd91f3420395adff1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `68e8f60657a1`

`dg-7746435a75e9fefd95d4b78d` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/2163c64d6c4ea89579f0a51bfd195f260f9c4e4a8602cb8315de70ecfe8efe8b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `75c31726e33c`

`dg-778d5decdd8a393fbcf31a7e` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/70cd59e2ec52ed874f266336d1ec36149198361852d60afc5aea19a31c4aa009.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d6467e4c2ec0`

`dg-782083dd2af989acece30cb8` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0384f9d6172b3033325d3a34118bce436d0fbd8fca86a1fc911cc9df092cc41d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7e07def86397`

`dg-792d2b7ce057825edbc3a3d0` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/07fa8a66bccb1534ec67907d6267b13fdab7daae8168e130b3a65db382227e78.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `54f00c064233`

`dg-79733182f6adb7989d383352` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/456717529384fe0e680668e147679ca08f65e33a2161bd2c7859bea84bc95b7a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `159bea6b54a5`

`dg-79733182f6adb7989d383352` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/24f5bc09f34f86f3d1078e85f2798ce38d21baec74aa74379d7eed0c6213c25b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f72bebf7fb19`

`dg-7978b8bc6db6be30231793f8` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e9997549b9738425c4c0b03ae1ecf6fe10ae59a0b37ab827334451294a18c072.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `de9d7f9dee80`

`dg-7a5e54d3082f64586f2be9b1` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/908daaa1e621298c3bc30e3e2d18ce86103e5cc30f8a4b3a5597df042b15211d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `371401440a26`

`dg-7a970c58512c3db06bf769b0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/fa49439d5f9eeb039ca0b39b4eacd9ade12609778921ebbbd057bf40b58bf53d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3c4147513dd8`

`dg-7aca9d5b5ff5212680f4d810` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a00061cc10e26405fecbd85aed641f7d3ebb70d3fcb3240ebf7f9323fa28e091.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dab75c3f9200`

`dg-7acb6d444888d8b78495dc84` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, precedence, resource_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/cd14af68aa015b6748c2ffd47eb5ad227bac975b1fbb5adc441b0f9068e88fba.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b1946c427df8`

`dg-7b168f00994c2c8558cb56b9` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/151344fe4daffcfa865d43d544fd839123062cb2ec0d78e601d08e4909478d0b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fefca361c548`

`dg-7cc2cbdbd2704a9dae38aa2f` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/a468524ed1c1f3b461167df05965dc110975e79136e216090989772b00e23697.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `43b3089715aa`

`dg-7d97f355a9be59c371387f32` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b87ac92994851d2b3e4b85e2488390432818f958157bc69e75996688414e1e1d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c3742a291f0`

`dg-7d9a76557f64b7fd4de0c644` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3768e199d1c3407cd6a8cfdf7197b4ae9bc549d3898a3091ac9a8d8d5055ee94.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9ceee151383a`

`dg-7f52d68d5f61667721b9c26e` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/5b835c6929a1bfa200f144c5e0208468c4e9f1aa5a267adbbd89833a4a58e472.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f31eb97cf556`

`dg-7f708560753322e41ffec8a3` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: duplicate_activity.
- Attempt record: `runs/controlled/controlled/attempts/6be57124375f4b0d7510901d298ce4a9d68f4e132b8348e1fd50ec399bb5bf65.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d58b1943fe26`

`dg-7fe514bfb9687057bb68b14e` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d55a1939a7dbcf8078ca7c83e56c370d4702e887b52e953e791f8e7d694e141c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b5da4c78ecac`

`dg-8010895dd9f9772f1ea4b54a` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/5202c1e6c65ddf8b7c73e8743936f01fa0433b9e016bfaf0dd8ca49d14d3b98f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0f12d9da68f8`

`dg-8031630cabffecc6fd3e2c73` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/38dd4b1dc1c11476c6a57065ea45a5ff66b95b43206ebce8409bc1cffd32dff5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `74c102068fd2`

`dg-805409aaa8f9bd25481bb222` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/76bddfd51ace05e6806ace1f65f46bd7276a592024b512ffd7c946b219268689.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `617817325ac7`

`dg-805409aaa8f9bd25481bb222` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a561c310f0378feb13e9d2bbf6dd581c39abd271d7c42b1857a20fed358b631f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e83585747f9f`

`dg-81313372d453a728aa899a7e` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/7ade4005cd7c60e73201b053370ef9af447e6f4b492c4f5512c1db937faee403.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `01f6a64cd4fa`

`dg-8173f97516641cafb21ec7e0` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/406f582fe73cc6a5ebe82afbfd48dd62d94c57175abe109de26d7850bbb2c77e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `72ea4f3204c0`

`dg-820989a1b5d12a1d1ec67b03` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/07bfb997b6bc2437513418a2421edb4c11f33f39ea64e2015b1df8706f34991b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `df3152f1fe17`

`dg-8212ec6b23ea8a0cfffd471a` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8bd42ac402afdb069b577ebbebab4746f5d533ebe967e1afc6806ffc0f4b4bbb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `25606ca50be1`

`dg-8220654a27ac9057b89249a9` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3268d7910b231387b2d32838a5b44505ffc640554b091c4de467dfc01c262734.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `29eb379a88b0`

`dg-82b5b412c5ce9021546cf62f` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0ebb7d51e5fe79939416abe52709c9fe7281de1bc5e3a383c7cfa433b64a98b2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3147188b8805`

`dg-836c39a51d93cb277c8c68af` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5e2c9a7caff5c8b846ff8589e0f8c01067e908ec87396cc34968ac0df14842f1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fff73b972b0b`

`dg-844a8809c41e595805e889ed` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/e5478a0618e203e82b0d3872df850d6a46c7f5dc1624480ddeefe9da8a18bcbc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e1acdeafd1e8`

`dg-84759a116cd39af0b43da51f` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/f254a0bf41190e09caf6f0ec3beae27d1fcbdb07e3038a42752260e4da1fc16f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7bf59385d9c5`

`dg-8489e30753463fd3c2ac3270` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, horizon, participant_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/5fe359c4a430ca4b5e8428759f86f4cb28fcd910ed1d158abcb6ddc1577cb4a4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `258bd5c681ff`

`dg-84f8f7e19247f1b0303f5ed7` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/176d17f6daef8b50a2e488bbfe34ba28a14073d5b8eea35dd9f6e9c69578f4f2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5d3c4da21f83`

`dg-85aba96b389b49fa2ba53841` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/bc46ff8a88c4af5faba3034bdb42203101d1db6dbb764d6aa68e123f6f0f1381.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dc1fb493af4b`

`dg-860090e1e7800d60ec03f976` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/19cee1fccbb2f9abe9b029b0d93b1fbf84f1e5daed08817caea7d4e6467d4718.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3ca984693d79`

`dg-861e1eae906574161311bc52` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/cc57ca09f3d3a4a6403aa8302bbe9c180f91e4da713942d91841f44c36b92161.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4f29c48c33ba`

`dg-862a337ef575aaad721a4dbf` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/e88c6c10bd67de395b5ac9ce08a98d9ff35a5b9bfffe0b45f9345e73f1f8354b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3256ff89d02f`

`dg-862a337ef575aaad721a4dbf` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/73f91ef4c6532a7dcfa09a09638d069ce27889177f38a7ebfc82e1b5acceaf0d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `23dad72d69c3`

`dg-86bd745fafd371d231b2f102` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/469df16ac67fb66bf1833dce4c978b0933ddcf67ca43341d7ef0ccc0e2f087da.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7b7dc3930cfb`

`dg-86fd7879a47f068a8130c5e0` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/c8a5b4c4f79e9c6c261f41588db53a90ad57545f53a0996e7bbab623ca0a7831.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6e5e2009587e`

`dg-8741f0e696a64b8df5df91a6` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/2ca296cda8204cceb2721af03458bf5f19747bda3f70bf0fad1f7b79b21428a8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `67e40e2c662d`

`dg-8741f0e696a64b8df5df91a6` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/bd1a95d2d5adf15f676513daff38c3dc594ba3618565eeea9c92b17713764078.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `05b091f5a5b8`

`dg-874cb9ba7ff349f0c82e262f` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b8ce0c6a2d214d2f9743282a4e89453bd1c135558c9aa31de3bcfa8f7d19e684.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `498275d5eb86`

`dg-875277e61c42ff9407492b3f` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/e5f95d62ff3f6a08e89da7b734d82d7a373e41f8e1f49c610f753027c4409613.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d444d7e4a19c`

`dg-875277e61c42ff9407492b3f` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/7fb17c331ff2014dbdda849f737c70696093509614f018b0d51046ee798332eb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `35db96be8f31`

`dg-87681f136ced3c2bee96cf2d` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/e23e8ab6305c488c6ad9d39fc7dffd18c698e12055e36fe5adf19811558b8adc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9685053105dc`

`dg-87c547bed8416a870938afbd` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/2ed3d66ed1351e36722524dee24d837e360363763b1dfcd8e4e32d309e3ddfed.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e8e3ef64a8c0`

`dg-8822d5bb73b1f5219cca23a6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4023ce2ce7fe8bda0295a4e64a4fb902b85365a2c471901c00251ea6c66d6672.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1ead1b122af7`

`dg-8837cda528ee0842de2a7d73` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b127fae13f74e50798b81347452b3c20f9eafb3f2ac589cb2f02d01eabe23df5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f8a717908d42`

`dg-88b7ce630577caef75e80a62` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7d536685b20f9fb71eadd8e88417d1e0a844af2c5d684ebee065d20044f87f08.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `70d9fec1e3bf`

`dg-890aaf261826e28677ba4c56` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/53c56710114943597de3fcf6cddf4f4b4a3321fbe7c705295091462f82ffb9f4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `41aed54ae824`

`dg-89aac0937589452552ac62fb` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/db1b75b8c4929dc5e64881b7475c337bd4d74357c9b1b566c0d234328dffc575.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8ae31c53cba3`

`dg-8b00187d32af276be7940b49` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/79a22e35497f24a3af749ea983fbab6b83eef22d8cb8c95213de8f38baaa6567.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6605deab17cd`

`dg-8b01bfc597c3c4e62eddc475` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/e5a956ba93add5e21792110cd136855d5dc1a9b7d89c541aad0851204e00633f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8fafb2ccc476`

`dg-8b4ac8dcd202787ba09ad551` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/135dbf6c74abfa33da89fcc46ce1948ead174e33d076fa6b73a46829df28f119.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2d38c9ebe47a`

`dg-8b713892228ff90b927af122` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b4eea1c623e8b2f30a5ca2b4923a1fa9349382b180de775e35b01abae307111c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7f55ba05161c`

`dg-8c97a9e94bb9fc0a9149b8ee` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/dc5d897ccf6818f296d4b18960328d6713ae117aae5e95de111bebfb1863c759.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `da89ba48cf2a`

`dg-8cbb582f61ee732cfbcd5fc5` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/acb04fe9685b4751cdded88305d7673857d81246cf3d892e803bd896a31b8ccb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6dbe27162be6`

`dg-8cc81a99d13d56e0bb17f0a9` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: malformed_entry, missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/cd70c7d720270d81d7e75a5293f3724c0822d5115648f54175f82eba227eb67c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8d33c9f73fc4`

`dg-8cdf7e37d636563d9920ca2a` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2c445413864bc8fcdd429f3d764d78adca0e2872d53005faaccb28b97909ccc1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dd1a9d4ecad5`

`dg-8ce691d530eb6b15fe5ef922` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/958a760444e3694700f5d9febbf1d7b2c14ecb97d49edc08e5c0b5ecb17e3d42.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9e0d53faa6a0`

`dg-8d0af856c7a8bb60385b9d6b` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/0d259a63ba894e2c8a3782232c0f5ab98dbb39a54df84505e474eeac4634ed38.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `346de2c50044`

`dg-8d4921520dd5ce25f64636d8` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1ec2c94772dc2ce34d44fef5e2adb5b9c74f6991c720afa3f05b42645c2386fb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7d3465da05e1`

`dg-8d53b59ee2c2c98cb9f11ebe` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/25f061bab1bb3946f0b949f765c9e96a40a9521859ad1eb7530ef340f4767b8d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9f052d9144ba`

`dg-8de55f20baff285e4b5d8bf8` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/42a7e64dedd52af3a4c54784e84de946b85db5d5891d8a3197ba346106ef03e9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a583aa011108`

`dg-8ded20f6d6d23a2ecdc72294` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c81d4aa2a6f5ebb5e28d9c0cd7f0dbd59fb98ab6a443b4ed69596f141eaf11db.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5dfa05ccf6b3`

`dg-8e68ca65c6c9ffbae7156860` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4e201736858b9aca4e3d91d88901c474ee722d35b4477dbca2bf732d7ad0dd58.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `70303c958b9b`

`dg-8eb5e6b4f95c2580847231d0` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1353eaad6873de44a117a476249da14d01836f7f2658fd98c28a8b616f0dd2b8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `737eff34042a`

`dg-8ede101be58a375b73b4e4f1` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/29ae6215d36946ca71a4ad8a95183e1531bf5664aad07ce75cd02ebd04dcec63.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ad13d6551dfd`

`dg-8ffe91c69d7cce7a69666c8a` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/16ea435fd15f0c3ecc1b2912a34f3645a71c300b3dcfa4142302e6d0c3ac3307.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5ffc586cc861`

`dg-901f5127b3f63880cc499f19` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/87db870ea95995f17e7a66ae3c6619a2d9ed282bf570129def2a7c464db4272a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `73f655b2931c`

`dg-901f5127b3f63880cc499f19` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/3d005cfc79ee78cfde0333691438c5eb042f0b4f7fbb9f0f2aeec7c070a82927.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `41094c51cb8a`

`dg-915276e3c922a5fdc8ba8e41` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/08bb0cfd4222442cd8eec2c6f91bc79536ad10ab7bc9e451bb00f97f54a189c5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1dd8c8eb1ad3`

`dg-9217be4ccd6ef38c2cb086f4` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7d422df470d0cbb7c08e1e72aea35701495ca03384c0ab315413cce87810b584.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0d37d826d8d8`

`dg-922456595da34b60fbe5a2ea` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4a7f79db7c4c280dc9204015b0e315406c4766cc1ab3c815d024f05286e6701e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d05447fb7bd3`

`dg-92b9fba927defe329af5d947` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4f3b6c1caf8fbe5465df8401bac6eeeecdd2873006bbf6a144cecf4707cc3dd4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `19ae293cd06e`

`dg-92be19dfa00da00efdd27922` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/3c3e7a9791be09be1c9d1d5ebf9afb59a097a406aaf70df8245e6efb924b1382.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a36a11459e3`

`dg-93645cd68c645d31d613fa2b` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/75c31f67f2af5095ebb9f752cd96789f3b1ac759078d9feb1fadc29448d22388.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8b79b0442e2b`

`dg-93c9aa0e2d19779a1b7b2963` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ef08952d127a85b993ab658a7d664fa80b746639399854ea005dc7f9825d7754.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8c14446f1fc3`

`dg-9557b161a80370836243a743` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/af42deb04eb19aa1f4fad589cebac54b1f55d7d30634f1c63f22282376bce300.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c533206f6fbb`

`dg-9568fe95655835f5f48a3487` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0a802257cdd96e50c5a06532ecaeaf3444e9215500a96b34c40596bc5faf3ec7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a034e77f0f2`

`dg-964af0f0f3046bdc6a2a8e45` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/e6f8ae0fb443172a511c77403fd185c5307acd23214fa1144bb88cee8cd8e61c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2d0d5ba7e968`

`dg-967d0fd1cdbbf5965824ae73` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/25ccbc54443002601e315fd614b6d757722f69d992ad8df4cf292c4e528cc948.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c9fb0f30b844`

`dg-96b198c67e1cc1fca298ac84` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7da44d8a589fc9259ba15315bfc8bdb5fb5377652b135240a9fca6ff37237a7e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `621c7cd63ff8`

`dg-9783601fd28a7ab994fdd063` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f9254fc1d0ff5c57bb73429307ce539c601da9e63aca41f50cadb1262970dc9b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5f0cd82225c9`

`dg-9792ea50e7eca26f51b5198f` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/be137c59ff9934af292dc39c309d53a65d39534c485e23b1603622ae8b067d33.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2b1f8756836b`

`dg-97caed70b9a286c5c0195a59` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/97c19468d90e78d89449c1721a4a33396294f220e1519c20ec4c118765370236.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a3c8a14152a6`

`dg-97caed70b9a286c5c0195a59` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/f48941ab3afd4acccdb44206ec1c08a70e0192d73fa86e4f626a8210d9e36c60.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3cd8e25d6b85`

`dg-97f09da4896aa8f5afe3ecc9` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: malformed_entry, missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/50fafa36779da0b3d318807ac983bf45186cf20fbdc8a83ab22805bca7269395.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `60a31a0e1bdf`

`dg-991bb9c12dee2cb3d6cfb6c6` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/a6feae80d03e7b8bd7fcf5e12df62b0227f3515fe8a8378b3112e066d15ac404.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `764b1640653a`

`dg-99504ffa710045fe5be0b987` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/165edd47519131d40e3c10a953231df6536e45b517d4018274c56b0fb79a720b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `88d2dd617154`

`dg-9960a4e27ff98551edb70a99` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/800762bf2a3420c41b941b334893de01406297ae1a8c00a9511d9374b177914a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ee0d5d3db6f1`

`dg-99b05819031bc842f0edaf2e` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/93d6ed41f5ddf9a57dda0185d6dc44f77590d7451971ed1c4c06f811549532c8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `920c4e0d9241`

`dg-9ad734cc1b63d89b2462e9b3` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/90dd9255f657526922cb3ec9349d4a87d12054a9b141440e6e4731256c86b5bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a8bf2eff744a`

`dg-9baacc9d058d66bbc367ca5b` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d93c381104438e78a1458f8afb22d636313c1fa8d47277570c8d5482f584f111.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `027a8083c961`

`dg-9bbf03f41ea97890d805abb7` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4d95d66598f6a4db88554c968ee015d4d11247838a10dede1bdef1c112ae3db8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `aac0d96953e0`

`dg-9c182e1955b3fd325367336f` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4c228b5af3c627a0fb88ce215652afc4c8164ceccd796111945aee6e7b99ecce.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d091b84dc332`

`dg-9c2285af4c3cd22da092b894` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f7dbe1145c8820a8a2683e8ba62a6fd36268176cdf8fd84d6ef730ecc3320e4a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3053a2dca4a4`

`dg-9c8e99ffa1b70d0afa6fb07d` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/37fa3d276e6dc00ad631321ac504f36ef811a6046ce040098d7ef4d5d320f305.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2aed86307dda`

`dg-9cc4ba0c5e1cc046c590957b` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8da33beb2e5a20408fee7384dc01cadc9539fd19ae775b7a0ff222171daec52d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4e43a1a6efd4`

`dg-9d3a387ab9df3fee10493450` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/910599433e5733e27634c90ef88c096264fb537ed408ab979f174e1e26a432bc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `02a1f33baf3a`

`dg-9d3b5a311a7f41cfc196b6f0` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3f54c07d22d593b4733360093a79ac5a997dc4bc12cc4f524193d70d72fc64d1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d1814f415f44`

`dg-9d3c59660e8caff073f371e7` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/93c71a585e7c0273d7e26b025cbfe15174e630135e3c5550480b8115eaddd753.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7a03bbb55a43`

`dg-9d622418294763463a9cda52` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/70498dcce5288fe0a267d2feb969939d7994020a8a226ccf6fec34cf8f413b7a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `710a29022f8d`

`dg-9d648b3f63f6caf25ded6b23` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/31e9a13e3249d8dff969557a9a88d6c6f9bd0ecef9675a19f22258215cfcbb17.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cbaedda0ab7f`

`dg-9d6a182e37cb54b1c16d6e13` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/681e654ee505bf012c732d71b0d3a3e3931317b04d3654cfd16868eee40e480e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dd7270c92174`

`dg-9d6a182e37cb54b1c16d6e13` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/511a85cb874b3491480dd314b417a6e1b00c72e74ef5e09d145412d403ba1fd6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1245e6f6e4eb`

`dg-9da726311ef07d25a07ed6d2` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6430a73ecb3b73055f15c45c48d1ed01321f3493a517e83667f3edac911f3206.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `800e95b5550a`

`dg-9daaf1e79d58d8476a06d3aa` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/659bb1969fea843fa24c840fd4f0a8b4ac3c7509b7b626ba309041c2c192f193.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `599055f4124e`

`dg-9e169467bab7dc2548ba664f` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/b388c85f138b22d4a26b8bdb79d74cfc65504752f58410046a47d10870dc140a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `17b80bc8c829`

`dg-9e44cba9c69f184fb92cca1d` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ddbdea292576342d0c619e90a52991104780c51d2b5b58f2a03f427b04fc9519.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a6370911b4c1`

`dg-9e4fec0f01cd0a2362508a00` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/dbe0eeabbad104f8a36b33d2bac7c221d7eaee6e27fed3130626c5f89e74c576.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `33d18d63005e`

`dg-9e9f33802f912e4582627c1a` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/3a3bf9de41e79fa035dc61f75d1126a64061be0280bddfbd9dcbe36d6bcbcf30.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `093f52c7b0d6`

`dg-9ed0ab3b5529fd3dfd634f4a` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/ab9fd2072fd88b23d322b4a7275fe7421486f4e4010610180182772b93ccfefa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c648a01b9d3f`

`dg-9eff0d1a7d6fd1e14bd434bf` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/d60baf55d87ff46e053b99f4f54a85b50535b14deaf7632050c7063bf4d613b7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d9b499d483c5`

`dg-9f4f196b93eeec7c5bce13dd` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d5906b2afe0167b46eb0399d64dd81f6e1c4ee8eb924b6ac7bf973e77e550715.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `909e529cbd8e`

`dg-9f51f33492b3354dc767b5af` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/b259cdb1d6b2556ed5a7d7842def7f118a604900475c9dc9109e0e86fc238e66.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a96a876885ec`

`dg-a15f217d1f081a5af6a02586` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/f2b5955082645cc255a223cdff042dace1e1ae844fea7257f978a55a541f37c0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3279a4648c85`

`dg-a15f217d1f081a5af6a02586` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/81c9ac2a45d86fb30de7533f08c1f4e1352b9f1289cb7a257a3ca3bcfbeb3405.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9db957e932fd`

`dg-a17f3794f1e647dcafc726d0` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/dd22f558989b1180984f73dffdd9ca99fca030528b58ebf7cdc6f583ff153edf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `58b81a561abd`

`dg-a1a7e54e84dff07b0caaa958` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ef118e8bd8849e0e496a18281aff4a0b820d779f3c9414c97a06447249f1eaea.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3a16bcfd96bb`

`dg-a229286db3960b435178750f` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f7a03eb27979cc2c61c1267d813a42b2d4faf8506076a7b77658662304868268.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5682c72d6a3e`

`dg-a238a00f0b53fa2128ad4bd4` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/04e17de3cc843ea65e0e2ffb5d9f5ea9b8e62902b274633a1e1bdabedef16a42.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `716600910c8e`

`dg-a2411af783fbebcefceef4e7` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/8aacceb0ef80c1b60a82558316c256c517142e676601af322bfa480bbd641fbd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0c05164988aa`

`dg-a2b59af10144c65402926893` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4fc4e02dd99101910cf3843e2c2f7e573d823457918413838f0e56ce26619b6b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `977fb36a3d4d`

`dg-a2eb0e22de738aac239ce03f` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/946bffee9891cb8f45ab552e50936bfea767e4e47ebbe8e02342beec61e231e7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8a3562e4b01e`

`dg-a346f666d2fc64a6b412af9d` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/4e897adaf5d37d42cafc095413b0958333bd6d9fa7a633aff6253f3d119ab84f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d55b843dcc77`

`dg-a388b35c41e28d7a2b5d7544` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/05d6e9c2e5a2caba71c82a65a25bb337fc0f8523e1caa55e4e2e2be00e7199d7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c0711c05fb49`

`dg-a4cadf0a384a4052a3fff088` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7f8beba232f2205eb6575bf9e5da9b31cbf3251bc6a07506ea4918218c8e9445.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7d64a2b15bc2`

`dg-a4e485976b0be82cc72caf24` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/6442096eb02c1bc08357851e5902b68e661ebafe11a54335b7c2340a5ef6a8c8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c4a508007bb`

`dg-a56ab539ae67d4f196440d00` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/27376d565bd2a0399434ac8d3461592d8fb0d9c94ddc5b158a0cd02cebf4abe9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1aab416de76e`

`dg-a5c6135c394e9da48d732458` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/8d6e840e0474b18b8b34a47f8b7f5042970c2cddacc8b31fc99d2f6276425b06.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `691fe0dcee60`

`dg-a5c67e3d59940d39975580ad` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/767b0a2050dfee1bb852a10fd2c4b2f94b382d70c7abc9a18d11d4194b4ec460.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9014e83b789f`

`dg-a6693846ff3b52109af04704` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/aa93ace737c0f188d00eae6bfc3ed3b48912ca4cc77857a63b40bb5abace535b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8efd4b22dc80`

`dg-a70c68b8d8244c8823466c21` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d5757127e19852cb265e3bdaf03e33378f00c80970a8ee861c5ad8756dc906c0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `80ebb4a73d52`

`dg-a7542bcaf35f7024ab973f3c` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/a47255243c634d067b04d85371e44533ffe62018b51c881bdf8db799fd97786c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7c370c596044`

`dg-a7542bcaf35f7024ab973f3c` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/c1d7869f29dd8bd5ae009b56229f3ad6870822d3e5e756e58186103462dbba69.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d97eb8ea865a`

`dg-a7b2bbbf183edc900d29a00c` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/71f0cb5f1210a43b71a5fa766b8bc4f1a8a4d7e1500a255de9bb690fe4096777.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4d2aac2d3642`

`dg-a7b2bbbf183edc900d29a00c` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/897f8fa7bfb105a01e5154102461c9ce6bec499d6ce90351e53e18825558e403.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `afdf6eb68356`

`dg-a83d04664e422f1f6e4c3c44` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f36109c7aba4f6b594159fb770cabe51c8ac6da4f1431f3bd5d66cfc936947cd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b62a189c8b2e`

`dg-a83d72680badd5cb054e8245` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d50502d05b93a60a922653c109211ab859ea43525d56366436f2e8acd29477ad.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `06403dbe9c3d`

`dg-a87100d5455ac0969ecb9826` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0f43f9b8f677bca5002fa18e8b093b01172f48a9d7c6fe003ddc4d488979f28b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0e95b7ab6d7b`

`dg-a8d5c4bdea2ada978e3ae36b` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/e9a1d8efef8ec18003cd51472ea25b57a1652bc00d6666ef755f1b593d29a49f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `25c48d05a1a1`

`dg-a93a42b5423621065ab9844a` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e4596da0c440b915af66f53182d7a1b64cd651ef8c3b2f162846cd8c5261b1ce.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `40c0328a752c`

`dg-a9ca1489dd2b1c422be45580` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/457a2d990388a2db183383ad73a591f50b310be6416185d94cf46e665d15164c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3f3aa21f1235`

`dg-aa1a70dd52b137a8716ef081` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/910e9084d48be61cad27b2156f17524ffbf414d7c17e44b64fc2fe6c4b242a8b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7b74385e1ab1`

`dg-aad2609e13b457f5f09d0eb0` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: duplicate_activity.
- Attempt record: `runs/controlled/controlled/attempts/3f3975d6f957ededf8340a42ab03450e6ef00109984f12ab0c0e964c23d40908.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e5dce0f6d5ea`

`dg-abb9c737ccee90c9ad2720e8` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/64a2075908ae6d00c22a5e12f21c252f62a2a1858cf59cd6399d18eade40d16d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7cd70b29b344`

`dg-abea52448608d785cdad9757` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/cc16955e28f6236dcfa5454d91f3170af72fb654cefa939e221a22bf6ac5ce40.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `feeb630b7f08`

`dg-abea52448608d785cdad9757` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0dfc5a56c684933dcaa3d4d5bf656a1fb1663082e72990e08f4ccc5612468663.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `feb0c41a3a16`

`dg-ac632709b4f5c13218b7c9c3` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/91605285e4e0732b67ae9f3bf0c48752e74159b6f55fb0ed8ce3fe7006e7755d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2d713afdf9c9`

`dg-ac646beff816f0bad359c8b3` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ca5cb2d499b598af8c101af8d4ae0301b30061383e909f734383958718ca4ecf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e2a788a5fe95`

`dg-ac646beff816f0bad359c8b3` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/229012ed035e30738861fef7818fae7e434a6cd6e5e6617c382cd5b6c7238352.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a4d427fe1b60`

`dg-acc6a2327c269ec249444dc7` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8337ba2ce2d386ae6177b56f129a49ac16fba367937320958ea61e03ba9ef0b6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b7a1130249cb`

`dg-ace13631aee1aa325b6d0435` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5bf8162e6dfad8d232297db015119071e07239b5caccb4127d994a9e7f5e6446.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e6bfe2f962ac`

`dg-aced6e4c6644be00ffae2521` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/8404183e5d8912784108e9233ebe4b1761f708c550eadc1e001758b803f63c8a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e39427ad28e6`

`dg-ad13d592d5d3e0b1ff5fb37d` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/da7e6522dc8738c625a09336db39650da6625f46d5318826de6ab5257ca7e569.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `734433aded38`

`dg-ad2e243f065b143676f5e03e` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/54f8db814cdc9a3ecf9f9a30260b2de771982b76d02933514410d85e78d9bfac.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `da7e25f2bc5f`

`dg-ad42993d87d77d251f11c488` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/40c8dfc1da67b1dd655f703368c64e48ad393fed9695f3a8a21034d040291a59.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8f1a28b6ad42`

`dg-ad42993d87d77d251f11c488` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/15dbd92aeed29c549bc6b5dfbd090727b02e2fa342ddcc3187d473aec471c092.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `091e1aee74a6`

`dg-ad87165ab645d8fafc7a41cc` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/621861e9e19d007ffdd336a25c64d5a1d04804708774fca250469ac02acd64bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5f11ffc1be42`

`dg-ae0094944422579b1ab4c711` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d6f4d29f2184f6da539632e6ba468a62ab77fc34123e5819b1ec353b3148ab12.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b8eea4e13d09`

`dg-ae5f3196e84515f3a905fc07` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/30143c4643efa133dbb1ce49e99429f5d3070e7a1110a9ca9f2f6589b34b6c21.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `515f65839dff`

`dg-ae6c16b78be5244dba06ccd4` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/eeb067792b4c4009ddca7c034232050775785604c4a7d6a2013f1b40998ecded.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4a885f972611`

`dg-aedacd0836d5fd5f2e10f563` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0e7359ef3e42e3b5d9916ac90105f6f23474449a38eb03a002c139d59a3cce09.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bd9cb74c1eda`

`dg-af044cdd545a39a20ae3c248` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/682481233590abfe0bbcea6ce4741bccc0a7b29caccc09d796c76c844a9d87a7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8dc462f934cf`

`dg-af0b66de1cc5d327c348ca25` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/650fc732e6df4d7f2f5f1c9e7237de08434f5e5927d1f67fe39282f1e6aa16be.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b030baefdb61`

`dg-afe234ae85091a90ca03135f` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/25abc5b9f4f6d7daaf5976d5107328c4a8e3e4e72a247fade8613cdf090e1268.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0ee274b37fc3`

`dg-b06dc80c16fb519bd51e911f` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0630afd8177dfe9fc5037af898071a846bcd46538076e972ee54eae2ed812a3e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `36d94ead07e7`

`dg-b1254795cf353abd0c561570` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/f2e29a94d61b03d1c7fdca7ad19151d21fc284ec871b4c49401cafaf62092237.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5f2c20dcfe47`

`dg-b152125fa70bf11a7e1cedbd` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/38aa71ff0e6c3acccbe436bbf7e2a18f481d8d997438ff267c3aea8c2f083384.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f1965acf3371`

`dg-b155d746948e9f252cea841f` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/6a6b05c093d1e0d55a012f047e0d0a592b321bb0114f2f4254a0574cfd62ccdb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4d030b527a68`

`dg-b155d746948e9f252cea841f` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ca312373365c36068b5a63a1d14d6dae2b460a2a14e51f3075956b681c3537ce.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `35551b0f4c1d`

`dg-b19d3c6230dc1f15689bec52` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/c20b144ae536d6b4a94344cdd7361eadd850181c235496c7018bd5f7d58a10c5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3c50d08ad1a2`

`dg-b2020ca207e09708d8ab5a7a` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/62fe62c8f8603bee9d46e9aefb32287637b3fa1248e3f0cddd29a929bbdb080b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `90eaaf3d0b83`

`dg-b239a59e2b5b2487dc57de48` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/dfa01969bb0486691aa6961ee80d450725864512762b048500d62fd9e2d470f2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d13ad5044450`

`dg-b266d3dbc2ee8233c9f8666f` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/18f975c04c6a22ec6da2c404cdcab18ea16d1c0535a8f5594c9a4108f44e08f5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bbea98897c32`

`dg-b2a0e8911ceb7d11e282ff9b` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/9265e1a809830d86d21ba5be037e4aa2d6ea7cc3f4d70bc8fc7f2ab0d91f40f6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `32212e0fc542`

`dg-b2b55e945759b375fca72309` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/726757cf592279e74f0b2c4f4e28730aa45b72336ee58f62bc97e220470de8c5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `97ba78cc3165`

`dg-b2c59565a04780a72bb4f7a5` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ed1f321d0b36063d43fbf4c4c2c9cc2d586013ee07329ea0c3e383cd4cf579db.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c4990489a8bf`

`dg-b2c59565a04780a72bb4f7a5` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0817dcc14668e94e16b1d27cd9159125585d31afec2b4a12be5b90b8b3d2d950.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `10c8df4657b8`

`dg-b364054c772e1c8254bd5fd3` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/a8540f044f04e29e95009bfab3f1e667ab57a85257ec8ef8bf5a910cc4ee6df5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ab5e70ef1cf6`

`dg-b364054c772e1c8254bd5fd3` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/9db459f0a1e48ff052b0a948c6d891b6000e9b3e9535efaa1afe223772cd2971.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f5f6311d65e2`

`dg-b3859a44cb70563808b0f3b0` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/9afd3573103db7745e12d2dd906f06d06d94d4d4a4beb227fcb01341abc0e0c2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6b4fa9b43cd6`

`dg-b3ebccc31a67fcd2151ba90e` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6409a473dc20b3679850b4de7a43afed1634c3f57284f4fc0c77655775dd909f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `14b78e4f472c`

`dg-b43e6bac9ff9f7ffd0564523` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/79e5393ce0c31ed0d14e27e7bd1f9755f2117f18871668452180c648c1eac25a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fd8201e27524`

`dg-b4eadef3cbc2f6648789d369` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/bf216edc3fbc76d91592bbd54adebf90c73602bbb391da97683af832824a7eab.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dcf654d64105`

`dg-b4eadef3cbc2f6648789d369` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/217fc96e472c58f5c3c89b9dbbf187a5673c5c237e7cae790a3ea0ace0985192.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2b54d266fdf1`

`dg-b53d5032ba8f987a6b7a67e5` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/861fa4850b7749ce9a51af6cf6720bd325f8aeae9fc007121c4bd44defa700d8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `247a88a7483b`

`dg-b5b15036d600099dabdf2f79` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/9adfa76542df208d26fb934cf0a3fe8df220205fcbc4d661fad4a2f2aa46c46e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `30f34836f69a`

`dg-b5b5add04601b5d562d35e16` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5ad3169fa40f610b715381522eb79e3eefc47c8dea2bd3f485c3896987274562.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5bf533c4fcbc`

`dg-b5c8a259f66a8740cf9c1d7d` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5de4c18d9dd5fa7eeed2678ec04b01ad7781931a899773de0780016fa9285f46.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `88b4f1de6a59`

`dg-b5dd05963a023d5e8abff3b1` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5a6b31a386eb617a80b0e980167ad01cea8b3eb3259da2c8c8b71d0abcdee86d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d62806ca71d1`

`dg-b5debba385c672da4267a666` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/e72562d49f648bc97c8a8ae4df3e7046d7e9a73799314bb9aae4de7cdaa946c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1663e22d8397`

`dg-b6817fe573c0d4879635301d` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e1b56997a873d1f5314bc059ddb53de766c28808e7ab25df9c32b174e50b1ecf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8a569659667f`

`dg-b682ea70580da2ee8942e5f4` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline.
- Attempt record: `runs/controlled/controlled/attempts/e291be41a99a19aa7424491dd0349061274c1cfa7ca04718c213433b54adc6ff.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c5eb8857e1b2`

`dg-b7b32fe833e69d446e666de7` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5b19c6f8f5bc8f295fcc9adb4520b54816e0f64a8872b2b3f786b972f85166bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `642b6be5bb0e`

`dg-b7b32fe833e69d446e666de7` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/8e6774e437669628a1e0061fdf6a336efcde28e295dc3b9895d3397b70052690.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6108822d1c25`

`dg-b88363dea41347881dafd903` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f0538e0f52c7dbbc7e2be97eed6271172fed39fb15a5403f1de580e27a5e4409.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `eab05b9b5777`

`dg-b8b9a31a33e372247f09c958` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/183d2121a0aef3266375839e4f8e2e511b687a981f1637311308a0f9f1587cf7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e7d3ecea6096`

`dg-b8d113936266262772942444` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4d309a22706821b03bba13e24dc146ec9db6d3b892c57bdab6d466db570eb2c9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c2ba5c990091`

`dg-b9b621a7b49f933ffaa909bb` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b3572c8a2f4743b836e2db5dd2f6f3775bd77045f98df2f3a90fb7caaec72493.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `32231f26a6c9`

`dg-b9cdc5a2085a8548eb22edf1` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/00cc62896e163874b896d27e5663314e56c3c2df3a56092f33b072f16e7f348f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bc4a309c40cb`

`dg-b9f448f453474a0e2e395c46` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/728e120ef58eb9a41ab3abcf44f78f26fdfd1e4bfb5f08eacb69bce36178e68e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2b9508e2b3ae`

`dg-ba5b6e22459fa4cd556b1e04` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e238edc2541392fa08652f032bbc8411c61fc058ae6ed381cbb5d60e2306cf4e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5260903e2007`

`dg-bb2e75f29386cefba2e11f3a` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/0c049f394102b2e5460ef2b3e6cd31cd4f5636d54554a22b7c1baa20128d62ca.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8d21cbc94385`

`dg-bb670e958d969104859c641c` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/5bbfb2f024255dd76645e3e858417cf0958073aa51db1a20644e2364e0f01efd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `07a20723e822`

`dg-bb670e958d969104859c641c` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: precedence.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/03079a22b3450dbd290fcf99063b7807cacd1459ec7af0b67a81a4bcaba18a10.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `14de22072a69`

`dg-bb7ee76032543bd33afb2b62` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/a7709b5b317bf3325842dac62063c835553ed0e59780c7b0f82701fd963790ca.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ba3145e865d7`

`dg-bbaa31caf0eda49af2361cce` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/9bac4136f847cd68ff3ab353fc71a2998a745e672c3761248b4fa036ba75d252.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6d6d861f4613`

`dg-bbd96ba4f98751fc41ed78ec` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d549e22caf005a8484b3f9e3eaef6f0c81544cdd31f2a224c72390e845cca27d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5aa0c7b5c628`

`dg-bc34912db9e4ab5544fb0b35` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d451d109fe9555ccc1f6fa56ad4d812990b88665c207beea4b0822e4d07a0c9f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `296014e5e2ae`

`dg-bc34912db9e4ab5544fb0b35` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/af7f0848b705cf0283b7d99de471db8748cb0668885a6db2e3b046d83cebdf70.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cd1ddc25cf4c`

`dg-bd905c541bc9926b8bd9ddff` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/f7fea0ba04f854a92993743be2e796475c676d654c809471d4c595ef6766795a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7d74dc11286c`

`dg-bdb42017b37c63001e173034` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b554e8d0be726dc36ae8c15fd7bec9dd355bdf432cfc521120790b5e7048335b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4d202a98522c`

`dg-bdf826b31a974915abf4371a` / canonical / direct / easy. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/a77665dc8075440579d9ed8532d100f57ec96eb6acdf23ea4b8fe80dc5e403df.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4b940fddc856`

`dg-be2810ef16915947e6851513` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a24d5fa3652b5ab5c86eeba15e2b6d89d20b65b9a1ed8f373297ccd353e36a6e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e2952d65c594`

`dg-be99efd4f0b7ae5b8b5884d7` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/ba291ee78f5dbb6f521437a90b62c982dcd2dc5c8c3fbde685ea9ea5d59518a1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9aabf22594d8`

`dg-beec9576395b9d2472c98ea3` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline.
- Attempt record: `runs/controlled/controlled/attempts/668a58bbf456925d4eb96505e8b16455c2708d66a9c13efd5b50163d5b134933.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a1edbf3c8384`

`dg-bfd3d31c67805bac350ebeed` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/740c648219b0ff838057e8a4f034d2c7376a04cb9534eb287dd4f63ca53cbf05.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7d2c722ed94f`

`dg-bfd3d31c67805bac350ebeed` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/5033d99c9b86ec403332d7eb7f5ddf04f57ae2ffd5a772f9031006c8813aed38.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8e018c04f2cd`

`dg-c073d643b7bd3840d82fa306` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/4b400d087b1ad007f1c4b8f6cf4bbc283bbf0ece68fbb69bece761e261746778.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `14dffe8084ea`

`dg-c0a49a82814bfff169c18c4f` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5b8778f7f3c2ea10f538cb111195c1f1612f1a6f54db45c78dbbd21707a2179d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f443d91b5f54`

`dg-c0d0adbba64a906ddfbe21eb` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/87d2feede8439802535a1986a64a779c9dfc0b7b59b913b7e762a10d85a318e3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `055e78ba80d1`

`dg-c10c167833cf5a45864989b0` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/20901260cb3e205b3bd03ce2ad0e2b01efcf6211886f32c1494025aa79a9d7f4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b9b723d796f3`

`dg-c1318728c13b1ec232c4e6c9` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d14ffae242af987c028cf4626b4ff6760b43b858630ebce9d6c812f47312209c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `13355aa03887`

`dg-c1731ee0056aca459928ff6e` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ca9b579267ca1d805a574d4a806d0e6f80ef09ad01bf397c50aadece5cd07196.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bff5b3aff5a1`

`dg-c17adbab11203ce627cc6753` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/7958b21a816a559c8e0cd53371775169740ca9540ff295050c66cb5a7ebf25e7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6d02f8aab7ed`

`dg-c25f19b05a638c418aa778f5` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6cb2d9c712086a2259aa3aadedb7e7f78dc1f4740d3ebc67ac735fbacb12d259.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ffba4929bd9e`

`dg-c289a32efa923d0cb3e54748` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8a282c6e64d4fa639e7bde73d4bda84a8852d20f8d6d2cb06a3a13cc96f6fb0e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `98b4c7c2c8c1`

`dg-c2c167778e3f5323db9188ef` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/497e301a14cc3ffd49744796e5564bf319a5e977591906237dee595ebac2802f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `39af06a939bc`

`dg-c33b6d97f25ad8bdab61dbc4` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/e2e64ebdb6b89fe45bba0e472bbdbdde933c1cfc7c52241a38021026bae72820.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9969e3fe88db`

`dg-c44dd05d16c0851be57963eb` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0d78c1889c7cc66318bec5e64857ac60f0baad128ea20321468587a639533b85.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `20d40f9d5ba7`

`dg-c450996ce7c2c4dc01fec651` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/660e4752f303c57c189b19fbb17bf60c2b130041c2abaa9415064a9a32af2f3b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8e17b36aa3fa`

`dg-c4cedc1281fd98b73d83ff28` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/780fa92265d2775f20d847793ece74a161a2f7c4d0de905e5fe0938b20ab3309.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f99d194893dc`

`dg-c5320493c339ff0c960c96e4` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/010c01731ee9f923bee2d551e56c1842ef903ba0a54629b4e050d9ee85a0c2a2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b8e112536d80`

`dg-c5633892debc0461e8f1e9b2` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/cdbb76491754bc020a34d8fc40e0ee87648ed0f7a248b0aacb4406a66e68c75e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b60a494d4928`

`dg-c5920a7f206a49b488823cca` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/7ccd13474e7f9e8f401153c00a0d69198b5b519086eb02de5f9d1c85471a7967.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ad59a4c6ace1`

`dg-c5e19c031297f65f130849bc` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/6cef06adeb95de54c217409fef88be78361a68c9c65782702cb391e873d416b3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `947ab1b003b0`

`dg-c6049eadcab1a80eb6b2f1eb` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/2a08958142f2eb29d71d0a462ce8986d9bfd0d662ac93a04dc2bff607fda7955.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `650c0ef871e6`

`dg-c6530b23fb34c31a28d71b15` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/e7f7afe43ebee20655f180a34544d7e37985a3423a68bbdad4bc9aaf97d8de04.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4360e76d82b4`

`dg-c6b31eb54818e334ea72e991` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/6dd1c8172efa617703f84c6a9f867a541a6a0d8e30efb9013ce44f1c12deb20a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ee30f9f9bd01`

`dg-c6ea9da2f9f7bc3bf7471917` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/00627ffe5aee97793bc11752c831055b84ed81c0094109022b411a89dd15d376.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `59f0a69cc50f`

`dg-c70e7a1200bd5dc08b754b21` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5aef248f726153b3e62f8dc72c8534b7fec69e5b3799a9b5f0723357a61e6faa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b5ff4e8b8eab`

`dg-c70e7a1200bd5dc08b754b21` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/1ab1ef87224d078766677656c5b8fca31810d372bb3853dac01f2fc81e15d5d1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f7ae40b5ada6`

`dg-c7924c0e5faa9720705ad359` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/680dbfaab850932b0d2b2727f97ab0c5c32b2e3fde577e8effa2face0d95ac4d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `555a6174a865`

`dg-c819d489f5772ba5a2508f2b` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/db90cdadab0fc75ecf71ccf836c95ca525d6c90abbe4c79bdcf465ad6e46ee81.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `34cdafd10abc`

`dg-c83c7fc4f0e0e6156c76dab0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/cc30c45d53add46bd268e985536ec0632905b1c6e8bd991874ea60fe5acb7e89.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f7696a4ca802`

`dg-c85c70d9a2d8b36c96e953e8` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/766c9727a11800a29d668caf753ff9980aab94ea111cfe071ab1342fd3a50af0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d124081bb84f`

`dg-c882bd603f11046634450489` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5c027d565b42178dd75e3a263cee213019592e7f165c0549bf4841cb3754df0d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6358941c64e3`

`dg-c8c72622cb0193712f090711` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c21d9b698572e5821b1e2bf2db0ddd7195adaa8dba387ce0c8e3c44c65dc3411.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8f5040beda6b`

`dg-c9133fe09ad086512cf41b20` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/64c550e8199b63b21e51d7353b99f0d2beebfefd8b4a8bf9f4c853012c44c9a1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8890bf29a22d`

`dg-c9133fe09ad086512cf41b20` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/27113c6cd6c8df478e0496431d7761b137c4fa63e59f54ee89f557ec52fe82bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b6f23c710d4d`

`dg-c98dd9c884eb3780943622a0` / canonical / direct / easy. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/689580ca8211e190ddbf631cea207c8aa056626eac07d4dc50fe5da9e71203e5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0e5d62e1ff9d`

`dg-ca042284e7cfb3fa29b17d76` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/958150c1001728c6b41ca29fe6356da33687c865303037ec6791b391e46f4d18.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5385dc5ee94e`

`dg-ca042284e7cfb3fa29b17d76` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8946b47bf2a8c28cb4c92d3cd3e2e228b980e216e954345a050a9aa3f0e8f930.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f45264316910`

`dg-cad494841f946bd3597f094b` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability.
- Attempt record: `runs/controlled/controlled/attempts/a686cfd3cffd10987e4f6e0b4852ab728e33f2bc002fc57e22bb88dca3553918.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4250b2c855ee`

`dg-cc1e3edd86a813f05131cb91` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/4ba292314e82bd34e5fe29fa5a1f53e1515afd3ad5b847e719f0a6f27386c55a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ea3db1862300`

`dg-cc3c156fcdd7284caa6746df` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c26c899b6feca98c4850409eb139cb8f04a455164755c423f5b763a5b7bcabb4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `30f967d4fbd6`

`dg-cc3c156fcdd7284caa6746df` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/5b3bc6fee313d2f932c5d0ae4a109690ea29108b25e7679dc2f9f3c6d3bbf11b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ec768af22027`

`dg-cd2b88c9966126bd0ec77817` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e87684d26920aaf46904d1b3ead2db134ad363f1187667309621399018c1b8b3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `390d81ca61c9`

`dg-cd78b62c5cb8af005a2ec5c7` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/08a0b4248f0f7185bc49aed49f1379af0917d71833aa20f5f022c1de31416100.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `86bbc567584f`

`dg-cd78b62c5cb8af005a2ec5c7` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/72bd26ccca45bfb0519ad67e950a4e1744001b6151bd68cdb55711562f2baab1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d854e28d9432`

`dg-cddb9f6eb90fa67e9d430a3d` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/aae16686d7967d3135f0ae016f187d9b80dbd5dd70e6d9ac85578eddeb55c7d2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b43637704a0e`

`dg-ce0313ec294d51050008f224` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/33970bd6f15ccc8b310dd9df37bbeb13fc0108a93268dd3be4f0f4a12906f46b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `28c522618043`

`dg-cf04d4ecef68996a177df308` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/dcd6c257b2e85e00d997ed99a6d704c12748294f3a5147bbfd1f0a409f28d353.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c4c71ad4c8ea`

`dg-cf52ffaf9c245ec11d04b1a6` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/082463b7555f62bd6a59817d3185183339a686005dc62905214a0526355b7460.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `03c9c813072f`

`dg-d14574daf687da96e6404367` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ccb74a526c0d029ab0ad29f2fc2897fa04ca947d77d1985abe590cc769b3585a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c76dca88de6`

`dg-d19e838e25b13d8f72b35a53` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/b569841212b0a4a8335e0b5e06fb9f047752111efca03200b24ebd4c3a1372b3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `414e42fd98e9`

`dg-d19e838e25b13d8f72b35a53` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/5563537ac0af05d89e66c4fa6f66f6f4c6f44e125b430018cce768703614cc24.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `47e94150ae7d`

`dg-d1ec0d6e0963c15ae637b268` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/e0cd761100358e58f53e1513fb40ba4813f50449ef65d70662915654071ff754.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e62e66c56f8e`

`dg-d1f6a526485fc46cd80e7da8` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/75a7186f32265aec206e18d0f659a76712cd78409448bdc1a3ff1cf0afd10cab.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f0db26410e88`

`dg-d20016ba70c9ed61098d7028` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/9e2e671b34aa1d84702ccc69dc020c4f794a10befb32275601ccc0faded90515.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a8cdb4f2b5be`

`dg-d2b939328bc1b555a527090c` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/951705595b51c3174a7a65ab30987cf75b2fc283e8293562fafb7a30b9a738c9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2edc23b875d4`

`dg-d2ef7e0d399c209cf5c15b57` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/f52ae9e938d438ddb8c379f252d8f86d56c1b41d90c1393dd9d1138598b136bc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1ee397fc36d5`

`dg-d3d784c3615ec6e21688386e` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0d058718745f34469cc9127e2fde61e38492bc490f080cefa887f1a15045245d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f575f1ff8132`

`dg-d514cc6bff0dc41ef8cd44a2` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/9af983d9a88937743ed29e20a7a9c3a8da125c268484f2fcfaf89026ad2035fd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d746510f34ad`

`dg-d5413808c6fd5f890fd91872` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/41eb79882b1d1086cd0920ad4985e966b09012fcbea753f8c1c877055569ddb9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0fbc1a048425`

`dg-d5413808c6fd5f890fd91872` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c25c65d39cf0563b3c15938bcdf6352a434e7c90d8613917cfbae3ea81031c03.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cf79bb584d97`

`dg-d56cbd7b82443127ccc944b0` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c3a2fce5defe3a38506f4ef52a828b5aac6c5286619347372ca9594c57506d40.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a2d933df493a`

`dg-d5e7fc8c1bd6c104f123e099` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7888f6ef9698ac6b990e693c60a25848885972face04777046ca82808b22ac2c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c939a140ef8f`

`dg-d6195ffb778aa07c166e50e1` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/21545621489ef6b311a1977487803caa56f8c68877bd6033b466a8e04390b0a6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e8d81c8c6aff`

`dg-d620f51058b6be4f6e27d2bd` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/ee254e9868dd9ca5b83a6f46c391ba269da892a1bb4201614b90adba496d6e5d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cb36db71f9de`

`dg-d63b3aa8271891e48a7ea81c` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1f0cb1113f3fdae7046af191f6fce452833ebab36ba1079c22e1bc7b12f822fc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `46398c06f8b9`

`dg-d678ef1e10e835c9f3d4bdcf` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/ee440e4a1e20704314c6cd202593b35bfc9aac6531f5dad3e09d35a84bd9b3c1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f65d3327eded`

`dg-d68a3de6adc575e67506c285` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/aa6ecd7ab2f50b8880aa6e71c2bfcce084e39219d69b8829d8ace67952548620.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2e970eea0aeb`

`dg-d6dfce23d10daef879c1494e` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4f985b9b651b48bd9810bcac004981fc0464f0ac700700a2202aba529b9bac0d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `931c373ec894`

`dg-d70ba58f2113f6959d0b429d` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/746b592f2f58262ac128f71966bd577941965cd8acc3f5377a48bd52c0f44949.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7b4ee8927a76`

`dg-d72927b5b59dd9f15aaea3ca` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d364dd7d3d97b532b22ac99c503df25fc394e00f735aa1d3344e5566f415c04c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a77c4f9f6361`

`dg-d78869e0046a90d1045d142e` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1d7ce7b0574f5ec0486a22ae2b4ba41c79081b7dc0e88a42814432bd2b0d64b4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3f8b05b1a4b9`

`dg-d79c05887d6be85eb72ca25a` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/9a1c1edd6cecc291a8ac7abe0c30b5088f9bc7e1613000179c8a4ee956b35e91.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3ffe1718a587`

`dg-d7ff76d667fb6fd7bb8733b9` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d625c5365d9d73d6956d8a86b4e37b6d27aca0443c90ae05ca22c777c0fec05b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `994865995826`

`dg-d80b1fdc02db5ed640b9c501` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/da0e888585cba783bd8773e3105d9b3d5f06d550ed2314d532709602623eec08.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6a29288c7b2f`

`dg-d9064365d3a47a06d08349b9` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/46af406bc5e1cfc84e4371e92420bdd08ade56061fcc6de4c515a5510ce61206.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `10d4959cf457`

`dg-d93b27189da13c48bec8d5e5` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/d51581917b2a7cccee103d5eaec8b6fc80675eb59f22950b56de05dfda5af62a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4d831548f6b3`

`dg-d93b27189da13c48bec8d5e5` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/94297b12139cd1fb804633382318a2336846e1c2ed8a6ec39ef9177d8647b86c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0dea54c2fffb`

`dg-d949e0b62c3d0a8cc0dc7087` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/75fb2f6ecbb3ad90d60d41750e52afd3b3b56ae9ff91150f48f4e2c9e5e034d2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c892cee79a30`

`dg-d972266691fcce8d4a270e32` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7585be26389cee2f153faedb7bce60ef7ee21acdfa97442be79d529bb136a7e3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dc6ca889dbd0`

`dg-d9b38f402e0bdb0130f64b07` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/dfc3c049e74167a1dc108fa9bc43a301a4aad1157db994f1bad1c9a09a0d77c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `45612e0b1a01`

`dg-da45c9df809e6a5ea0160578` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/6c2499a892f0afcc49c0efd91d56fb47143fb88ea2716a86814efe7245cdb679.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `51cbb7c38bf5`

`dg-da6942e74bfbc83d8ce739e7` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/5b96cce3cdbc2e9ccc728ea6ec0f6420367676f9ce0db67ca0f1e665538d2036.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8ba18a500c0f`

`dg-da89918b931692746eed08b1` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/9b10eddf6c41b1c26c676a79e956eac03fa068a88375930d42e7e6424c8f5f85.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c7982eec6092`

`dg-db7d5fd529c0db000fe198ac` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/216645bf2d0e0a8ebd791ad61ce4ed5c984b874576ffae6d3a2dc9b0e95a7b1d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ed2d223b82ea`

`dg-dbb9d78445bb40be3a051c09` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/94803c2734b5700ed887f1025e4c0db5cdd1d594080044f542f2b0041dac003a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8d704999e812`

`dg-dbbe4930940aa03aba98fe0b` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/afd765f9d5fd1eb9cec10c868acaac259d6129713b9f9980fbe4e63ad32b2cfd.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0c55a43f082e`

`dg-dbbe4930940aa03aba98fe0b` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/cbff44c5b1d0e503269179f97dec1255eb401f31eaff9f29375c36abfda104fc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bf44c33a6bc0`

`dg-dc173165b3b50d17dcc98e0d` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ab02d1bbf4e17daa1d235e1cae430dad25b268eee3c5fa72de97efa7fb3863eb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5ad863a69cdd`

`dg-dc65c6bd4d22eddc69228ad5` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/01724dc525a8ec49574d83db468eb2b0fbe2f196ad555aba4162a00deea7456d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `915c6a905025`

`dg-dc9f412962a367d022d37f86` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: duplicate_activity, missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/a0d179cee2035a808bbfb13ce434bb75a7c1ee7cde9b70f02ab1963c71e10678.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `857d206f55a5`

`dg-dc9f412962a367d022d37f86` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/16c564c1ec1601a51927614090c815c2aca7b36d566991180b928ad119c8d360.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7400b2dad72f`

`dg-dcc6c3463c2fff40a8b384b8` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/60d33a51ffeaa4f53443cb152c26624ac17225fdf4d4a337981bc194f259a69b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e28f853fa6e9`

`dg-dd1afd54eb4cf25139d01780` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/dbf937822e75d5ec6f0b1d1e17df6673eddc30b034f591f4b4f8d41e8ed92f3c.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `676ae69d255b`

`dg-dda16038e1157ad8878f3a4a` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7d1a5013576aba0548f1f601c9419bb871dac3380247a2ae701667e483a2f2c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `bcffa33eadc4`

`dg-dda16038e1157ad8878f3a4a` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/906ccc05f5cc4f3ab14ce47cafc48b569961942687b986d898c89f9d3bc54609.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b2b183fd3083`

`dg-dde5eb5b79b0833507d4fdb0` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/b327fe02c14b36a8f193d92bdd60163de9b56cde1fd5153b7cfe4f9f8ae36cd4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `de98ac114c92`

`dg-de34d161630d59fa1e2c3a9a` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/3664109024482f173392e9e1fc13054498b19f4b138bacf2e950368417f7abad.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e0a28b62eb23`

`dg-de54af75f114879b95b959fe` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: deadline.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/fc3e854902d2f0b532da5bc29197218c132a7d9a9fe9c2634a8e37abab26fdb3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b01e31c81ee5`

`dg-de84ee2401e8b65699f01f2d` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/1c32a4a181ffae4c6374aa0529323912da63a756617871709fe09a86e6ab7c5d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `35eddceadfed`

`dg-de8d00479e2a93d6bb875a32` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/73c358b0a19c5e6db88f3788887ac7d674928095906d682f204f2d17d0890f3b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2ab8febba4dd`

`dg-ded4df14485868b215f20eaa` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/b44387c1a0d3760adc0a6fc425fec6292469c04d875c53d710ba8b7c1923b479.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dd5899266b2e`

`dg-dee6c10ab7ae5f3e7938c11e` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/94f7ea6dedcd426c0a533bab1956c3298682a052eb066d30225b33e4c5df76c2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f97fc2ba884e`

`dg-dfef5561d67123b3eb8c0080` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/f3b7157dd519c2820a5ca356ca205889e4b8355a139f7a8427c31c287364c641.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0f56d02109af`

`dg-e0358dced0fda43f5e42f72e` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3cb6d5aaa8563503419591ff1ae7f998c0fe1521ca4db761c38c55db58e6ecb1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6a53fd85f1ff`

`dg-e0358dced0fda43f5e42f72e` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/1f1e4ce1f1f7446d61085b65c061e85c0debba14ad39a446e5228074db887d98.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `899f9942b47a`

`dg-e049e6d78f0e3e75c59f7fff` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/3018e0c615aa950ad92c1dd0f5baed4ec57dc93dec142c02b8b8b08bc8503f12.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `af0ce0bf6cbe`

`dg-e04e59946e3b94caa724bfb5` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/b35825439c4263213495011ae7caf4c3a8a8e96f700174d79d7ee5987add38aa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ded04427ded8`

`dg-e060af8e586f15fbcba80093` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/cabdfbd0a7c4f978bb237b1346d3b0d4b9e4239e6db14e6de2b13de1620692b6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `062966fdc023`

`dg-e12eec58ddebcfa2807e758f` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/feb12a8dbfff6769b0346992d3c603979851f25a46e61ef020d4a3463a4a7427.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1f9157f7208b`

`dg-e130423c381590a04d858a0c` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/7cdb32502050c2864da83ee61955cc4990a11fbb3930b611f0673ebb240a1026.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d8f37fe419a1`

`dg-e13322df7c70577a438ecba2` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/a134dff424f46f7741a2db22d128e1ee5015897aea207832c537921b659dbe2a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `271f7f84785e`

`dg-e1998556d82caec97af5de55` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/8fc8c8f772db5162a2ea0a384d5cc0b4ce9ae143f971078ffa00ad52944efa28.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `98d442bed380`

`dg-e1aa9328b4c30a74aa5b9df0` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ff38235a4ee68b15332219df7f30e9e3dc888c7fed992e2701d32fc16f18efd7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `07f1cbce83e0`

`dg-e27bb91b2ce32a8f9f84c4fb` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/74217eb2142b8eb7c2d0c1741341194bfbeab59ba812177544dc9c4659015ea4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b13c130752f9`

`dg-e27bb91b2ce32a8f9f84c4fb` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/b5cb1146f7da804b0cf31fcaf5a28d39e9b0c6e425a89e302b89321a0f84956a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `754c11284bb5`

`dg-e3617d486abc4d1c3b0a0a4b` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/c082ffa5f5a1c76607260d7ab7276117508676e7456f728d7ede25b9c19ad02e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `68a0c06710e0`

`dg-e4e6fb16c53a0239fec648be` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d4efcad64906a61b1b78891082e5fb93e36d937c94401d1a09cd253727dd8887.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a5fa3007312f`

`dg-e5318031c3b02d85e45ddc30` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/9bcc9cdd5f31f825e0629909a9627c1e79710d1b17a55f4b67ea9642b2c2259a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6f0c8ed99bda`

`dg-e53c3c76efaba24dcd5335d8` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/1289b46cc8c5ac1dcfc9561f211753f1cb002e5f6b182cfcec8f4ebf71fd4762.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e92434d44925`

`dg-e5566b96b9254da9e587e4a6` / canonical / direct / easy. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/0943bd1fc6bd9acac827f2855ed6b4173bb59b440fcca2a3da6ae88a79be983b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7409f02b4645`

`dg-e5b2846c84e02d62af04c011` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c5c07763761224e8814a10572b960e77cd412af0b1aebce123c92122af4388c5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9d8e6077c685`

`dg-e5e674937352071591d5c89c` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ec8f3a57366080e3d628bb29352be2af6598b0a736b7788f4c2380b755ddeca8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6a8133ec0bbd`

`dg-e5eef8f569bf0db9ac9b9697` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/ff02cac65492c9e26a904ac0e36118bf7e0694fb0087dd9d4434f017037f6fbf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b5fd9e0785e1`

`dg-e725547d07aa87b40fd3bb27` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/4976d33742973f77c7b323f35f5d8a0725724b2d26a4928f651978fbc8f00614.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8665b2eafa1c`

`dg-e740df0ee42437ef05f28303` / canonical / direct / moderate. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/e21ac42f16de6613a0f875f3b4be214c7c01426ef0064a248a6bc0aebec6f9b5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `46c05aa0211e`

`dg-e7a4698afc829fb874ea0f2b` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/584c776cd3677b1c98f2503083a4b806b625d1d10f3195572fda1baf3ef05501.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `df556701a103`

`dg-e7b119b5d7aac2b407056f18` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/8491d7301adff31af84dae69f9146ffe98e9dbb04e0f9920a71d7f60041951eb.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `36db59cb03cd`

`dg-e840ec96986c63e81b4d835d` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Gold validation found: missing_activity.
- Attempt record: `runs/controlled/controlled/attempts/f1db8fe738661a4c4153ffb9b711b910f8e0257d9bdc4710204d47be738306bc.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8e2738988a7f`

`dg-e8575b62362ef3a80d5de4a3` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7562182b0e2c5078d10d89038cc5d1fb9e484e9047b72733f1b0ac90741cd733.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f39dba48431e`

`dg-e87ac75217db69c1c3eba981` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/f909ed7e787993c0c6bc3a46fd0f255c79121a70094153fe3607daacfc5c86d7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `29321bab008c`

`dg-e8803447da2a3c26fbd12cba` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, precedence.
- Attempt record: `runs/controlled/controlled/attempts/ed7c0323215a8862dac0199aa3c9b583247ae946a04897bb2bda076b8c3a6cbf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cad6fc3a145a`

`dg-e89128c0a858e1020f03a7aa` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/655b9e5841b5166a364c680cc5804c4515d31dda2318ae34e4881368bb2214e7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dc1241a82f42`

`dg-e91052fb470151cf4dbddb54` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/bd429aa23f6ded7408da12fba2c72d44e5a03f0149d410872aa040e07e90483f.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c7d133886564`

`dg-e9149b7bc10be1e31639915d` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c7cc3bcec1649a50dc4dbba28414595fb319fc02fa6d70c8919fba4fbb906954.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `939f5ef05d06`

`dg-e924d72001b7ad2dc508c806` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, fixed_start, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/230bce103293fd6073de36c8aaa2105118ebaa094d247bdceb6fd7e79d6bd59d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a897014436b`

`dg-e9449e2413d77ec7070c48c4` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/c037c8e443d6a5045c50cd203696f8d3aa37d8a49e897a2087a56e666de1ee16.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6eeeb373f210`

`dg-e94d9a00316b374224cbedf8` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/6f75adbd9431d5412dd4bfd7007a1a1cbf3fac2dd702432ba1da4f32ecdce0c7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `04027aab2591`

`dg-e9882b4ad6123116c94d16d1` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5ba49afc0e65ec34fba1e6e3fc1550f305d07cc80dba7902e46faefabf98dad2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2cb6fb402c09`

`dg-e99121a6e0fbdd4fbc8772ef` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/bd835471f6fad6968b20099bd7b5d63d2768bb8eb83df0e0f8f6dc9be0f9a622.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `8c64ab0ea743`

`dg-e9b721a8c61e1d3336a4aaae` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/e618c7447c2be0a157a57e5821c493481023076116f5e61cb371eff5aba2d06d.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `19010a47d9b5`

`dg-e9c46fc4a7229dcd8adc0632` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/1496f3693c76ac04cf1c32f5ca4181473824efbb96cd417061081c7f305efa09.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7abac6bae56f`

`dg-e9c6e342fa701a460e149b78` / canonical / direct / hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/dfa73e8f40fc3f0be9449c5b8985a7ec88cbfc6ba363a140d0327d671bb4c131.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d41aae2e717c`

`dg-ea441dd2da2e12ab7fb096b6` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/db130430ddb9b4c9b145a5c2f0b63f336f1497494215ec1129a70046ffd62f41.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d66c1fc5a1ee`

`dg-ea5a0fa6f00b4b5c9a827106` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/620f09c3becd3ec4f7f958532b9b57ac985450fa3dadd77a702f16acc80a5318.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `55120e372d06`

`dg-eb0b18fcea925b5ea6bf5d00` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/8eb9d4f5b8488322dc6638225b7176fa516e527c0f137d3d59b0879d5b8f48b8.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a2b9a0a93200`

`dg-eb9f36a270c084a3b7063287` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/70360fca238f0c7a4e48048dca3333c6465a96f5bc80b8b5eaddca6c37d702bf.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `467b7236f1a7`

`dg-eb9f36a270c084a3b7063287` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/489730d71aa8a7c9fd55794c516cbbfd8e50f9d2fc66c0bef33226618f31d9e4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `88d0766d2be3`

`dg-ebb422a3b63ab45b26941740` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/76d5986c6c6230c797195be5d159e0f908d4f0cb808ce4d0e1b0a02c5cd6c267.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `a10d274b55d0`

`dg-ec20b5a51caa43207ef5e7ca` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/144180afc11b5e2539fb3831c84e7625ddd9c858c403e11c6272ff0e5dcc2ba9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5690bbe275d8`

`dg-ec33ded944a24f124b98389a` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/f9e918665bae86b0175efce95060328f4da4653c12dd886cf66e387e075cb0e5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b5221a6d6faa`

`dg-ec66dc926650096426fec48b` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/ed8747470ac0919f3a4a568fcebb741701c1ab908aba289e011703e617ec8136.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fa0330d822b8`

`dg-ec66dc926650096426fec48b` / canonical / solver_augmented / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/d03ce01bbf652c40a2c61429c4bcb44a7070f591b7e0a0dd174cc7a518948fa6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `26e9a3dbed32`

`dg-ec68a6051846d1b6ea25db63` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/529bfd045e14f85bba5378d1542e9f4338f15b4b75cf53378e1cd37eda860d04.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1ffc84bfa79c`

`dg-ec6920d709f8059882d3b0a7` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/b93bba34391b2b0da4d19835659aa741a846deabb9c3079ebba8f74555586da1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `71f2ff95cb1a`

`dg-ec7903c9d95454dda760f88a` / canonical / solver_augmented / hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/133aafe1c0bcc50c4fec3ada82a51d89de350a81c1442aeb1113b8c5c67d26b2.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4b202f0f8c24`

`dg-ed1d3af47d59dcc65d1f1c04` / canonical / direct / hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/8fbffe3527b913515bc5877fa9cf4110f222f2d1e958e5f1ea68119944f4bb97.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1652b1b941bb`

`dg-ed26ff14cfb03ca08a920814` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0aa0a44d3be22e52e150c0e72e768915e5798048bc69f21a5a57c996b4964f00.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5cbda0ca2bf7`

`dg-ed6ee5ffce06375975dc4b5e` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/8a1fb196c81ab2ad26e4375b80563fb0679665a12d4c4ecd671f6b33eeeb0580.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c3183a52e124`

`dg-ed6ee5ffce06375975dc4b5e` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/ff88e6a2de7168ee9c316ca492d932c8984890acf11c073167b07121d6cd1dc4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `30b7671ee1a8`

`dg-ee4821ff221f450960ddc3e0` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/7263f5cc6c87a8f226414a277311aeb52d474776b2edad38f88bcc88dfc3d920.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `6b77da2b4615`

`dg-efd5bc5ef6fa7b7a9859f818` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/b754ff80644dd124c89bed526eba19f4ce73ea9a76b64faa4c7bef0a2962db28.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `9c71bf5ce232`

`dg-efda67d35490f127cfa8aa73` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3f32490fb342f35be6c6c0779da06395d43bcf0c840e856de870b9a02d2e5442.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5a95b7b85700`

`dg-effa32b88dc36f96df7f7746` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/4fe133178bd0c109ae195eb7d742b2d4ab5a27706fb52ac93a5b692b892b1ef3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `239473af2fa3`

`dg-f05d1bc1090398b1e6f297d5` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ca7800ce6370ef83d683f821ee1ab39cf44959b8b1aa06df63ee853b35f6c14a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `cbc2f57b943a`

`dg-f097c01f403cfba0107829b8` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3e790217ff2ee62a8de32dada854762ff96dd26e97cf832decfddcfd2ec6adf4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0e220d97ebc0`

`dg-f0e9f421e620f8f6caf316e5` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/f8a094b7122706b5a52683ecb991dde950d684e8a107cc338b222974f32743b3.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `24c60b29ea5c`

`dg-f0f3dacf4591407c30766049` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/129a5524f22afe5a9ff213aa468eb82291d9cd761cf0020a185a0ca5ddc6d2f7.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `3a3e8a15ea1e`

`dg-f11bd8682ef135f894f14ee1` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/cc19927fdcb771a8b914c461372af5cc18acf05741effd3efe945b25e9ed1088.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1a22672d720f`

`dg-f171b04f3df9c26faf120098` / canonical / direct / extreme. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/ca74e0d2a58b25807c2d2c559bc13cb22acbe8fa2fd643340cf83dcd63a0968b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `087969b2121f`

`dg-f1760bfe3ade1a5b0ad006d7` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/871b00f72253ad4b4e0d9d8c2a4904ac490881d1454f7de8a74a86af95ba7768.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4748d8771166`

`dg-f1760bfe3ade1a5b0ad006d7` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/7b7071c808825193d83c68dc5308d8ff0d0f5a72d67298c267dc05e868ea2114.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7af4e256c810`

`dg-f1c4e759e4d2b2409b2f2b87` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/7c9653deb4fcfe54fb25f9a3e685e124b96b86fb0ea9160acbeac0fde4c90218.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c0d944dcf776`

`dg-f1e0981146fc68084a239eda` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5bd8133410b17cd1d1da7a003d62b51a9016ff986cb060625c8e3471030c02f0.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f82bfe8326a6`

`dg-f31992a173115f196f88aa20` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/5036c6d929d64480e0ba9e9a94e7a1eaa1b1071a6fbf053b326572b6d1c11f49.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f781806bfced`

`dg-f3d6914bf2ccfdbc898573dc` / canonical / direct / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/918c9bada6b8e39fa95d6506cace504fb6f9326ce56bfdc7655148b8bd56de85.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4f4c0a419658`

`dg-f3d7a3a0969df19b6b9f6bbf` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/94b4883860ab329c4e1185440a46dc536fd85f9b5c8446109ea4078e9e367812.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b90b89c59b8f`

`dg-f3d7a3a0969df19b6b9f6bbf` / canonical / solver_augmented / easy. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/726dd21021c8bf31f8882e5f31eeb6f34b88055c168234322b4367ef5ad277a6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `1c7b95f47d39`

`dg-f4866987f87ceb3823d07e5e` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/ec47ddcc82297397d0b712ba319ecadaf66439af9c57c86d432f513e454838ba.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `acf672cac535`

`dg-f4866987f87ceb3823d07e5e` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/756ab971cf66ff7392ba1bd33badc7b7d193d846668e0e312be77298de37c851.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0f286ca2ed4a`

`dg-f4fef6462a93e922469513c0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/3f1ca82b7b87f3e40d30c5eccab440959d1d8861b2d16fa9e7f6bf122f868bda.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `dfcc2181d759`

`dg-f599d407b781a0730818e432` / canonical / direct / easy. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/3ff3e3de79e1a6ba5bde7b14adc60778b40cdd20bfe0453051c62026c1ae94d1.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `87def7326e1a`

`dg-f5a703ea5706a08a268cfa25` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/bbc461177ede08d79904214a7a1a71cae75c4e6e3ed65bd36439a2c49b6f003e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `564fad61543b`

`dg-f6254495331fea5990caf7f5` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/fb677ef10796dfe0468dd8f94b0db44d8c3c730a747baa7ed5bce8c9b00c79fe.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `c4f987f62cba`

`dg-f65d1f13bc4ee9d4e0635479` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5cf2e3e2bae31a6a4331da6229809c33f6d3d68ec1bb58526645f87c4f14f592.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `409a7c081f9d`

`dg-f68903b409b4ebf5a51b561e` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/0ffbcf1a2add9472ba631515139693d696eb6bd27c166227186a9b2cd4b3a2b6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ad7a124b5027`

`dg-f6b945c20e57260f07ea67c3` / canonical / direct / hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/89c14082dfd0ff4c431e64d20efa3d47731d63301b40cb88e22b4ade63ac3679.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `fe35aeefef78`

`dg-f774f14989adc6cb612531c5` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/d1e0d29e59861451f7159171ae2c33d5297fa5fc56ea071fb381b2ef20493eae.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `7f2fcf0cf4a2`

`dg-f774f14989adc6cb612531c5` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Independent validation found a concrete schedule accepted by one specification and rejected by the other, demonstrating a hard-feasibility difference on that witness.
- Attempt record: `runs/controlled/controlled/attempts/e4eec79a0cdf6ef9d174fe77e54f3d20e922260094947e0cdfd64ba41602587a.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ad27b76dd7bb`

`dg-f8b08eaefa17cea0a92a54cf` / canonical / direct / very_hard. Selection: all_observed_issues.

- The provider attempt failed; this is not evidence of a reasoning failure.
- Attempt record: `runs/controlled/controlled/attempts/71cec977bae56e8837e4863be8166038c70a05eeda0607699fcab320dfe2d34e.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `343e69ca5791`

`dg-f8b713e33a7ef884e811f8a9` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, participant_availability, participant_overlap.
- Attempt record: `runs/controlled/controlled/attempts/ecf9438d1f6f769150b5623eb21a300fa9eefcd743927f8784426cf1dd4b9275.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `db49b441cd99`

`dg-f8ca78e474d3cdcaaa72bd01` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3961f5dd666b676c186ea73b9a8f2ea697c247bf2601c5b0f3e222b3ae210155.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a62b31e815a`

`dg-f96a2c29d58ab8c50fb11906` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3f951c702fb14c147e51c63a99a2698011a2a94d5ac9843452839ec5217f745b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `ef4a1937878a`

`dg-fa6ae0de8405127a8fbd6446` / canonical / direct / moderate. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/bcbaf27206eaf83ecee117d7a343110b4d3fbcb477851ec1ed6747fad49947b5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `2a4cf79079e0`

`dg-fab372c86b2a57a4c2a242da` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/313df658c8db89de9aab4ee2de331e4d84c8fb52abc29c04d447d4688dfd8af5.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `98b2ab6e91bc`

`dg-fb17cb49c6398b0b1628308c` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/df37fb4cdef2c469042e5a997fc37e50298a38d845682eed0871802bab26da65.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `830aa93e633a`

`dg-fb96f621d49445d2337956bc` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/3d6e1491dade29c0a0859c6bd9ca5b917bb4b7384e5768a17ea1556712860109.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5db24a3ca989`

`dg-fbd544e98512afa054502777` / canonical / direct / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/1695e26ad6b56e062c8cd631af33ae0b2305c44d4756e199ecda534d7fcb1104.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `df74e3dca23b`

`dg-fbd544e98512afa054502777` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/c20c20cb46d516ee2eb706e978021df53028edda55b2eb30a01fa3c6c188042b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `0d1c7f7780b4`

`dg-fc4494d2ecb71f7bfb46ff7e` / canonical / direct / extreme. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/267232530aed30d3211395f92cc36120bacfddd648e76ab9f9f942bf05939d29.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `e5adb045e479`

`dg-fc4494d2ecb71f7bfb46ff7e` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/da8f39435c2e3240a2bf7d44a2ce9dcef8622ef06b8cabbf36b14f55c454bfa4.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `5528515fb998`

`dg-fc5e1c67a0dd698a705f1264` / canonical / direct / easy. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/c47b9609bb6b288e429db3ff0f8dd523ba4a32d96487c33a6bb89dfcdab41556.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `851dc3266d54`

`dg-fcadf4cb92325fab958e20a0` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/b67964b5568d5904e7be7de79a8aa7a04219f45ffce4c868fea0dd6ac5e1b17b.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `466811b1574b`

`dg-fccded194c48615187bf19b8` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/bbe8bdabab3224d13b6973a959982a271890f47227169267e02cd7cc6bd52412.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `682b227adf58`

`dg-fd44788562b6cf3f01db3d00` / canonical / direct / very_hard. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/5675bb2b7d67eeec5f85b648838bff0aa744c8ffa857f916a5df23cb2b15d0c6.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `066449a251ff`

`dg-fe2a398f1773ac13d6770ca8` / canonical / direct / moderate. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/628d13f0f1b282310bfea08321a6e0c4bf47dea493f70c008101adbb10eaef36.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `4e2374bee428`

`dg-fe2b912bc571ac60f0148728` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence, resource_overlap.
- Attempt record: `runs/controlled/controlled/attempts/e89d043e03638460c21950755a868e077681c44f8b0ab1c4b48ed086677e7d63.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `b70e1e6f8c66`

`dg-fef2920b661c0aa1dab562a2` / canonical / direct / very_hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/2ca38b11d1b4b05a467e2ed2c5ca534cb2c8eff9fe5187da4dc0a0c480b9dc87.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `40621d9dd4d4`

`dg-fef2920b661c0aa1dab562a2` / canonical / solver_augmented / very_hard. Selection: all_observed_issues.

- The answer met the primary gold acceptance criterion.
- The extracted specification differs structurally from gold. This alone does not prove semantic error or causation.
- Attempt record: `runs/controlled/controlled/attempts/c865b28a5d35e7a32402ca5f276ab33838b0b60f9e91dbfe2dbc0a29e86d9a33.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `d156ea117ab0`

`dg-ff67a635d3f66d5dd00b9719` / canonical / direct / moderate. Selection: all_observed_issues.

- The returned schedule violates the evaluator's gold requirements.
- Gold validation found: activity_availability, deadline, participant_overlap, precedence.
- Attempt record: `runs/controlled/controlled/attempts/201b7e3f8c2acc117b8ddfa74eb812047daa8de9ebc6b6f96199b090c56eebfa.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `f446249abc02`

`dg-ffbcbdc830de9b102f43d8b3` / canonical / direct / hard. Selection: all_observed_issues.

- UNSAT was returned for a gold problem with a validated feasible witness.
- Attempt record: `runs/controlled/controlled/attempts/703144618e31cf44adc4693df3e1944410d356ab37c05da61d128891079fb4b9.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

### Example `67530dbdd0ed`

`dg-ffd0965d79e476e1634aba8b` / canonical / solver_augmented / extreme. Selection: all_observed_issues.

- The answer failed the required output/schema contract.
- Attempt record: `runs/controlled/controlled/attempts/230eadb4d6fa5fe1fd6aef7345d713f11bc5629f522b30db0cd350db0a7e7025.json`

Review: Which exact request fact explains the observation? Does the evidence establish a cause or only a difference? What does the paired method do, and what scope limitation follows?

